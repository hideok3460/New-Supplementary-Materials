# Data dictionary and conventions

## Data classes

- `HARDWARE`: counts imported from the supplied original archive or retrieved from the explicitly saved actual IBM job IDs. A JSON label alone is not a universal authenticity certificate; preserve import/job provenance and hashes.
- `SYNTHETIC_TEST`: sampled artificial data used only to test software. Output prefixes are `synthetic_`, never `measured_`.
- Ideal/illustrative/summary-derived outputs: equations, noise assumptions or rounded old-table calculations. Not a raw-data reanalysis.
- Compiled plans: no measurements, even if a calibration snapshot or QPY file exists.

## Tensor, measurement and channel conventions

Five-qubit tensor order: |q4 q3 q2 q1 q0>. Receiver matrices/count strings: |q4 q3>. Receiver c[0] measures q3 and c[1] measures q4. `basis='XY'` means X on q4 and Y on q3; Y measurement uses S† followed by H. Input y=0; V maps logical 0→00 and 1→11.

For raw data, z=m XOR x, k=m XOR M1 XOR M2, u=|z,k>, v=|1 XOR z,1 XOR k>. The raw support parity is y_raw=x XOR M1 XOR M2. `phase_rad` is arg(rho[u,v]); ideal is wrap(-pi/3 + pi*M2). `phase_fixed_code_rad` is arg(rho[a,b]) in V_yraw order. When k=1, it is the conjugated coherence. Its ideal is separately recorded.

Recovery frame: C=X^(m XOR x) tensor (X^(m XOR M1 XOR M2) Z^M2). Exact inverse C† is applied physically in chronological X-then-Z order on q3, or tracked by C† rho C. Physical and frame-tracked states use y=0. Both have target phase -pi/3 for chi. `chi = sqrt(.7)|00> + exp(i*pi/3)sqrt(.3)|11>`; ideal concurrence = 2sqrt(.21).

Choi order is input⊗output, unnormalized. E(rho)=sum_ij rho_ij J_ij. Tr_output J <= I; survival=Tr(J)/2, identity_overlap=<Phi+|J|Phi+>/2. These are trace-aware CP-TNI metrics, not an ordinary normalized CPTP process fidelity or average gate fidelity. PTM order is I,X,Y,Z with R_ab=Tr(sigma_a E(sigma_b))/2.

## `receiver_counts.json`

`schema_version=1`, `data_kind`, `backend`, `receiver_bit_order='q4 q3'`, and `records` are stored. New data also carry manifest hash, actual `job_ids`, acquisition ID and collection time. Each record includes resource `[M1,M2]`, sector `[x,m]`, recovery, probe, basis, integer counts, shots, circuit/acquisition index, protocol, backend, grouping key and true `hardware_job_id`.

`job_id` is retained for backward compatibility as the acquisition grouping key in new records. `hardware_job_id` is the actual IBM ID. Never report the acquisition grouping string as if it were an IBM job. Different acquisitions/devices are not silently pooled.

## State CSVs

The network chi-state table contains 32 raw/physical groups plus 16 derived frame-tracked rows. Baseline protocols have their own tables. Full matrices for **all five** input probes are stored, not just chi.

| Field | Meaning |
|---|---|
| `state_id`, `matrix_file`, `bootstrap_file` | Stable local ID and paths relative to that analysis/protocol folder |
| `recovery` | raw, physical, or frame_tracked |
| `derived_from_raw` | True only for software conjugation; no additional independent shots |
| `coherence_row`, `coherence_col` | Exact matrix indices used by phase_rad |
| `raw_code_y`, `evaluation_code_y`, `recovered_code_y` | Explicit subspaces; no hidden postselection |
| `phase_rad`, `ideal_phase_rad`, `phase_error_rad` | Branch-ordered phase, matching ideal, wrapped difference |
| `phase_fixed_code_rad`, `ideal_fixed_code_phase_rad` | Fixed-code order phase and corresponding ideal |
| `tracked_phase_rad`, `tracked_phase_error_rad` | Corrected raw phase or physical recovered phase, compared with -pi/3 |
| `*_lo`, `*_hi` | 95% counting bootstrap percentile interval; phase intervals locally unwrapped |
| `phase_localized_approximate_check` | Approximate bivariate-origin/separation and circular-concentration diagnostic; not rigorous coverage |
| `phase_resultant_length` | Bootstrap circular concentration |
| `phase_warning` | Unreliable phase CIs are blanked, not interpreted as precise phase measurements |
| `concurrence`, `negativity` | Evaluated on the full trace-one two-qubit PSD mixed state, not on a postselected code block |
| `code_population`, `leakage` | Population in the specified code and its complement within the two-qubit computational space |
| `bootstrap_projection_fraction` | Fraction of state-count resamples requiring a nontrivial PSD projection |

The PSD state estimate uses eigenvalue-simplex projection, not zero-clipping and rescaling. `state_projection_audit.csv` retains every probe's pre-projection eigenvalue and projection change. Weak/zero coherence makes phase unidentifiable. Local percentile intervals may cross ±pi; do not wrap their endpoints independently into an ordinary interval.

## Process / GOF

Four probes 0,1,+,+i are used in each fit. The chi probe is held out. Each input's code block remains unnormalized. Raw-probe blocks are frame-tracked before fitting; the CSV names that fitted recovery `frame_tracked` and retains `source_recovery='raw'`.

`block_residual` is sum of four squared Frobenius block errors, not itself a Pearson statistic. `choi_min_eigenvalue`, `effect_max_eigenvalue`, linear-estimator diagnostics, and `bootstrap_boundary_fraction` audit physicality. Each bootstrap refits the physical operation. Failures raise; failed draws are not silently discarded.

GOF fits a full 2→4 CPTP multinomial nuisance model (8×8 Choi), using ideal probe and measurement axes as assumptions. Data drawn from its fitted probabilities are refitted to calibrate both Pearson X² and the original CP-TNI block objective. P values use (1+number_exceeding)/(B+1). Per-cell observed/expected counts and the simulated null statistics are saved. This is a plug-in local diagnostic, not proof of correct SPAM or guaranteed boundary coverage. No universal chi-square degrees of freedom are assumed.

## Additional artifacts

`final_layouts_and_counts_mapping.csv` links acquisition indices, actual IBM job IDs, receiver ordering and physical readout pairs. `compiled_recovery_overhead.csv` compares raw/physical circuits at the same logical settings and flags a changed readout pair. Gate-calibration proxy columns are not measured fidelity predictions.

Readout calibration prepares 00,01,10,11 for each routed pair at two manifest bookends. The response includes preparation error. No correction is silently applied to the primary state/process estimates. Hardware scheduling may differ from manifest order.

Selected discarded observables are X2, X1, Z0 with ideal expectations (-1)^m, (-1)^M1, (-1)^(m XOR x) for input C0. Connected correlations are estimated from joint c/d shot-paired counts with count bootstrap. This witness set is not informationally complete for the five-qubit state and cannot certify factorization by itself.

Calibration snapshots distinguish compile, submission and collection times. None is automatically an exact execution-time snapshot. Job metrics and available execution-span metadata are retained separately.

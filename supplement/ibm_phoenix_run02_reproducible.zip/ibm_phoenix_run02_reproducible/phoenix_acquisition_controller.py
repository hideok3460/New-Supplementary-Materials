"""Validated source controller for NEW IBM acquisition (optional mode only).

Taken from stages 2-7 of the supplied fixed5 sequential notebook. The original
scientific routines are imported unchanged; no IBM key or instance CRN is stored.
Only import this module when acquiring or resuming incomplete hardware results.
Interactive approval for potentially billable QPU submissions is mandatory.
"""
from __future__ import annotations
import os
# IBM authentication input guard, embedded in this notebook.
# Does not save credentials, mutate workflow.py, create accounts, or submit jobs.
import getpass as _getpass
import io as _io
import logging as _logging
import warnings as _warnings
from contextlib import contextmanager as _contextmanager
from contextlib import redirect_stdout as _redirect_stdout, redirect_stderr as _redirect_stderr


class RuntimeConnectionIssue(RuntimeError):
    """Only a fixed, public code/message is exposed; never raw SDK error text."""
    def __init__(self, code, message):
        self.code = code
        self.public_message = message
        super().__init__(message)


def _credential_text(value):
    # Strip surrounding paste artifacts, never modify characters inside a key.
    if not isinstance(value, str):
        return ""
    return value.strip().strip("\ufeff\u200b").strip()


def _validate_api_key(value):
    value = _credential_text(value)
    if not value:
        raise RuntimeConnectionIssue("API_KEY_REQUIRED", "APIキーが空です。ダッシュボードで取得したAPIキーを入力してください。")
    if value.lower().startswith("crn:"):
        raise RuntimeConnectionIssue("API_KEY_FIELD_CONTAINS_CRN", "APIキー欄にCRNが入力されています。この欄にはAPIキーを入力してください。")
    if (any(c.isspace() for c in value) or any(c in value for c in "<>\"'\u200b\ufeff")
            or value.lower() in {"api_key", "your_api_key", "your-api-key", "token", "..."}):
        raise RuntimeConnectionIssue("API_KEY_COPY_FORMAT", "APIキーだけをコピーしてください。説明文、引用符、空白、改行は含めません。")
    # No fixed key length: format checks cannot establish key validity.
    return value


def _validate_instance_crn(value):
    value = _credential_text(value)
    if not value:
        raise RuntimeConnectionIssue("INSTANCE_CRN_REQUIRED", "CRNが空です。Instances画面のCopy CRNでコピーしてください。自動的な利用枠選択は行いません。")
    if not value.startswith("crn:"):
        raise RuntimeConnectionIssue("INSTANCE_CRN_FORMAT", "CRNは crn: で始まります。APIキーではありません。Instances画面のCopy CRNから全文をコピーしてください。")
    if any(c.isspace() for c in value) or any(c in value for c in "<>\"'\u200b\ufeff") or "..." in value:
        raise RuntimeConnectionIssue("INSTANCE_CRN_COPY_FORMAT", "CRNに空白、説明用の記号、または省略記号があります。Instances画面から省略せずコピーしてください。")
    parts = value.split(":")
    if (len(parts) != 10 or parts[1] != "v1" or parts[2] != "bluemix"
            or parts[3] not in {"public", "dedicated", "local"}
            or not parts[5] or not parts[6].startswith("a/") or len(parts[6]) <= 2
            or not parts[7] or parts[8] or parts[9]):
        raise RuntimeConnectionIssue("INSTANCE_CRN_STRUCTURE", "サービスインスタンスCRNの形式を確認してください。先頭から末尾の :: まで、Copy CRNでコピーします。")
    if parts[4] != "quantum-computing":
        raise RuntimeConnectionIssue("INSTANCE_CRN_WRONG_SERVICE", "IBM QuantumのインスタンスCRNが必要です。他のIBM CloudサービスのCRNでは接続できません。")
    return value


@_contextmanager
def _quiet_auth_sdk():
    """Suppress raw SDK auth output only during this synchronous read/connection.

    SDK exceptions may contain the entered token/instance. Fixed diagnostic codes
    replace raw output. Logging/streams/warnings are restored even after failure.
    Do not run this notebook concurrently in the same Python kernel.
    """
    old_disable = _logging.root.manager.disable
    try:
        _logging.disable(max(old_disable, _logging.CRITICAL))
        with _io.StringIO() as sink, _redirect_stdout(sink), _redirect_stderr(sink):
            with _warnings.catch_warnings():
                _warnings.simplefilter("ignore")
                yield
    finally:
        _logging.disable(old_disable)


def _sdk_problem(exc):
    # Read exception category/status only; never return str(exc), repr(exc), or its args.
    names = {cls.__name__ for cls in type(exc).__mro__}
    response = getattr(exc, "response", None)
    status = getattr(exc, "status_code", None) or getattr(response, "status_code", None)
    if status == 401 or names & {"IBMNotAuthorizedError", "AuthenticationError", "IBMInvalidTokenError"}:
        return RuntimeConnectionIssue("AUTHENTICATION_REJECTED", "APIキーが拒否されました。有効な再発行済みAPIキーと、そのキーのIBM Cloudアカウントを確認してください。")
    if status == 403:
        return RuntimeConnectionIssue("INSTANCE_ACCESS_DENIED", "インスタンスへのアクセスが拒否されました。APIキーのアカウントとCRNの利用権限を確認してください。")
    if "IBMInputValueError" in names:
        return RuntimeConnectionIssue("INSTANCE_OR_ACCOUNT_INVALID", "入力形式は検査済みですがIBM側が指定を受け付けませんでした。CRNの存在、APIキーとインスタンスのアカウント一致、利用権限を確認してください。")
    if names & {"AccountNotFoundError", "InvalidAccountError", "CloudResourceNameResolutionError"}:
        return RuntimeConnectionIssue("SAVED_ACCOUNT_INVALID", "保存アカウントの設定を確認するか、PROMPT_FOR_CREDENTIALS=TrueにしてAPIキーとCRNを入力し直してください。")
    if names & {"SSLError", "ConnectTimeout", "ReadTimeout", "Timeout", "ConnectionError", "ProxyError"}:
        return RuntimeConnectionIssue("CONNECTION_NETWORK_OR_TLS", "接続・TLS・プロキシを確認してください。証明書検証を無効にせず、ネットワーク設定を確認して再実行してください。")
    if names & {"QiskitBackendNotFoundError", "BackendNotFoundError"}:
        return RuntimeConnectionIssue("BACKEND_NOT_ACCESSIBLE", "指定バックエンドがこのインスタンスで見つかりません。config.jsonのbackendと利用可能な実機を確認してください。")
    return RuntimeConnectionIssue("IBM_CONNECTION_FAILED", "IBMへの接続確認に失敗しました。APIキー、CRN、利用権限、ネットワーク、qiskit-ibm-runtimeの版を確認してください。秘密情報保護のため生の例外文は表示しません。")


def _read_hidden_credential(prompt, validator, max_attempts):
    for attempt in range(max_attempts):
        try:
            with _warnings.catch_warnings():
                # Refuse getpass's visible-input fallback if this front end cannot hide input.
                _warnings.simplefilter("error", _getpass.GetPassWarning)
                text = _getpass.getpass(prompt)
        except _getpass.GetPassWarning:
            raise RuntimeConnectionIssue("HIDDEN_INPUT_UNAVAILABLE", "この画面は非表示入力に対応していません。通常のJupyterLabのPythonカーネルで実行してください。") from None
        except (EOFError, KeyboardInterrupt):
            raise RuntimeConnectionIssue("AUTH_INPUT_CANCELLED", "認証入力を中止しました。操作は開始していません。") from None
        text = _credential_text(text)
        if not text:
            raise RuntimeConnectionIssue("AUTH_INPUT_CANCELLED", "空欄のため認証を中止しました。正しいAPIキーとCRNを確認後、同じ操作セルを再実行してください。")
        try:
            return validator(text)
        except RuntimeConnectionIssue as issue:
            text = ""  # Do not echo the rejected value or keep it in a result file.
            print(f"入力確認 [{issue.code}]: {issue.public_message}")
            if attempt + 1 < max_attempts:
                print("この欄だけをもう一度入力してください。空欄で安全に中止できます。")
    raise RuntimeConnectionIssue("CREDENTIAL_INPUT_RETRY_LIMIT", "入力の再試行回数に達しました。認証情報を確認し、操作セルを再実行してください。IBMへの接続は行っていません。")


def _saved_options(factory, account_name):
    # Never print the returned dictionaries: they contain API keys.
    try:
        with _quiet_auth_sdk():
            if account_name:
                records = factory.saved_accounts(name=account_name)
            else:
                records = factory.saved_accounts(default=True)
                if not records:
                    records = factory.saved_accounts()
    except Exception as exc:
        raise _sdk_problem(exc) from None
    if not records:
        raise RuntimeConnectionIssue("NO_SAVED_ACCOUNT", "保存済みアカウントがありません。PROMPT_FOR_CREDENTIALS=Trueで入力してください。")
    if len(records) != 1:
        raise RuntimeConnectionIssue("SAVED_ACCOUNT_AMBIGUOUS", "保存アカウントを一意に選べません。SAVED_ACCOUNT_NAMEを指定するか、非表示入力を使ってください。自動選択はしません。")
    name, record = next(iter(records.items()))
    if record.get("channel") not in {"ibm_quantum_platform", "ibm_cloud"}:
        raise RuntimeConnectionIssue("SAVED_CHANNEL_UNSUPPORTED", "旧サービスまたはローカル用の保存設定です。PROMPT_FOR_CREDENTIALS=Trueで現行IBM QuantumのAPIキーとCRNを入力してください。")
    _validate_api_key(record.get("token"))
    crn = _validate_instance_crn(record.get("instance"))
    return {"name": name, "instance": crn}


def connect_runtime_checked(prompt_for_credentials=True, saved_account_name="", max_attempts=3):
    """Connect with an explicitly validated CRN; no implicit paid-instance choice.

    Interactive mode always asks again, ignoring stale environment/saved values.
    Noninteractive mode validates a specified saved account or complete env pair;
    ambiguous saved accounts and absent CRNs fail closed.
    """
    if not isinstance(max_attempts, int) or not 1 <= max_attempts <= 5:
        raise RuntimeConnectionIssue("AUTH_RETRY_SETTING", "AUTH_MAX_ATTEMPTSは1～5の整数にしてください。")
    try:
        from qiskit_ibm_runtime import QiskitRuntimeService
    except ImportError:
        raise RuntimeConnectionIssue("RUNTIME_PACKAGE_MISSING", "このPythonカーネルにqiskit-ibm-runtimeがありません。Revision_fixed5の実機用セットアップを確認してください。") from None
    kwargs = {}
    try:
        if prompt_for_credentials:
            print("APIキーとCRNは別の値です。2つとも非表示入力です。空欄で中止します。")
            print("CRN: IBM Quantum Platform → Instances → 使用するインスタンス → Copy CRN（crn: で始まる全文）")
            print("今回は入力値を使用し、保存アカウント・環境変数の古い認証情報は使用しません。")
            token = _read_hidden_credential("1/2 API key（非表示・空欄で中止）: ", _validate_api_key, max_attempts)
            crn = _read_hidden_credential("2/2 Instance CRN（crn:で始まる全文・非表示）: ", _validate_instance_crn, max_attempts)
            kwargs = {"channel": "ibm_quantum_platform", "token": token, "instance": crn}
        else:
            name = _credential_text(saved_account_name) or _credential_text(os.environ.get("IBM_QUANTUM_ACCOUNT_NAME"))
            if name:
                kwargs = _saved_options(QiskitRuntimeService, name)
            else:
                token = _credential_text(os.environ.get("IBM_QUANTUM_API_KEY"))
                crn = _credential_text(os.environ.get("IBM_QUANTUM_INSTANCE"))
                if token or crn:
                    kwargs = {"channel": "ibm_quantum_platform", "token": _validate_api_key(token),
                              "instance": _validate_instance_crn(crn)}
                else:
                    kwargs = _saved_options(QiskitRuntimeService, "")
        try:
            with _quiet_auth_sdk():
                service = QiskitRuntimeService(**kwargs)
        except (EOFError, KeyboardInterrupt):
            raise RuntimeConnectionIssue("AUTH_INPUT_CANCELLED", "認証処理を中止しました。実機ジョブは送信していません。") from None
        except Exception as exc:
            raise _sdk_problem(exc) from None
        print("IBMへの接続に成功しました（この認証処理では実機ジョブを送信しません）。")
        return service
    finally:
        # Not cryptographic erasure: the SDK must retain credentials in process memory.
        kwargs.clear()
        token = crn = ""


def check_runtime_backend(service, backend_name):
    """Read-only backend check. Never compiles, submits, or changes the backend."""
    try:
        with _quiet_auth_sdk():
            backend = service.backend(backend_name)
            status = backend.status()
            qubits = int(backend.num_qubits)
            operational = bool(status.operational)
    except (EOFError, KeyboardInterrupt):
        raise RuntimeConnectionIssue("AUTH_INPUT_CANCELLED", "接続確認を中止しました。実機ジョブは送信していません。") from None
    except Exception as exc:
        raise _sdk_problem(exc) from None
    state = ("CONNECTION_CHECK_PASSED_NO_JOB_SUBMITTED" if operational and qubits >= 5
             else "BACKEND_NOT_READY_NO_JOB_SUBMITTED")
    return {"status": state, "backend": backend_name, "operational": operational,
            "num_qubits": qubits, "jobs_submitted_by_this_action": 0,
            "note": "Authentication/backend lookup only. No compilation, measurement, or account changes."}


# Embedded controller for the fixed5 sequential notebook.
# This layer changes orchestration only; scientific functions remain in fixed5.
import copy as _copy
import csv as _csv
import hashlib as _hashlib
import itertools as _itertools
import json as _json
import math as _math
import re as _re
import sys as _sys
import threading as _threading
import time as _time
from collections import Counter as _Counter
from contextlib import contextmanager as _contextmanager
from pathlib import Path as _Path
from workflow_paths import (ROOT, RESULTS, load_config, write_json, sha256,
                            code_fingerprint, utc_now, jsonable)
import workflow as _wf
import ibm_followup as _ibm


class SequentialStop(RuntimeError):
    """Public diagnostics only; do not expose SDK exceptions or local variables."""
    def __init__(self, code, message):
        self.code = code
        self.public_message = message
        super().__init__(f'[{code}] {message}')

    def _render_traceback_(self):
        return [f'安全に停止しました [{self.code}]', self.public_message,
                '後続セルへ進まないでください。Resultsの記録は削除しないでください。']


def _stop(code, message):
    raise SequentialStop(code, message)


def _read_json(path):
    try:
        return _json.loads(_Path(path).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        _stop('LOCAL_RECORD_UNREADABLE', '保存ファイルを読めません。作業フォルダとJSONを確認してください。')


def _question(prompt, validate, *, default=None, attempts=3):
    """Only public operational settings. Credentials use getpass, separately."""
    for _ in range(attempts):
        try:
            value = input(prompt).strip()
        except (EOFError, KeyboardInterrupt):
            _stop('USER_CANCELLED', '入力を中止しました。新しい実機ジョブはこの入力では送信していません。')
        if not value and default is not None:
            value = str(default)
        if value.lower() in {'q', 'quit', 'cancel'} or not value:
            _stop('USER_CANCELLED', '操作を中止しました。保存済みのジョブやデータはそのままです。')
        try:
            result = validate(value)
            if result is not False:
                return result
        except (ValueError, TypeError):
            pass
        print('入力が一致しないか形式が違います。この入力欄で再入力できます。qで中止。', flush=True)
    _stop('INPUT_RETRY_LIMIT', '入力の再試行上限です。説明を確認してください。')


def _run_id(value):
    if not _re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,79}', value) or '..' in value:
        raise ValueError('invalid run id')
    return value


def _positive_int(value):
    if not value.isdecimal() or int(value) < 1:
        raise ValueError('positive integer required')
    return int(value)


@_contextmanager
def _operation_lock(folder):
    """OS-level lock, released even if kernel exits; Windows and POSIX supported.

    Lock files are not submission records. We never delete or reset job records.
    One notebook/controller should operate on a run at a time.
    """
    path = _Path(folder) / '.sequential_operation.lock'
    stream = path.open('a+b')
    locked = False
    try:
        stream.seek(0, 2)
        if stream.tell() == 0:
            stream.write(b'0'); stream.flush()
        stream.seek(0)
        try:
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            locked = True
        except OSError:
            _stop('RUN_IN_USE', '同じ実験を別のセル／カーネルが操作中です。並列実行しないでください。')
        yield
    finally:
        if locked:
            try:
                stream.seek(0)
                if os.name == 'nt':
                    import msvcrt
                    msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(stream.fileno(), fcntl.LOCK_UN)
            finally:
                stream.close()
        else:
            stream.close()


class SequentialRun:
    """Fixed order: configure -> connect -> compile -> submit -> collect -> analyse -> report -> export.

    No automatic retries of submission. Polling retries only read operations.
    Resumption uses the SAME run_id and validates saved design and raw counts.
    """
    VERSION = 'fixed5-sequential-1.0'

    def __init__(self, cfg, *, poll_seconds=30, max_wait_hours=None, progress_seconds=30):
        self.cfg = _copy.deepcopy(cfg)
        self.poll_seconds = float(poll_seconds)
        self.max_wait_hours = max_wait_hours
        self.progress_seconds = float(progress_seconds)
        if self.poll_seconds < 5 or self.progress_seconds < 5:
            _stop('POLL_SETTING', '状態確認間隔は5秒以上にしてください。通常は30秒です。')
        if max_wait_hours is not None and (isinstance(max_wait_hours, bool) or max_wait_hours <= 0):
            _stop('WAIT_SETTING', 'max_wait_hoursはNoneまたは正の値です。')
        self.service = None
        self.folder = None
        self.plan = None
        self.done = set()
        self.blocked = False
        self.analysis_dir = None
        self._stream = _sys.stdout

    def _emit(self, message):
        # workflow.logged_step redirects global stdout. Retain notebook output stream.
        try:
            self._stream.write(str(message) + '\n'); self._stream.flush()
        except Exception:
            pass

    def _record(self, stage, status, **extra):
        if self.folder is not None:
            write_json(self.folder / 'sequential_progress.json',
                       {'workflow': self.VERSION, 'stage': stage, 'status': status,
                        'updated_utc': utc_now(), 'completed_stages': sorted(self.done), **extra})

    def step(self, stage):
        order = ('configure', 'connect', 'compile', 'submit', 'collect', 'analyse', 'report', 'export')
        if self.blocked:
            _stop('PREVIOUS_STEP_STOPPED', '前の工程で停止しています。後続工程は実行しません。原因を確認後、カーネルを再起動して同じrun_idで上から再開してください。')
        if stage not in order:
            _stop('UNKNOWN_STAGE', 'ノートブックの工程名が不正です。')
        needed = set(order[:order.index(stage)])
        if not needed.issubset(self.done):
            _stop('CELL_ORDER', '上の工程が未完了です。セルは上から順に実行してください。')
        try:
            self._record(stage, 'RUNNING')
            getattr(self, '_' + stage)()
            self.done.add(stage)
            self._record(stage, 'COMPLETED')
        except KeyboardInterrupt:
            self.blocked = True
            self._record(stage, 'INTERRUPTED')
            _stop('INTERRUPTED', '操作を中断しました。IBMに送信済みのジョブは自動キャンセルされません。同じrun_idの記録を残し、再開時は上から実行してください。送信途中の場合は照合が必要です。')
        except RuntimeConnectionIssue as exc:
            self.blocked = True
            self._record(stage, 'STOPPED', code=exc.code)
            raise SequentialStop(exc.code, exc.public_message) from None
        except SequentialStop as exc:
            self.blocked = True
            self._record(stage, 'STOPPED', code=exc.code)
            raise exc from None
        except Exception as exc:
            self.blocked = True
            self._record(stage, 'STOPPED', code='OPERATION_FAILED', exception_type=type(exc).__name__)
            messages = {
                'configure': '設定と保存済み記録を確認してください。',
                'connect': '認証・権限・指定実機・ネットワークを確認してください。',
                'compile': 'コンパイルが完了しませんでした。実機の状態、依存パッケージと保存済み計画を確認してください。',
                'submit': '送信中に停止しました。一部のジョブがIBMで受理済みの可能性があります。submitted_jobs.jsonとsubmission_intent.jsonを削除せず、IBMのWorkloadsと照合してください。自動再送はしません。',
                'collect': '結果の取得／照合に失敗しました。完了済みのカウントは保持しています。再送せず、保存済みジョブIDを確認してください。',
                'analyse': '解析が完了しませんでした。最新解析フォルダのログとチェックポイントを確認してください。実測データはそのままです。',
                'report': '解析の完全性確認に失敗しました。結果を完成済みとして扱わないでください。',
                'export': '公開用ZIPの作成に失敗しました。元の測定データと解析は残しています。'}
            raise SequentialStop('OPERATION_FAILED_' + type(exc).__name__,
                                 messages[stage] + ' 生のSDK例外は秘密情報保護のため表示しません。') from None

    def _configure(self):
        cfg = self.cfg
        print('config.jsonの値を読み込みました。Enterは表示の既定値を使います。qは中止。')
        print('既存の測定を再開する場合は同じrun_id。新規実験だけ新しいrun_idです。')
        rid = _question(f'実験のrun_id [{cfg["experiment"]["run_id"]}]: ', _run_id,
                        default=cfg['experiment']['run_id'])
        cfg['experiment']['run_id'] = rid
        self.folder = _wf.acquisition_folder(cfg)
        saved_plan = self.folder / 'plan.json'
        records_exist = any((self.folder / n).exists() for n in
                            ('submitted_jobs.json', 'submission_intent.json', 'receiver_counts.json'))
        if records_exist and not saved_plan.exists():
            _stop('MISSING_COMPILED_PLAN', 'ジョブ／測定記録がありますがplan.jsonがありません。新規送信せず、実験フォルダ全体を復元してください。')
        snapshot = self.folder / 'sequential_config.json'
        if snapshot.exists() and saved_plan.exists():
            saved = _read_json(snapshot)
            # A run is pinned to its acquisition and execution. Analysis is pinned in this UI too.
            for key in ('experiment', 'execution', 'analysis'):
                if key not in saved:
                    _stop('CONFIG_SNAPSHOT_INVALID', '保存された設定記録を確認してください。')
                cfg[key] = saved[key]
            if cfg['experiment']['run_id'] != rid:
                _stop('RUN_ID_MISMATCH', '保存先と設定のrun_idが一致しません。')
            print('このrun_idの保存済み設定を再利用します（config.jsonの後からの変更は採用しません）。')
        elif saved_plan.exists():
            plan = _read_json(saved_plan)
            # Adopt the ACTUAL saved acquisition instead of silently changing it.
            p = plan['plan']
            cfg['experiment'].update(backend=plan['backend'], stage=p['stage'], shots=p['shots'], seed=p['seed'],
                physical_layout=plan['initial_layout'], direct_preparation_baseline=p['direct_preparation_baseline'],
                swap_transfer_baseline=p['swap_transfer_baseline'], readout_calibration=p['readout_calibration'],
                discarded_diagnostics=p['discarded_diagnostics'])
            print('既存のコンパイル済み計画を採用します。回路・shots・実機は変更しません。')
        else:
            cfg['experiment']['backend'] = _question(
                f'実機名 [{cfg["experiment"]["backend"]}]: ',
                lambda v: v if _re.fullmatch(r'ibm_[A-Za-z0-9_\-]+', v) else False,
                default=cfg['experiment']['backend'])
            cfg['experiment']['shots'] = _question(
                f'1回路あたりshots [{cfg["experiment"]["shots"]}]: ', _positive_int,
                default=cfg['experiment']['shots'])
        if cfg['experiment']['stage'] != 'full':
            _stop('FULL_REQUIRED', 'このノートブックは4資源のfull測定専用です。screenは使用しません。')
        a = cfg['analysis']
        if (a['solver'] != 'cvxpy' or not a['count_gof'] or not a['resume']
                or min(a['bootstraps'], a['gof_bootstraps']) < 500):
            _stop('PUBLICATION_ANALYSIS_REQUIRED', 'この初心者向け経路ではCVXPY、適合度検定、再開設定、各500回以上のブートストラップが必要です。config.jsonを確認してください。')
        if cfg['execution']['mode'] != 'job':
            _stop('JOB_MODE_REQUIRED', 'この順次実行版はjobモードを使用します。execution.modeをjobにしてください。')
        _ibm.require_allowed_backend(cfg['experiment']['backend'])
        with _operation_lock(self.folder):
            if saved_plan.exists():
                self._verify_plan()
            # No credential, account object, or original input path is written here.
            write_json(snapshot, {k: cfg[k] for k in ('experiment', 'execution', 'analysis')})
        print('実験:', rid, '| 実機:', cfg['experiment']['backend'], '| shots:', cfg['experiment']['shots'])
        print('保存先:', self.folder)
        print('config.jsonは書き換えません。この実験の設定はsequential_config.jsonへ保存します。')

    def _verify_plan(self):
        p = _read_json(self.folder / 'plan.json')
        rows = _read_json(self.folder / 'manifest.json')
        if p.get('backend') != self.cfg['experiment']['backend']:
            _stop('PLAN_BACKEND_MISMATCH', '設定と保存済み実機が一致しません。')
        from dataclasses import asdict
        if p.get('plan') != jsonable(asdict(_wf.experiment_plan(self.cfg))):
            _stop('PLAN_DESIGN_MISMATCH', '保存済みの測定設計と設定が一致しません。')
        if p.get('manifest_sha256') != _ibm._manifest_sha256(rows):
            _stop('MANIFEST_MISMATCH', '測定順序のハッシュが一致しません。')
        if p.get('code_hashes') != code_fingerprint():
            _stop('SCIENTIFIC_CODE_CHANGED', 'コンパイル後に科学計算用コードが変わっています。異なる版のデータを混ぜず、元のプログラムを復元してください。')
        for file, field in (('compiled_circuits.qpy', 'compiled_qpy_sha256'),
                            ('logical_circuits.qpy', 'logical_qpy_sha256')):
            if not (self.folder / file).is_file() or sha256(self.folder / file) != p.get(field):
                _stop('CIRCUIT_FILE_CHANGED', '保存済み回路が不足または変更されています。復元してください。')
        _ibm.validate_full_design(rows)
        if (p['budget']['circuits'] != len(rows)
                or p['budget']['total_requested_shots'] != sum(r['shots'] for r in rows)):
            _stop('PLAN_BUDGET_MISMATCH', '保存された回路数／shotsが一致しません。')
        self.plan = p
        return rows

    def _submission_state(self):
        idx = self.folder / 'submitted_jobs.json'
        intent_file = self.folder / 'submission_intent.json'
        if not idx.exists() and not intent_file.exists():
            return None
        if not idx.exists():
            _stop('UNCERTAIN_SUBMISSION', '送信開始記録はありますがジョブIDが未確定です。IBMで受理済みの可能性があるため再送しません。Workloadsとsubmission_intent.jsonを照合してください。')
        entries = _read_json(idx)
        if not isinstance(entries, list) or not entries:
            _stop('UNCERTAIN_SUBMISSION', 'ジョブ記録が空または不正です。自動再送しません。')
        n = self.plan['budget']['circuits']
        indices = []
        ids = []
        for e in entries:
            if (type(e.get('start')) is not int or type(e.get('stop')) is not int
                    or not 0 <= e['start'] < e['stop'] <= n
                    or e.get('backend') != self.plan['backend']
                    or not isinstance(e.get('job_id'), str)
                    or not _re.fullmatch(r'[A-Za-z0-9_-]+', e['job_id'])):
                _stop('JOB_RECORD_INVALID', '保存済みジョブの範囲・実機・識別子を確認してください。')
            indices.extend(range(e['start'], e['stop'])); ids.append(e['job_id'])
        if sorted(indices) != list(range(n)) or len(set(ids)) != len(ids):
            _stop('PARTIAL_OR_DUPLICATE_SUBMISSION', '送信記録に不足・重複があります。自動再送や部分データのfull扱いは行いません。既存ジョブをIBM画面と照合してください。')
        if intent_file.exists():
            intent = _read_json(intent_file)
            if (intent.get('manifest_sha256') != self.plan['manifest_sha256']
                    or intent.get('backend') != self.plan['backend']):
                _stop('SUBMISSION_INTENT_MISMATCH', '送信開始記録とコンパイル済み計画が一致しません。')
        return entries

    def _verify_collected(self):
        source = self.folder / 'receiver_counts.json'
        if not source.exists():
            return False
        rows = self._verify_plan()
        entries = self._submission_state()
        if entries is None:
            _stop('COUNTS_WITHOUT_JOBS', 'カウントはありますが実機ジョブ記録がありません。実測の由来を確認してください。')
        status = _read_json(self.folder / 'collection_status.json')
        data = _read_json(source)
        if (status.get('status') != 'HARDWARE_RESULTS_COLLECTED'
                or status.get('receiver_counts_sha256') != sha256(source)
                or data.get('data_kind') != 'HARDWARE'
                or data.get('manifest_sha256') != self.plan['manifest_sha256']
                or data.get('backend') != self.plan['backend']
                or data.get('receiver_bit_order') != 'q4 q3'
                or data.get('acquisition_id') != self.folder.name):
            _stop('HARDWARE_COUNTS_INVALID', '実測カウントの状態・ハッシュ・順序・実機が一致しません。人工データへ置き換えず、保存済みカウントを確認してください。')
        records = data.get('records', [])
        if len(records) != len(rows) or [r.get('acquisition_index') for r in records] != list(range(len(rows))):
            _stop('COUNTS_COVERAGE_INVALID', '取得データの回路数または順序が不完全です。')
        _ibm.validate_full_design(records)
        by_index = {i: e['job_id'] for e in entries for i in range(e['start'], e['stop'])}
        total = 0
        for i, (r, expected) in enumerate(zip(records, rows)):
            if any(r.get(k) != v for k, v in expected.items()):
                _stop('COUNTS_MANIFEST_MISMATCH', 'カウントと測定計画の対応が不一致です。')
            counts = r.get('counts', {})
            if (set(counts) - {'00', '01', '10', '11'}
                    or any(type(v) is not int or v < 0 for v in counts.values())
                    or sum(counts.values()) != expected['shots']
                    or r.get('hardware_job_id') != by_index[i]
                    or r.get('backend') != self.plan['backend']):
                _stop('COUNTS_VALUES_INVALID', 'カウント／shots／実機ジョブ対応が不正です。')
            total += sum(counts.values())
        if total != self.plan['budget']['total_requested_shots']:
            _stop('COUNTS_SHOTS_INVALID', '総shotsが計画と一致しません。')
        if self.cfg['experiment']['discarded_diagnostics'] and not (self.folder / 'joint_discarded_counts.json').exists():
            _stop('JOINT_COUNTS_MISSING', '破棄レジスタのデータが不足しています。元の取得フォルダ全体を復元してください。')
        return True

    def _connect(self):
        if self._verify_collected():
            print('取得済みの完全なカウントを確認しました。今回はIBMへ接続せずローカル解析へ進めます。')
            return
        # The previous auth guard validates both fields and suppresses raw SDK auth logs.
        for attempt in range(3):
            try:
                self.service = connect_runtime_checked(prompt_for_credentials=True, max_attempts=3)
                break
            except RuntimeConnectionIssue as exc:
                print(f'接続確認 [{exc.code}]: {exc.public_message}')
                if exc.code in {'AUTH_INPUT_CANCELLED', 'HIDDEN_INPUT_UNAVAILABLE'} or attempt == 2:
                    raise
                answer = _question('このセル内で認証をやり直す場合は retry、中止は q: ',
                                   lambda v: v if v == 'retry' else False)
        # Do not print a service object or saved_accounts(): they may expose identifiers.
        if self.plan is not None and self._submission_state() is not None:
            print('保存済みジョブの取得用に接続しました。実機の現在の稼働状態にかかわらず既存ジョブを照会します。')
            return
        check = check_runtime_backend(self.service, self.cfg['experiment']['backend'])
        if check['status'] != 'CONNECTION_CHECK_PASSED_NO_JOB_SUBMITTED':
            _stop('BACKEND_NOT_READY', '指定実機が稼働中でないか量子ビットが不足しています。実機を勝手に変更せず停止します。')
        with _quiet_auth_sdk():
            backend = self.service.backend(self.cfg['experiment']['backend'])
            if getattr(backend.configuration(), 'simulator', False):
                _stop('SIMULATOR_NOT_ALLOWED', '実機測定にはシミュレータを使用できません。')
        print('認証・指定実機を確認しました。この時点ではQPUジョブを送信していません。')

    @_contextmanager
    def _progress(self, label):
        event = _threading.Event()
        start = _time.monotonic()
        def monitor():
            while not event.wait(self.progress_seconds):
                note = ''
                try:
                    if label == '解析':
                        latest = self.folder / 'latest_analysis.json'
                        if latest.exists():
                            ad = ROOT / _read_json(latest)['analysis_directory']
                            p = ad / 'network' / 'analysis_progress.json'
                            if p.exists():
                                d = _read_json(p)
                                note = f' | state={d.get("phase_rows", "-")}, process={d.get("completed_process_fits", "-")}, gof={d.get("completed_gof_fits", "-")}'
                            checkpoints = ad / 'network' / 'checkpoints'
                            if checkpoints.exists():
                                note += f' | 保存済みチェックポイント={len(list(checkpoints.glob("*.json")))}'
                    elif label == '送信':
                        p = self.folder / 'submitted_jobs.json'
                        if p.exists(): note = f' | 保存済みジョブID={len(_read_json(p))}'
                except Exception:
                    pass
                self._emit(f'{label}処理中（経過{int(_time.monotonic()-start)}秒）{note}。同じセルを重ねて実行しないでください。')
        worker = _threading.Thread(target=monitor, name='local-progress-only', daemon=True)
        worker.start()
        try:
            yield
        finally:
            event.set(); worker.join(timeout=2)

    def _compile(self):
        with _operation_lock(self.folder):
            if (self.folder / 'plan.json').exists():
                self._verify_plan()
                print('保存済みの計画・回路ハッシュを確認。再コンパイルせず再利用します。')
            else:
                if any((self.folder / n).exists() for n in ('compiled_circuits.qpy', 'logical_circuits.qpy', 'submitted_jobs.json', 'submission_intent.json')):
                    _stop('INCOMPLETE_COMPILE_ARTIFACTS', '途中までのコンパイル／送信記録があります。上書きせず確認してください。')
                if self.service is None:
                    _stop('CONNECTION_REQUIRED', '接続が確認できていません。')
                prepared = _wf.prepare_followup(self.cfg)
                print('4資源full計画の回路数（較正追加前）:', prepared['budget']['circuits_before_backend_specific_readout_calibration'])
                print('実機向け回路をコンパイルします。まだ測定ジョブは送信しません。')
                with self._progress('コンパイル'), _quiet_auth_sdk():
                    _wf.compile_followup(self.service, self.cfg)
                self._verify_plan()
        p = self.plan
        print('コンパイル済みの回路数:', f'{p["budget"]["circuits"]:,}')
        print('総shots（較正を含む）:', f'{p["budget"]["total_requested_shots"]:,}')
        print('次は送信済み記録の照合、または新規送信の明示的な承認です。')

    def _submit(self):
        with _operation_lock(self.folder):
            self._verify_plan()
            entries = self._submission_state()
            if entries is not None:
                print(f'{len(entries)}件の送信済みジョブを確認しました。新規送信せず、その結果を取得します。')
                return
            if (self.folder / 'receiver_counts.json').exists():
                _stop('COUNTS_WITHOUT_JOBS', 'カウントだけが存在します。新規送信せず由来を確認してください。')
            p = self.plan
            total = p['budget']['total_requested_shots']
            n = p['budget']['circuits']
            ex = self.cfg['execution']
            chunks = _math.ceil(n / ex['max_circuits_per_job'])
            print(f'送信先: {p["backend"]} | run_id: {self.folder.name}')
            print(f'回路数 {n:,} / 総shots {total:,} / 分割ジョブ予定 {chunks}')
            print('QPU利用枠を消費し、契約により課金されます。料金／利用枠はIBM画面で確認してください。')
            print('shots数と各ジョブの時間上限は、料金上限や全体の実行時間の保証ではありません。')
            print('ここで承認すると、全ジョブ送信→自動取得→ローカル解析へ順に進みます。')
            token = p['submission_authorization_token']
            print('今回の計画の承認文字列:', token)
            approval = _question('利用枠・費用と計画を確認済みの場合だけ、上の SUBMIT-... をコピーして入力（qで中止）: ',
                                 lambda v: v if v == token else False)
            _question('総shotsを桁区切りなしの整数で入力（qで中止）: ',
                      lambda v: int(v) if v.isdecimal() and int(v) == total else False)
            # Exactly one submission call. Never retry, including after ambiguous network errors.
            with self._progress('送信'), _quiet_auth_sdk():
                status = _wf.submit_followup(self.service, approval, total, self.cfg)
            if status.get('status') != 'SUBMITTED_NOT_YET_MEASURED':
                _stop('SUBMISSION_NOT_CONFIRMED', '送信が完全に終わったことを確認できません。保存されたジョブIDを確認してください。')
            entries = self._submission_state()
            print(f'送信完了：{len(entries)}件。submitted_jobs.jsonへIDを保存しました。')
            print('続く結果取得セルが待機状態を自動確認します。submitを再実行する必要はありません。')

    def _collect(self):
        with _operation_lock(self.folder):
            if self._verify_collected():
                print('取得済みカウントを検証しました。再取得・新規送信はしません。')
                return
            if self.service is None:
                _stop('CONNECTION_REQUIRED', '結果の取得には接続が必要です。')
            if self._submission_state() is None:
                _stop('JOBS_REQUIRED', '送信済みジョブがありません。')
            print('全ジョブの結果がそろうまで、このセル内で状態を確認します。')
            print('待機中は次のセルを実行せず、Pythonカーネルを起動したままにしてください。')
            print('中断はKernel → Interrupt。中断してもクラウドのジョブはキャンセルされません。')
            start = _time.monotonic(); errors = 0
            while True:
                try:
                    with _quiet_auth_sdk():
                        status = _wf.collect_followup(self.service, self.cfg, wait=False)
                    errors = 0
                except Exception as exc:
                    # Only well-defined network errors are retried, and only during GET-like collection.
                    names = {t.__name__ for t in type(exc).__mro__}
                    transient = bool(names & {'ConnectionError','ConnectTimeout','ReadTimeout','Timeout','TimeoutError','ConnectionResetError'})
                    if not transient or errors >= 4:
                        raise
                    errors += 1
                    print(f'取得時の一時的な通信エラー。読み取りだけを再試行します（{errors}/4）。新規送信はしません。', flush=True)
                    _time.sleep(self.poll_seconds)
                    continue
                if status.get('status') == 'HARDWARE_RESULTS_COLLECTED':
                    if not self._verify_collected():
                        _stop('COLLECTION_NOT_VALID', '取得後の完全性検査に失敗しました。')
                    print('全実測カウントの取得・完全性検査が完了しました。')
                    print('保存:', self.folder / 'receiver_counts.json')
                    return
                if status.get('status') != 'PENDING_HARDWARE_JOBS':
                    _stop('UNEXPECTED_COLLECTION_STATUS', '取得処理が予期しない状態です。記録を確認してください。')
                counts = _Counter(j.get('status', 'UNKNOWN') for j in status.get('pending_jobs', []))
                print(f'取得済み {status.get("completed_circuits", 0)}/{self.plan["budget"]["circuits"]} 回路 | 未完了ジョブ {dict(counts)} | 待機経過 {int(_time.monotonic()-start)}秒', flush=True)
                self._record('collect', 'WAITING', completed_circuits=status.get('completed_circuits',0), pending_status_counts=dict(counts))
                if self.max_wait_hours is not None and _time.monotonic() - start >= 3600*self.max_wait_hours:
                    _stop('LOCAL_WAIT_LIMIT', '設定したローカル待機時間に達しました。クラウドジョブは継続します。後で同じrun_idで上から再開すれば、再送せず取得を続けます。')
                _time.sleep(self.poll_seconds)

    def _validate_analysis(self):
        status_file = self.folder / 'notebook_02_status.json'
        if not status_file.exists():
            return None
        status = _read_json(status_file)
        if status.get('status') != 'ANALYSIS_COMPLETED_AUTHOR_INTERPRETATION_REQUIRED' or status.get('data_kind') != 'HARDWARE':
            return None
        adir = (ROOT / status['analysis_directory']).resolve()
        if not adir.is_relative_to((self.folder / 'analyses').resolve()):
            _stop('ANALYSIS_PATH_INVALID', '解析フォルダが今回の実験内にありません。')
        net = adir / 'network'
        signature = _read_json(net / 'analysis_signature.json')
        a = self.cfg['analysis']
        expected = {'input_sha256':sha256(self.folder/'receiver_counts.json'), 'code_hashes':code_fingerprint(),
                    'protocol':'network','bootstraps':a['bootstraps'],'seed':a['seed'],'solver':a['solver'],
                    'gof_bootstraps':a['gof_bootstraps'],'count_gof':a['count_gof']}
        if signature != expected:
            return None  # Different analysis signature: workflow creates a separate analysis directory.
        s = _read_json(net / 'analysis_status.json')
        if (s.get('data_kind') != 'HARDWARE' or s.get('status') != 'ANALYSED' or s.get('warnings')
                or (s.get('phase_rows'),s.get('process_rows'),s.get('gof_rows')) != (48,32,32)):
            return None
        tables = {}
        for filename, count in [('measured_state_phases_concurrence.csv',48),
                                 ('measured_cptni_fits.csv',32),('count_level_gof.csv',32)]:
            path = net / filename
            if not path.is_file(): return None
            with path.open(encoding='utf-8-sig',newline='') as stream:
                rows = list(_csv.DictReader(stream))
            if len(rows) != count or any(r.get('data_kind') != 'HARDWARE' for r in rows): return None
            tables[filename] = rows
        for filename, recoveries in [('measured_state_phases_concurrence.csv',('raw','physical','frame_tracked')),
                                     ('measured_cptni_fits.csv',('physical','frame_tracked')),
                                     ('count_level_gof.csv',('physical','frame_tracked'))]:
            actual = _Counter((int(r['M1']),int(r['M2']),int(r['x']),int(r['m']),r['recovery']) for r in tables[filename])
            expected_keys = _Counter(_itertools.product((0,1),(0,1),(0,1),(0,1),recoveries))
            if actual != expected_keys: return None
        # Core exporters store matrix/sample paths alongside each estimate.
        for filename in ('measured_state_phases_concurrence.csv','measured_cptni_fits.csv'):
            for row in tables[filename]:
                for field in ('matrix_file','bootstrap_file'):
                    p = (net / row.get(field,'')).resolve()
                    if not row.get(field) or not p.is_relative_to(net.resolve()) or not p.is_file(): return None
        self.analysis_dir = adir
        return status

    def _analyse(self):
        with _operation_lock(self.folder):
            if not self._verify_collected():
                _stop('NO_FULL_COUNTS', '完全な実測カウントがありません。解析へ進みません。')
            status = self._validate_analysis()
            if status is not None:
                print('同じデータ・設定・コードの解析が完了済みです。再計算せず結果を確認します。')
                return
            print('位相・コンカレンス・チャネル・適合度検定を解析します。新しいQPUジョブは送信しません。')
            with self._progress('解析'):
                status = _wf.analyse_followup(self.cfg)
            if status.get('status') != 'ANALYSIS_COMPLETED_AUTHOR_INTERPRETATION_REQUIRED' or self._validate_analysis() is None:
                _stop('ANALYSIS_INCOMPLETE', '必要な48行の状態評価・32行のチャネル・32行の適合度検定がそろっていません。未完了として停止します。')
            print('解析が完了し、CSV・行列・ブートストラップ標本の対応を確認しました。')

    def _report(self):
        if self._validate_analysis() is None:
            _stop('ANALYSIS_INCOMPLETE', 'この実験の完全な解析を確認できません。')
        from IPython.display import display, HTML
        from html import escape
        net = self.analysis_dir / 'network'
        with (net / 'measured_state_phases_concurrence.csv').open(encoding='utf-8-sig', newline='') as stream:
            state = list(_csv.DictReader(stream))
        columns = [c for c in ['M1','M2','x','m','recovery','phase_rad','phase_rad_lo','phase_rad_hi',
                              'ideal_phase_rad','concurrence','concurrence_lo','concurrence_hi'] if c in state[0]]
        table = '<table><thead><tr>' + ''.join('<th>'+escape(c)+'</th>' for c in columns) + '</tr></thead><tbody>'
        for row in state:
            table += '<tr>' + ''.join('<td>'+escape(str(row.get(c,'')))+'</td>' for c in columns) + '</tr>'
        display(HTML(table + '</tbody></table>'))
        print('48行 = 補正前16 + 物理補正後16 + 補正前から計算したフレーム追跡16。')
        print('位相区間の空欄は0で補完しません。phase_warningを確認してください。')
        print('区間は単一取得の計数誤差であり、SPAM・較正・装置ドリフトをすべて含む保証ではありません。')
        for name in ('measured_state_phases_concurrence.csv','measured_phase_comparison.csv',
                     'measured_recovery_comparison.csv','measured_cptni_fits.csv','count_level_gof.csv'):
            path = net / name
            if path.is_file():
                print(path.relative_to(ROOT))
        print('保存先:', self.analysis_dir)
        print('論文への掲載前に、数値・区間・診断・実験の限界を著者が確認してください。')

    def _export(self):
        with _operation_lock(self.folder):
            if not self._verify_collected() or self._validate_analysis() is None:
                _stop('EXPORT_REQUIRES_COMPLETE_CURRENT_RUN', '今回の実験の完全な実測解析がありません。完成済みZIPは作りません。')
            from publication_export import make_release, readiness
            ready = readiness()
            this = next((r for r in ready['runs'] if r['run_id'] == self.folder.name), {})
            if not this.get('complete_four_resource_analysis'):
                _stop('CURRENT_RUN_NOT_READY', '別実験ではなく今回のrun_idの完全性が必要です。')
            # Snapshot code actually used by this notebook is embedded, not fetched remotely.
            print('ローカルの提出用／GitHub用ZIPを作成します。オンライン投稿はしません。')
            result = make_release()
            if result.get('status') != 'LOCAL_BUNDLES_CREATED_NOT_UPLOADED':
                _stop('EXPORT_INCOMPLETE', 'ZIP作成が正常に終了していません。')
            for item in result['bundles']:
                p = ROOT / item['file']
                if not p.is_file() or sha256(p) != item['sha256']:
                    _stop('EXPORT_HASH_MISMATCH', '書き出したZIPの検査に失敗しました。')
            # Written after exports intentionally: terminal marker does not claim inclusion in those ZIPs.
            write_json(self.folder / 'sequential_completion.json', {
                'status':'RESULTS_AND_LOCAL_EXPORTS_READY_FOR_AUTHOR_REVIEW',
                'run_id':self.folder.name,'data_kind':'HARDWARE','updated_utc':utc_now(),
                'analysis_directory':self.analysis_dir.relative_to(ROOT).as_posix(),
                'bundles':result['bundles'],
                'limitations':'Not a guarantee of experimental agreement, interval coverage, paper acceptance, or online publication.'})
            print('RESULTS_AND_LOCAL_EXPORTS_READY_FOR_AUTHOR_REVIEW')
            for item in result['bundles']:
                print('ZIP:', ROOT / item['file'])
            print('全数値はResults内に保存済みです。APIキーを含むファイルを公開しないでください。')

"""Python/Jupyter preflight checks; no cloud connection and no credential reads."""
from __future__ import annotations

from importlib import import_module
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
import json
import os
import platform
import sys

ROOT = Path(__file__).resolve().parent
OFFLINE = {
    "numpy": "numpy", "scipy": "scipy", "nbformat": "nbformat",
    "nbclient": "nbclient", "ipykernel": "ipykernel", "pytest": "pytest",
}
QUANTUM = {
    "qiskit": "qiskit", "qiskit-ibm-runtime": "qiskit_ibm_runtime",
    "cvxpy": "cvxpy", "scs": "scs",
}


def check_environment(profile: str = "offline", *, import_packages: bool = True) -> dict:
    """Report installed/importable requirements without reading saved IBM accounts."""
    if profile not in {"offline", "quantum"}:
        raise ValueError("profile must be offline or quantum")
    requirements = dict(OFFLINE)
    if profile == "quantum":
        requirements.update(QUANTUM)
    packages, missing, broken = {}, [], []
    for dist, module in requirements.items():
        try:
            packages[dist] = version(dist)
        except PackageNotFoundError:
            packages[dist] = None
            missing.append(dist)
            continue
        if import_packages:
            try:
                import_module(module)
            except Exception as exc:
                # Exception messages may include local service/proxy settings; omit them.
                broken.append({"package": dist, "exception_type": type(exc).__name__})
    solver_present = None
    if profile == "quantum" and not any(r["package"] == "cvxpy" for r in broken) and packages.get("cvxpy"):
        try:
            import cvxpy
            solver_present = "SCS" in cvxpy.installed_solvers()
        except Exception:
            solver_present = False
    python_ok = sys.version_info >= (3, 11)
    valid = python_ok and not missing and not broken and solver_present is not False
    return {
        "status": "READY" if valid else "ENVIRONMENT_REQUIRES_ATTENTION",
        "profile": profile,
        "python_version": platform.python_version(),
        "python_executable": sys.executable,
        "python_prefix": sys.prefix,
        "project_root": str(ROOT),
        "results_directory": str(ROOT / "Results"),
        "minimum_python": "3.11",
        "python_supported": python_ok,
        "packages": packages,
        "missing_packages": missing,
        "import_failures": broken,
        "scs_solver_available": solver_present,
        "no_cloud_connection": True,
    }


def initialize_notebook(notebook_name: str) -> dict:
    """Require the chosen local venv when present and record a per-notebook preflight."""
    if not (ROOT / "revision_project.json").is_file():
        raise FileNotFoundError("revision_project.json is missing. Extract the entire package.")
    if sys.version_info < (3, 11):
        raise RuntimeError("Python 3.11 or newer is required. See readme_fixed.md (Python 3.12 recommended).")
    local_venv = ROOT / ".venv"
    if (local_venv / "pyvenv.cfg").is_file() and Path(sys.prefix).resolve() != local_venv.resolve():
        raise RuntimeError(
            "This notebook is using a different Python environment. Select Kernel > Change Kernel > "
            "Python (Revision fixed5), then restart the kernel. Expected: " + str(local_venv)
        )
    # Do not modify the global Julia/IJulia or Python configuration.
    cache = ROOT / "Results" / "_cache"
    os.environ.setdefault("MPLCONFIGDIR", str(cache / "matplotlib"))
    sys.dont_write_bytecode = True
    report = check_environment("offline")
    if report["status"] != "READY":
        raise RuntimeError(
            "Offline dependencies are missing or cannot be imported. Run setup_jupyter.py "
            "with the intended Python, then select Python (Revision fixed5). Missing: "
            + ", ".join(report["missing_packages"])
            + "; import failures: " + str(report["import_failures"])
        )
    from workflow_paths import output_path, utc_now, write_json
    report["checked_utc"] = utc_now()
    report["notebook"] = notebook_name
    destination = output_path("Environment", directory=True)
    write_json(destination / (Path(notebook_name).stem + "_environment.json"), report)
    return report


def main() -> int:
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", choices=("offline", "quantum"), default="quantum")
    args = parser.parse_args()
    report = check_environment(args.profile)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    destination = ROOT / "Results" / "Environment"
    destination.mkdir(parents=True, exist_ok=True)
    (destination / (args.profile + "_preflight.json")).write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return 0 if report["status"] == "READY" else 1


if __name__ == "__main__":
    raise SystemExit(main())

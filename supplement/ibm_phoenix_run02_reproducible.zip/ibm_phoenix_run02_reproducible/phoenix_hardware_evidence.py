"""Offline verification and extraction of saved IBM Phoenix hardware counts.

Counts are never synthesized. A missing or inconsistent acquisition raises.
"""
from __future__ import annotations
from pathlib import Path
from collections import Counter
import csv, hashlib, json, math

RUN_ID = "full_4resources_run02"
BACKEND = "ibm_phoenix"

def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def sha256(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda:stream.read(1024*1024),b""):
            h.update(block)
    return h.hexdigest()

def verify_config(root):
    config=load_json(Path(root)/"config.json")
    e=config["experiment"]
    for name, expected in {"stage":"full", "run_id":RUN_ID,"backend":BACKEND}.items():
        if e.get(name)!=expected:
            raise ValueError(f"Experiment requires {name}={expected}, found {e.get(name)}")
    return config

def verify_saved_hardware(root,check_raw=True):
    root=Path(root).resolve()
    cfg=verify_config(root)
    folder=root/"Results"/"02_hardware"/RUN_ID
    source=folder/"receiver_counts.json"
    collection=load_json(folder/"collection_status.json")
    bundle=load_json(source)
    manifest=load_json(folder/"manifest.json")
    plan=load_json(folder/"plan.json")
    jobs=load_json(folder/"submitted_jobs.json")
    recorded=load_json(folder/"submission_intent.json")
    if collection.get("status")!="HARDWARE_RESULTS_COLLECTED":
        raise ValueError("Hardware collection is not marked complete")
    digest=sha256(source)
    if digest!=collection.get("receiver_counts_sha256"):
        raise ValueError("Saved hardware counts hash mismatch")
    if bundle.get("data_kind")!="HARDWARE" or bundle.get("acquisition_id")!=RUN_ID or bundle.get("backend")!=BACKEND:
        raise ValueError("Not the requested IBM hardware data")
    entries=bundle.get("records",[])
    if len(entries)!=1746 or collection.get("circuits")!=len(entries):
        raise ValueError("Incomplete or unexpectedly sized hardware count inventory")
    valid_job_ids={item["job_id"] for item in jobs}
    if len(jobs)!=6 or set(bundle.get("job_ids",[]))!=valid_job_ids:
        raise ValueError("Stored IBM job IDs are missing or inconsistent")
    if plan.get("manifest_sha256")!=bundle.get("manifest_sha256"):
        raise ValueError("Manifest fingerprint differs from the count record")
    manifest_digest=hashlib.sha256(json.dumps(manifest,sort_keys=True,separators=(",", ":")).encode()).hexdigest()
    if manifest_digest!=plan.get("manifest_sha256"):
        raise ValueError("Original manifest contents do not match its signature")
    if recorded.get("status")!="ALL_CHUNKS_SUBMITTED" or recorded.get("backend")!=BACKEND:
        raise ValueError("Stored job submission provenance inconsistent")
    protocol_count=Counter()
    shot_total=0
    for n,row in enumerate(entries):
        if row.get("backend")!=BACKEND or row.get("acquisition_id")!=RUN_ID:
            raise ValueError(f"Non-hardware or different-backend row at {n}")
        if row.get("hardware_job_id") not in valid_job_ids:
            raise ValueError(f"Unknown IBM job ID in row {n}")
        shots=row.get("shots")
        counts=row.get("counts")
        if not isinstance(shots,int) or shots!=cfg["experiment"]["shots"] or not isinstance(counts,dict):
            raise ValueError(f"Wrong shots/counts structure in row {n}")
        if not counts or any(not isinstance(v,int) or v<0 for v in counts.values()) or sum(counts.values())!=shots:
            raise ValueError(f"Shot-conservation failure in row {n}")
        if any(not isinstance(k,str) or any(bit not in "01" for bit in k) for k in counts):
            raise ValueError(f"Unexpected count key in row {n}")
        protocol_count[row["protocol"]]+=1
        shot_total+=shots
        if check_raw:
            original=load_json(folder/"raw_counts"/f"{n:05d}.json")
            if original!=row:
                raise ValueError(f"Raw QPU count file {n:05d}.json differs from normalized record")
    expected={"network":1440,"discarded_diagnostic":192,"direct_preparation":45,"swap_transfer":45,"readout_calibration":24}
    if dict(protocol_count)!=expected:
        raise ValueError(f"Unexpected measurement protocol inventory: {dict(protocol_count)}")
    if shot_total!=7151616 or shot_total!=collection.get("shots") or shot_total!=recorded.get("total_requested_shots"):
        raise ValueError("Total shots do not match the collection/submission record")
    return {"status":"VERIFIED_SAVED_IBM_HARDWARE_COUNTS", "data_kind":"HARDWARE", "backend":BACKEND,
            "stage":"full", "run_id":RUN_ID,"circuits":len(entries),"shots":shot_total,
            "sha256":digest,"job_ids":sorted(valid_job_ids),"protocols":dict(sorted(protocol_count.items())),
            "raw_files_checked":len(entries) if check_raw else 0,"receiver_bit_order":bundle.get("receiver_bit_order"),
            "new_qpu_jobs_submitted":0,"verification_mode":"offline-preserved-hardware-evidence"}

def export_count_table(root,filename=None):
    root=Path(root).resolve()
    evidence=verify_saved_hardware(root,check_raw=True)
    rows=load_json(root/"Results"/"02_hardware"/RUN_ID/"receiver_counts.json")["records"]
    path=Path(filename) if filename else root/"Results"/"Review_Outputs"/"hardware_counts_1746_circuits.csv"
    path.parent.mkdir(parents=True,exist_ok=True)
    keys=["acquisition_index","protocol","resource","sector","recovery","probe","basis",
          "calibration_epoch","hardware_job_id","backend","shots","count_00","count_01","count_10","count_11"]
    with path.open("w",newline="",encoding="utf-8") as stream:
        w=csv.DictWriter(stream,fieldnames=keys);w.writeheader()
        for row in rows:
            d={k:row.get(k,"") for k in keys if not k.startswith("count_")}
            for col in ("resource","sector"):
                if isinstance(d.get(col),list):d[col]="".join(str(v) for v in d[col])
            for bit in ("00","01","10","11"):
                d["count_"+bit]=row["counts"].get(bit,0)
            w.writerow(d)
    return path,evidence

"""Full nine-basis receiver tomography and leakage-aware CP-TNI reconstruction.

Only explicitly typed real counts may produce measured_*.csv; synthetic fixtures
produce synthetic_*.csv. All generated paths are restricted to Results/.
Raw coherence is reported in BOTH the ordered branch (u,v) and fixed-code bases.
Physical recovery is a separate acquisition; frame tracking reuses the raw counts.
"""
from __future__ import annotations
import argparse, csv, hashlib, itertools, json
from pathlib import Path
import numpy as np
from quantum_core import (I,X,Y,Z,PAULI,PROBES,SETTINGS,encoding,frame,raw_basis,
    tomography,resample_counts,concurrence,circular_interval,choi_from_blocks,
    effect_transpose,apply_choi,CPTNIFitter)
from workflow_paths import validate_output,write_json,sha256,code_fingerprint,environment_record

BITS=('00','01','10','11')
CAVEAT=('95% multinomial percentile counting interval, conditional on this acquisition; '
        'PSD/CP boundaries may bias coverage; no SPAM, drift, or calibration uncertainty.')


def write_csv(path,rows,fieldnames=None):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    keys=fieldnames or list(dict.fromkeys(k for r in rows for k in r))
    if not keys: keys=['status']
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore');w.writeheader()
        for r in rows:
            w.writerow({k:('' if v is None or isinstance(v,(float,np.floating)) and not np.isfinite(v) else v) for k,v in r.items()})


def _seed(seed,key):
    return int.from_bytes(hashlib.sha256((str(seed)+repr(key)).encode()).digest()[:8],'little')


def _label(key):
    acquisition,M1,M2,x,m,mode,*probe=key
    name=probe[0] if probe else 'process'
    name={'+':'plus','+i':'plus_i'}.get(name,name)
    return f'M{M1}{M2}_x{x}m{m}_{mode}_{name}_'+hashlib.sha256(acquisition.encode()).hexdigest()[:8]


def load_groups(path,protocol='network'):
    data=json.loads(Path(path).read_text(encoding='utf-8'))
    if data.get('schema_version')!=1 or data.get('data_kind') not in ('HARDWARE','SYNTHETIC_TEST'):
        raise ValueError('schema_version=1 and explicit HARDWARE or SYNTHETIC_TEST are required')
    if data.get('receiver_bit_order','q4 q3')!='q4 q3':raise ValueError('Expected receiver bit order q4 q3')
    if data.get('input_code_y',0)!=0:raise ValueError('This acquisition/analysis design uses input code C_0 only')
    groups={};provenance={};records=data.get('records',[])
    for r in records:
        if r.get('protocol','network')!=protocol:continue
        r=dict(r)
        if protocol!='network' and r['recovery']=='none':r['recovery']='physical'
        if r['recovery'] not in ('raw','physical'):continue
        M1,M2=r['resource'];x,m=r['sector']
        if any(type(v) not in (int,bool) or v not in (0,1) for v in (M1,M2,x,m)):raise ValueError('Nonbinary labels')
        if r['probe'] not in PROBES or r['basis'] not in SETTINGS:raise ValueError('Unknown probe/basis')
        acq=str(r.get('acquisition_id',data.get('acquisition_id',r['job_id'])))
        key=(acq,M1,M2,x,m,r['recovery'],r['probe'])
        dd=r['counts']
        if not dd or set(dd)-set(BITS) or any(type(v) is not int or v<0 for v in dd.values()) or sum(dd.values())<=0:
            raise ValueError('Counts must contain nonnegative integers on q4q3 bit strings')
        if r.get('shots',sum(dd.values()))!=sum(dd.values()):raise ValueError('Declared shots differ from counts')
        current=groups.setdefault(key,{})
        if r['basis'] in current:raise ValueError('Duplicate setting. Use separate acquisition IDs for repeats; no silent pooling.')
        current[r['basis']]={b:dd.get(b,0) for b in BITS}
        prov=provenance.setdefault(key,{'hardware_job_ids':set(),'backends':set(),'circuit_indices':[]})
        prov['hardware_job_ids'].add(str(r.get('hardware_job_id',r['job_id'])))
        prov['backends'].add(str(r.get('backend',data.get('backend','not_recorded'))))
        prov['circuit_indices'].append(r.get('acquisition_index',r.get('manifest_index')))
    if not groups:raise ValueError('No records for protocol '+protocol)
    for key,prov in provenance.items():
        if len(prov['backends'])!=1:raise ValueError('Different backends must not be combined in one tomography group')
    return data,groups,provenance


def state_metrics(rho,x,m,M1,M2,mode):
    psi=encoding()@PROBES['chi'];C=frame(x,m,M1,M2)
    raw=mode=='raw';yc=x^M1^M2 if raw else 0
    u,v=raw_basis(x,m,M1,M2) if raw else (0,3)
    a,b=(2*yc,2*(1-yc)+1)
    c=rho[u,v];fixed=rho[a,b]
    tracked=C.conj().T@rho@C if raw else rho
    target=C@psi if raw else psi
    ideal=float(np.angle(np.exp(1j*(-np.pi/3+np.pi*M2)))) if raw else -np.pi/3
    fixed_ideal=(-1)**(m^M1^M2)*ideal if raw else ideal
    fixed_ideal=float(np.angle(np.exp(1j*fixed_ideal)))
    phase=float(np.angle(c)) if abs(c)>1e-12 else np.nan
    fixedphase=float(np.angle(fixed)) if abs(fixed)>1e-12 else np.nan
    trphase=float(np.angle(tracked[0,3])) if abs(tracked[0,3])>1e-12 else np.nan
    p=float(np.trace(encoding(yc).conj().T@rho@encoding(yc)).real)
    pt=rho.reshape(2,2,2,2).transpose(0,3,2,1).reshape(4,4)
    return {'fidelity':float((target.conj()@rho@target).real),'code_population':p,'leakage':1-p,
        'phase_rad':phase,'phase_fixed_code_rad':fixedphase,'tracked_phase_rad':trphase,
        'ideal_phase_rad':ideal,'ideal_fixed_code_phase_rad':fixed_ideal,'ideal_recovered_phase_rad':-np.pi/3,
        'phase_error_rad':float(np.angle(np.exp(1j*(phase-ideal)))),
        'tracked_phase_error_rad':float(np.angle(np.exp(1j*(trphase+np.pi/3)))),
        'coherence_real':float(c.real),'coherence_imag':float(c.imag),'abs_coherence':float(abs(c)),
        'tracked_coherence_real':float(tracked[0,3].real),'tracked_coherence_imag':float(tracked[0,3].imag),
        'concurrence':concurrence(rho),'ideal_concurrence':float(2*np.sqrt(.21)),
        'negativity':float(-np.minimum(np.linalg.eigvalsh(pt),0).sum()),
        'purity':float(np.trace(rho@rho).real),'raw_code_y':x^M1^M2,'evaluation_code_y':yc,
        'recovered_code_y':0,'coherence_row':format(u,'02b'),'coherence_col':format(v,'02b')}


def add_intervals(row,reps):
    metrics=('fidelity','code_population','leakage','abs_coherence','coherence_real','coherence_imag',
             'concurrence','negativity','purity','phase_rad','phase_fixed_code_rad','tracked_phase_rad',
             'phase_error_rad','tracked_phase_error_rad')
    for metric in metrics:
        rr=np.array([r[metric] for r in reps],float)
        if not np.isfinite(rr).all() or not np.isfinite(row[metric]):lo=hi=np.nan
        elif 'phase' in metric:lo,hi=circular_interval(rr,row[metric])
        else:lo,hi=np.quantile(rr,[.025,.975])
        row[metric+'_lo']=float(lo);row[metric+'_hi']=float(hi)
    angles=np.array([d['phase_rad'] for d in reps],float)
    row['phase_resultant_length']=float(abs(np.mean(np.exp(1j*angles)))) if np.isfinite(angles).all() else 0.
    xy=np.array([[d['coherence_real'],d['coherence_imag']] for d in reps]);cov=np.cov(xy.T)
    point=np.array([row['coherence_real'],row['coherence_imag']])
    distance=float(point@np.linalg.pinv(cov)@point)
    identified=bool(row['abs_coherence']>1e-10 and distance>5.991 and row['phase_resultant_length']>.8)
    row['phase_localized_approximate_check']=identified
    row['phase_origin_wald_distance_squared']=distance
    row['phase_interval_method']='local circular percentile, unwrapped around estimate; limits may exceed +/-pi'
    if not identified:
        for metric in metrics:
            if 'phase' in metric:row[metric+'_lo']=row[metric+'_hi']=np.nan
        row['phase_warning']='Coherence cloud not separated from zero by approximate diagnostic; phase CI suppressed.'
    else:row['phase_warning']='Approximate localization check only; not a guaranteed coverage test.'
    row['bootstrap_replicates']=len(reps);row['interval_caveat']=CAVEAT
    return row


def _matrix_entries(matrix,matrix_id,kind):
    return [{'matrix_id':matrix_id,'matrix_kind':kind,'row':i,'column':j,
             'real':float(matrix[i,j].real),'imag':float(matrix[i,j].imag)}
            for i in range(matrix.shape[0]) for j in range(matrix.shape[1])]


def analyse(path,output,bootstraps=500,seed=240917,solver='cvxpy',count_gof=False,
            gof_bootstraps=500,protocol='network',resume=True):
    if min(bootstraps,gof_bootstraps)<20:raise ValueError('At least 20 resamples; use 500+ for reporting')
    out=validate_output(output);out.mkdir(parents=True,exist_ok=True)
    data,groups,prov=load_groups(path,protocol)
    kind=data['data_kind'];prefix='measured_' if kind=='HARDWARE' else 'synthetic_'
    signature={'input_sha256':sha256(path),'code_hashes':code_fingerprint(),'protocol':protocol,
               'bootstraps':bootstraps,'seed':seed,'solver':solver,'gof_bootstraps':gof_bootstraps,
               'count_gof':count_gof}
    sp=out/'analysis_signature.json'
    if sp.exists() and json.loads(sp.read_text())!=signature:
        raise ValueError('Analysis inputs/settings/code changed. Use a NEW analysis output folder rather than mix stale results.')
    write_json(sp,signature);write_json(out/'environment.json',environment_record())
    cache=out/'checkpoints';cache.mkdir(exist_ok=True)
    matrixdir=out/'matrices';matrixdir.mkdir(exist_ok=True)
    bootdir=out/'bootstrap';bootdir.mkdir(exist_ok=True)
    states=[];process=[];gof=[];warnings=[];audit=[];elements=[];complete=[]
    for key,counts in sorted(groups.items()):
        acquisition,M1,M2,x,m,mode,probe=key;tag=_label(key)
        meta={'data_kind':kind,'protocol':protocol,'acquisition_id':acquisition,'M1':M1,'M2':M2,'x':x,'m':m,
              'recovery':mode,'probe':probe,'backend':'|'.join(sorted(prov[key]['backends'])),
              'hardware_job_ids':'|'.join(sorted(prov[key]['hardware_job_ids'])),
              'source_counts_sha256':signature['input_sha256']}
        complete.append({**meta,'settings_present':len(counts),'complete':set(counts)==set(SETTINGS),
                         'total_shots':sum(sum(d.values()) for d in counts.values())})
        if set(counts)!=set(SETTINGS):
            warnings.append(f'Incomplete nine-setting tomography: {key}');continue
        lin=tomography(counts,project=False);rho=tomography(counts)
        np.save(matrixdir/(tag+'_linear.npy'),lin);np.save(matrixdir/(tag+'.npy'),rho)
        elements.extend(_matrix_entries(rho,tag,'rho_psd_trace_one'))
        audit.append({**meta,'matrix_id':tag,'linear_min_eigenvalue':float(np.linalg.eigvalsh(lin).min()),
                      'projection_frobenius':float(np.linalg.norm(rho-lin)),'trace_real':float(np.trace(rho).real),
                      'minimum_eigenvalue':float(np.linalg.eigvalsh(rho).min())})
        if probe!='chi':continue
        check=cache/(tag+'_state.json')
        if resume and check.is_file():
            saved=json.loads(check.read_text());states.extend(saved['rows']);continue
        rng=np.random.default_rng(_seed(seed,key));C=frame(x,m,M1,M2)
        modes=[mode]+(['frame_tracked'] if mode=='raw' else [])
        estimates={mo:state_metrics(C.conj().T@rho@C if mo=='frame_tracked' else rho,x,m,M1,M2,mo) for mo in modes}
        reps={mo:[] for mo in modes};projection_count=0
        for _ in range(bootstraps):
            cc=resample_counts(counts,rng);rl=tomography(cc,project=False);rr=tomography(cc)
            projection_count+=int(np.linalg.eigvalsh(rl).min()<-1e-12)
            for mo in modes:
                reps[mo].append(state_metrics(C.conj().T@rr@C if mo=='frame_tracked' else rr,x,m,M1,M2,mo))
        local=[]
        for mo in modes:
            derived=mo=='frame_tracked';stateid=tag.replace('_raw_','_frame_tracked_') if derived else tag
            mat=C.conj().T@rho@C if derived else rho
            np.save(matrixdir/(stateid+'.npy'),mat)
            bfile='bootstrap/'+stateid+'.npz'
            numerical=[k for k,v in reps[mo][0].items() if isinstance(v,(float,int,np.floating))]
            np.savez_compressed(out/bfile,**{k:np.array([r[k] for r in reps[mo]]) for k in numerical})
            row={**meta,'recovery':mo,'state_id':stateid,'derived_from_raw':derived,
                 'matrix_file':'matrices/'+stateid+'.npy','bootstrap_file':bfile,
                 'bootstrap_projection_fraction':projection_count/bootstraps,
                 'bootstrap_seed':_seed(seed,key),**estimates[mo]}
            add_intervals(row,reps[mo]);local.append(row)
        states.extend(local);write_json(check,{'rows':local})
        print('State completed:',protocol,tag,flush=True)
    # Make valid state results available even if a later process/GOF solve is interrupted.
    write_csv(out/(prefix+'state_phases_concurrence.csv'),states)
    write_csv(out/'state_projection_audit.csv',audit)
    write_csv(out/'tomography_completeness.csv',complete)
    _comparisons(out,states,prefix)
    write_json(out/'analysis_progress.json',{'stage':'STATE_TABLES_COMPLETE_PROCESS_FITS_PENDING',
               'data_kind':kind,'phase_rows':len(states),'completed_process_fits':0})
    for combo in sorted(set(k[:-1] for k in groups)):
        acquisition,M1,M2,x,m,mode=combo
        needed=[combo+(p,) for p in ('0','1','+','+i')]
        if any(k not in groups or set(groups[k])!=set(SETTINGS) for k in needed):continue
        tag=_label(combo);check=cache/(tag+'_process.json')
        if resume and check.is_file():
            saved=json.loads(check.read_text());process.append(saved['row'])
            if saved.get('gof') is not None:gof.append(saved['gof'])
            continue
        rng=np.random.default_rng(_seed(seed,combo));C=frame(x,m,M1,M2);V=encoding()
        def blocks_of(cc):
            blocks={}
            for probe,cnt in cc.items():
                rr=tomography(cnt)
                if mode=='raw':rr=C.conj().T@rr@C
                blocks[probe]=V.conj().T@rr@V
            return blocks
        cc={p:groups[combo+(p,)] for p in ('0','1','+','+i')}
        blocks=blocks_of(cc);fitter=CPTNIFitter(solver);J,vals=fitter.fit(blocks);Jlin=choi_from_blocks(blocks)
        actual_ids=sorted(set(i for k in needed for i in prov[k]['hardware_job_ids']))
        backends=sorted(set(b for k in needed for b in prov[k]['backends']))
        if len(backends)!=1:raise ValueError('Process probes span different backends')
        row={'data_kind':kind,'protocol':protocol,'acquisition_id':acquisition,'backend':backends[0],
             'hardware_job_ids':'|'.join(actual_ids),'M1':M1,'M2':M2,'x':x,'m':m,
             'recovery':'frame_tracked' if mode=='raw' else mode,'source_recovery':mode,
             'process_id':tag,'source_counts_sha256':signature['input_sha256'],**vals,
             'linear_choi_min_eigenvalue':float(np.linalg.eigvalsh(Jlin).min()),
             'linear_effect_max_eigenvalue':float(np.linalg.eigvalsh(effect_transpose(Jlin)).max()),
             'linear_to_cptni_frobenius':float(np.linalg.norm(J-Jlin)),
             'choi_normalization':'unnormalized input-first Choi; Tr(J)/2 = survival',
             'input_code_y':0,'probe_outputs_individually_normalized':False}
        np.save(matrixdir/(tag+'_choi.npy'),J);np.save(matrixdir/(tag+'_choi_linear.npy'),Jlin)
        row['matrix_file']='matrices/'+tag+'_choi.npy'
        ptm=np.array([[np.trace(PAULI[a]@apply_choi(J,PAULI[b])).real/2 for b in 'IXYZ'] for a in 'IXYZ'])
        np.save(matrixdir/(tag+'_ptm.npy'),ptm)
        row['ptm_file']='matrices/'+tag+'_ptm.npy'
        reps=[]
        for rep in range(bootstraps):
            _,v=fitter.fit(blocks_of({p:resample_counts(d,rng) for p,d in cc.items()}));reps.append(v)
        for metric in ('survival','identity_overlap','block_residual'):
            lo,hi=np.quantile([r[metric] for r in reps],[.025,.975]);row[metric+'_lo']=float(lo);row[metric+'_hi']=float(hi)
        row['bootstrap_boundary_fraction']=float(np.mean([r['choi_min_eigenvalue']<1e-6 for r in reps]))
        row['bootstrap_optimal_inaccurate_fraction']=float(np.mean([r['status']=='optimal_inaccurate' for r in reps]))
        row['bootstrap_replicates']=bootstraps;row['bootstrap_seed']=_seed(seed,combo);row['interval_caveat']=CAVEAT
        row['bootstrap_file']='bootstrap/'+tag+'_process.npz'
        np.savez_compressed(out/row['bootstrap_file'],**{k:np.array([r[k] for r in reps]) for k in
                ('survival','identity_overlap','block_residual','choi_min_eigenvalue','effect_max_eigenvalue')})
        if combo+('chi',) in groups and set(groups[combo+('chi',)])==set(SETTINGS):
            held=blocks_of({'chi':groups[combo+('chi',)]})['chi']
            predicted=apply_choi(J,np.outer(PROBES['chi'],PROBES['chi'].conj()))
            row['heldout_chi_block_squared_error']=float(np.linalg.norm(held-predicted)**2)
            row['heldout_chi_note']='chi was not used to fit the four-probe channel; descriptive residual, not a calibrated p value'
        grow=None
        if count_gof:
            from count_level_gof import calibrated_gof
            result=calibrated_gof(cc,frame_matrix=C if mode=='raw' else np.eye(4),resamples=gof_bootstraps,
                                 seed=_seed(seed,combo+('gof',)),block_solver=solver,output=out/'gof_details'/tag)
            grow={k:row[k] for k in ('data_kind','protocol','acquisition_id','backend','M1','M2','x','m','recovery','process_id')}
            grow.update(result);gof.append(grow)
        process.append(row);write_json(check,{'row':row,'gof':grow})
        write_csv(out/(prefix+'cptni_fits.csv'),process)
        write_csv(out/'count_level_gof.csv',gof)
        write_json(out/'analysis_progress.json',{'stage':'PROCESS_FITS_RUNNING','data_kind':kind,
                   'phase_rows':len(states),'completed_process_fits':len(process),'completed_gof_fits':len(gof)})
        print('Process completed:',protocol,tag,flush=True)
    # Reload all point matrices here so resumed runs produce the same exports.
    for row in states:
        if row['derived_from_raw']:
            elements.extend(_matrix_entries(np.load(out/row['matrix_file'],allow_pickle=False),row['state_id'],'rho_frame_tracked'))
    for row in process:
        elements.extend(_matrix_entries(np.load(out/row['matrix_file'],allow_pickle=False),row['process_id'],'choi_unnormalized'))
    write_csv(out/(prefix+'state_phases_concurrence.csv'),states)
    write_csv(out/(prefix+'cptni_fits.csv'),process)
    write_csv(out/'count_level_gof.csv',gof)
    write_csv(out/'state_projection_audit.csv',audit)
    write_csv(out/'tomography_completeness.csv',complete)
    write_csv(out/'matrix_elements.csv',elements)
    _comparisons(out,states,prefix)
    status={'data_kind':kind,'source_counts_file':Path(path).name,'source_counts_sha256':signature['input_sha256'],
            'protocol':protocol,'phase_rows':len(states),'directly_measured_chi_groups':sum(not r['derived_from_raw'] for r in states),
            'derived_frame_tracked_rows':sum(r['derived_from_raw'] for r in states),
            'process_rows':len(process),'gof_rows':len(gof),'warnings':warnings,
            'bootstrap_replicates':bootstraps,'gof_bootstrap_replicates':gof_bootstraps if count_gof else 0,
            'solver':solver,'count_gof_requested':count_gof,'status':'ANALYSED' if not warnings else 'INCOMPLETE_TOMOGRAPHY',
            'limitations':CAVEAT,'no_new_qpu_job_submitted_by_analysis':True}
    write_json(out/'analysis_status.json',status)
    write_json(out/'analysis_progress.json',{'stage':'COMPLETE','data_kind':kind,'phase_rows':len(states),
               'completed_process_fits':len(process),'completed_gof_fits':len(gof)})
    return status


def _comparisons(out,states,prefix):
    index={}
    for r in states:index.setdefault((r['acquisition_id'],r['M1'],r['M2'],r['x'],r['m']),{})[r['recovery']]=r
    phases=[];comparisons=[]
    for key,modes in sorted(index.items()):
        row={'acquisition_id':key[0],'M1':key[1],'M2':key[2],'x':key[3],'m':key[4]}
        for mode,r in modes.items():
            row['data_kind']=r['data_kind']
            for metric in ('phase_rad','phase_rad_lo','phase_rad_hi','ideal_phase_rad','phase_error_rad',
                           'concurrence','concurrence_lo','concurrence_hi','code_population'):
                row[mode+'_'+metric]=r.get(metric)
        phases.append(row)
        if {'frame_tracked','physical'}<=set(modes):
            a,b=modes['physical'],modes['frame_tracked']
            ba=np.load(out/a['bootstrap_file'],allow_pickle=False);bb=np.load(out/b['bootstrap_file'],allow_pickle=False)
            comp={k:row[k] for k in ('acquisition_id','M1','M2','x','m','data_kind')}
            for metric in ('fidelity','code_population','concurrence'):
                diff=ba[metric]-bb[metric];lo,hi=np.quantile(diff,[.025,.975])
                comp['physical_minus_tracked_'+metric]=a[metric]-b[metric]
                comp[metric+'_difference_lo']=float(lo);comp[metric+'_difference_hi']=float(hi)
            comp['interpretation']='Independent count resampling for raw/physical circuits; descriptive within-acquisition contrast, not an isolated correction-gate error.'
            comparisons.append(comp)
    write_csv(out/(prefix+'phase_comparison.csv'),phases)
    write_csv(out/(prefix+'recovery_comparison.csv'),comparisons)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--records',required=True);p.add_argument('--output',required=True)
    p.add_argument('--bootstraps',type=int,default=500);p.add_argument('--gof-bootstraps',type=int,default=500)
    p.add_argument('--seed',type=int,default=240917);p.add_argument('--solver',choices=['cvxpy','scipy'],default='cvxpy')
    p.add_argument('--count-gof',action='store_true');p.add_argument('--no-resume',action='store_true')
    p.add_argument('--protocol',choices=['network','direct_preparation','swap_transfer'],default='network')
    a=p.parse_args();print(json.dumps(analyse(a.records,a.output,a.bootstraps,a.seed,a.solver,a.count_gof,a.gof_bootstraps,a.protocol,not a.no_resume),indent=2))

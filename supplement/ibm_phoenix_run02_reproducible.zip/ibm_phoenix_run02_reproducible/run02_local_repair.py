"""Local-only completion of fixed5 full_4resources_run02.

Adds a versioned repair directory. Never edits acquisition records, old analyses,
configuration, original Python modules or their recorded hashes. No IBM service
is constructed and no compile/submit/collect operation exists in this module.
"""
from __future__ import annotations
from pathlib import Path
from contextlib import contextmanager
from collections import Counter
from importlib.metadata import version,PackageNotFoundError
import csv,hashlib,json,os,shutil,sys,threading,time,traceback,zipfile
import numpy as np
from full_receiver_solver_repair import VERSION,activate_recovery,CertifiedLikelihood,counts_array,counts_from_array,audit_choi

RUN_ID='full_4resources_run02'
NEW_FILES=('full_receiver_solver_repair.py','run02_local_repair.py')


def _read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def _hash(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def _rows(p):
    with Path(p).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))


def _inside(base,p):
    base=Path(base).resolve();p=Path(p).resolve()
    if not p.is_relative_to(base):raise ValueError('A recorded path leaves the expected directory')
    return p


@contextmanager
def _lock(folder):
    """Same lock as the sequential notebook; do not operate both at once."""
    f=(folder/'.sequential_operation.lock').open('a+b');locked=False
    try:
        f.seek(0,2)
        if f.tell()==0:f.write(b'0');f.flush()
        f.seek(0)
        try:
            if os.name=='nt':
                import msvcrt;msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl;fcntl.flock(f.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
            locked=True
        except OSError as exc:raise RuntimeError('This run is already in use. Stop the other kernel first.') from exc
        yield
    finally:
        if locked:
            f.seek(0)
            if os.name=='nt':
                import msvcrt;msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)
            else:
                import fcntl;fcntl.flock(f.fileno(),fcntl.LOCK_UN)
        f.close()


class LocalRun02Repair:
    def __init__(self,root=None):
        self.root=Path(root or Path(__file__).parent).resolve()
        if not (self.root/'revision_project.json').is_file():
            raise FileNotFoundError('Place the added files inside the existing Revision_fixed5 project, not an empty folder.')
        import workflow_paths as paths
        if paths.ROOT.resolve()!=self.root:raise RuntimeError('Another project is loaded. Restart the kernel.')
        self.paths=paths;self.acq=self.root/'Results/02_hardware'/RUN_ID
        self.out=None;self.cfg=None;self.old=None;self.prepared=False;self.finished=False
        self.stream=sys.stdout

    def _emit(self,s):self.stream.write(str(s)+'\n');self.stream.flush()

    def _versions(self):
        d={}
        for name in ('numpy','scipy','cvxpy','scs'):
            try:d[name]=version(name)
            except PackageNotFoundError:d[name]=None
        return d

    def _fingerprint(self):
        d=self.paths.code_fingerprint()
        d.update({name:_hash(self.root/name) for name in NEW_FILES})
        return d

    def _inventory(self,folder):
        d={}
        for p in sorted(folder.rglob('*')):
            if p.is_symlink():raise ValueError('Symlink in the analysis source: '+str(p.name))
            if p.is_file():d[p.relative_to(folder).as_posix()]=_hash(p)
        return d

    def _verify_network(self,folder):
        s=_read(folder/'analysis_status.json');sig=_read(folder/'analysis_signature.json')
        if (s.get('status')!='ANALYSED' or s.get('data_kind')!='HARDWARE' or s.get('warnings')
            or s.get('phase_rows')!=48 or s.get('process_rows')!=32 or s.get('gof_rows')!=32):
            raise ValueError('Original network analysis is not a completed 48/32/32 HARDWARE analysis')
        if s['source_counts_sha256']!=_hash(self.source) or sig['input_sha256']!=_hash(self.source):
            raise ValueError('Original raw-count checksum differs. Do not replace receiver_counts.json with a redacted support bundle.')
        if sig['code_hashes']!=self.paths.code_fingerprint():
            raise ValueError('Original science files changed. Restore them; do not edit recorded hashes.')
        for k in ('bootstraps','gof_bootstraps','seed','solver','count_gof'):
            if sig[k]!=self.cfg['analysis'][k]:raise ValueError('Original analysis settings differ: '+k)
        self._validate_protocol(folder,48,32,32)
        rows=_rows(folder/'measured_state_phases_concurrence.csv')
        expected={(a,b,x,m,mode) for a in (0,1) for b in (0,1) for x in (0,1) for m in (0,1)
                  for mode in ('raw','physical','frame_tracked')}
        actual={(int(r['M1']),int(r['M2']),int(r['x']),int(r['m']),r['recovery']) for r in rows}
        if actual!=expected:raise ValueError('Network resource/sector coverage mismatch')
        # No model fit: independently verify that the saved point states correspond
        # to the uploaded count groups and the original projection/frame convention.
        from reanalyse_counts import load_groups
        from quantum_core import tomography,frame
        _,groups,_=load_groups(self.source,'network')
        for r in rows:
            mode=r['recovery'];key=(r['acquisition_id'],int(r['M1']),int(r['M2']),int(r['x']),int(r['m']),
                                    'raw' if mode=='frame_tracked' else mode,'chi')
            rho=tomography(groups[key])
            if mode=='frame_tracked':
                C=frame(key[3],key[4],key[1],key[2]);rho=C.conj().T@rho@C
            saved=np.load(_inside(folder,folder/r['matrix_file']),allow_pickle=False)
            if np.linalg.norm(rho-saved)>1e-8:raise ValueError('Saved point-state/count mismatch: '+r['state_id'])
        return s

    def _validate_protocol(self,folder,ns,np_,ng):
        from quantum_core import effect_transpose
        pairs=[('measured_state_phases_concurrence.csv',ns),('measured_cptni_fits.csv',np_),('count_level_gof.csv',ng)]
        allrows={name:_rows(folder/name) for name,_ in pairs}
        for name,n in pairs:
            if len(allrows[name])!=n:raise ValueError('Unexpected row count in '+str(folder/name))
        a=self.cfg['analysis'];B=a['bootstraps'];G=a['gof_bootstraps']
        for r in allrows['measured_state_phases_concurrence.csv']:
            if r.get('data_kind')!='HARDWARE' or int(r['bootstrap_replicates'])!=B:raise ValueError('Wrong state provenance/resamples')
            J=np.load(_inside(folder,folder/r['matrix_file']),allow_pickle=False)
            if J.shape!=(4,4) or not np.isfinite(J).all() or np.linalg.eigvalsh(J).min() < -2e-6 or abs(np.trace(J)-1)>2e-5:
                raise ValueError('State matrix audit failed')
            with np.load(_inside(folder,folder/r['bootstrap_file']),allow_pickle=False) as z:
                for key in ('concurrence','fidelity','code_population'):
                    if z[key].shape!=(B,) or not np.isfinite(z[key]).all():raise ValueError('State bootstrap file incomplete')
        for r in allrows['measured_cptni_fits.csv']:
            if r.get('data_kind')!='HARDWARE' or int(r['bootstrap_replicates'])!=B:raise ValueError('Wrong process provenance/resamples')
            J=np.load(_inside(folder,folder/r['matrix_file']),allow_pickle=False)
            if (J.shape!=(4,4) or not np.isfinite(J).all() or np.linalg.eigvalsh(J).min() < -2e-6
                or np.linalg.eigvalsh(effect_transpose(J)).max()>1+2e-6):raise ValueError('CP-TNI point matrix audit failed')
            with np.load(_inside(folder,folder/r['bootstrap_file']),allow_pickle=False) as z:
                for key in ('survival','identity_overlap','block_residual'):
                    if z[key].shape!=(B,) or not np.isfinite(z[key]).all():raise ValueError('Process bootstrap file incomplete')
        for r in allrows['count_level_gof.csv']:
            if r.get('data_kind')!='HARDWARE' or int(r['resamples'])!=G:raise ValueError('Wrong GOF provenance/resamples')
            d=_inside(folder,folder/'gof_details'/r['process_id'])
            with np.load(d/'parametric_null_statistics.npz',allow_pickle=False) as z:
                for key in ('pearson_X2','block_residual'):
                    if z[key].shape!=(G,) or not np.isfinite(z[key]).all():raise ValueError('GOF bootstrap file incomplete')
            if not audit_choi(np.load(d/'full_receiver_cptp_choi.npy',allow_pickle=False))['accepted']:
                raise ValueError('GOF observed null matrix physicality audit failed')
        return {'states':ns,'processes':np_,'gof_tests':ng,'bootstraps':B,'gof_bootstraps':G}

    def prepare(self):
        required=('receiver_counts.json','latest_analysis.json','sequential_config.json',
                  'compiled_metadata.json','joint_discarded_counts.json','submitted_jobs.json',
                  'submission_intent.json','manifest.json','collection_status.json','plan.json')
        missing=[n for n in required if not (self.acq/n).is_file()]
        if missing:raise FileNotFoundError('Required local files are missing: '+', '.join(missing)+'. Do not remeasure; check the original Results folder.')
        meta=_read(self.root/'run02_repair_metadata.json')
        if self.paths.code_fingerprint()!=meta['expected_original_science_hashes']:
            raise RuntimeError('The seven original science files do not match the supplied run02 sources. Do not edit hashes or overwrite original files.')
        for name in NEW_FILES:
            if _hash(self.root/name)!=meta['repair_files_sha256'][name]:raise RuntimeError('Repair module integrity mismatch: '+name)
        self.cfg=_read(self.acq/'sequential_config.json')
        if self.cfg['experiment']['run_id']!=RUN_ID or self.cfg['experiment']['stage']!='full':raise ValueError('Wrong run or not FULL')
        a=self.cfg['analysis']
        if (a['solver']!='cvxpy' or a['bootstraps']!=500 or a['gof_bootstraps']!=500 or not a['count_gof'] or not a['resume']):
            raise ValueError('Use the original run02 CVXPY/500/500/resume settings; do not change config')
        import cvxpy as cp
        if 'SCS' not in cp.installed_solvers():raise RuntimeError('The original CVXPY/SCS environment is required; this tool installs nothing')
        self.source=self.acq/'receiver_counts.json';data=_read(self.source)
        if data.get('data_kind')!='HARDWARE':raise ValueError('Real HARDWARE counts required; synthetic tests are not evidence')
        from ibm_followup import validate_full_design
        validate_full_design(data['records']) # purely local; no provider access
        latest=_read(self.acq/'latest_analysis.json')
        self.old=_inside(self.acq/'analyses',self.root/latest['analysis_directory'])
        self.network_status=self._verify_network(self.old/'network')
        identity={'policy':VERSION,'run_id':RUN_ID,'counts_sha256':_hash(self.source),
            'original_analysis':self.old.relative_to(self.root).as_posix(),
            'analysis_settings':a,'code_hashes':self._fingerprint(),'packages':self._versions()}
        ident=hashlib.sha256(json.dumps(identity,sort_keys=True).encode()).hexdigest()[:12]
        self.out=self.acq/'repairs'/('gof_repair_'+ident)
        with _lock(self.acq):
            self.out.mkdir(parents=True,exist_ok=True)
            ip=self.out/'repair_identity.json'
            if ip.exists() and _read(ip)!=identity:raise RuntimeError('Repair identity changed')
            self.paths.write_json(ip,identity)
            source_inventory=self._inventory(self.old/'network')
            target=self.out/'network'
            if target.exists():
                if self._inventory(target)!=source_inventory:raise RuntimeError('Copied network differs from the protected source')
            else:
                temporary=self.out/'network_copy_in_progress';temporary.mkdir(exist_ok=True)
                for rel,digest in source_inventory.items():
                    src=self.old/'network'/rel;dst=temporary/rel
                    dst.parent.mkdir(parents=True,exist_ok=True)
                    if not dst.exists() or _hash(dst)!=digest:shutil.copy2(src,dst)
                if self._inventory(temporary)!=source_inventory:raise RuntimeError('Network copy verification failed')
                temporary.replace(target)
            self.paths.write_json(self.out/'network_reuse_provenance.json',{
                'status':'REUSED_UNCHANGED_ORIGINAL_NETWORK_RESULTS',
                'source':(self.old/'network').relative_to(self.root).as_posix(),
                'source_files_sha256':source_inventory,'checks':'48/32/32 rows; all referenced point matrices and bootstrap files; point states recalculated from counts; no network refits',
                'method':'Original SCS, unchanged. Baseline GOF recovery has separate numerical-policy provenance.'})
            self.paths.write_json(self.acq/'latest_gof_repair.json',{'repair_directory':self.out.relative_to(self.root).as_posix(),
                'policy':VERSION,'original_latest_analysis_unchanged':True})
        self.prepared=True
        self._emit('run02の実測カウントと完了済みnetworkを確認しました。IBMへ接続しません。')
        self._emit('保存先: '+str(self.out))
        self._emit('networkはそのままコピー。基準回路のGOFは混在防止のため各500回を新しい場所で実施します。')
        return {'status':'LOCAL_REPAIR_PREPARED_NO_QPU_ACCESS','repair_directory':str(self.out)}

    def regression_check(self):
        if not self.prepared:raise RuntimeError('Run prepare first')
        f=_read(self.root/'regression/failure_396.json')
        candidate=np.asarray(f['rejected_choi']['real'])+1j*np.asarray(f['rejected_choi']['imag'])
        J,p,T,detail=CertifiedLikelihood(counts_array(counts_from_array(f['counts_36x4']))).solve(candidate)
        result={'status':'FAILED_DRAW_396_NUMERICAL_RECOVERY_PASSED',
            'data_kind':'PARAMETRIC_BOOTSTRAP_REGRESSION_NOT_NEW_HARDWARE',
            'original':f['original_solver'],'repaired':audit_choi(J),'certificate':detail,'pearson_statistic':T}
        self.paths.write_json(self.out/'failure_396_regression_check.json',result)
        self._emit('396回目の停止標本を再計算し、物理性と最適性の数値確認に合格しました。')
        return result

    @contextmanager
    def _progress(self,protocol):
        stop=threading.Event();began=time.monotonic()
        def monitor():
            while not stop.wait(30):
                note=''
                try:
                    p=self.out/protocol/'analysis_progress.json'
                    if p.exists():
                        d=_read(p);note=' state='+str(d.get('phase_rows','-'))+' process='+str(d.get('completed_process_fits','-'))
                    d=self.out/protocol/'gof_details'
                    completed=[len(_read(p)['pearson']) for p in d.glob('*/bootstrap_checkpoint.json')]
                    if completed:note+=' GOF保存済み='+str(completed)
                except (OSError,ValueError,KeyError):pass
                self._emit(protocol+' / 経過'+str(int(time.monotonic()-began))+'秒'+note+'（同じセルを重ねて実行しないでください）')
        t=threading.Thread(target=monitor,daemon=True);t.start()
        try:yield
        finally:stop.set();t.join(timeout=2)

    def _done(self,p):
        sp=self.out/p/'analysis_status.json'
        if not sp.exists():return False
        d=_read(sp)
        if d.get('status')!='ANALYSED' or d.get('warnings'):return False
        sig=_read(self.out/p/'analysis_signature.json')
        if sig['input_sha256']!=_hash(self.source) or sig['code_hashes']!=self._fingerprint():raise ValueError('Baseline signature changed')
        self._validate_protocol(self.out/p,1,1,1)
        return True

    def analyse(self):
        if not self.prepared:raise RuntimeError('Run prepare first')
        import reanalyse_counts as rc
        from hardware_diagnostics import analyse as diagnostics,benchmark_comparisons
        statuses={'network':self.network_status};a=self.cfg['analysis']
        with _lock(self.acq):
            old_fingerprint=rc.code_fingerprint
            try:
                rc.code_fingerprint=self._fingerprint  # explicit NEW signature in NEW folders, never rewrite old signatures
                with activate_recovery():
                    for p in ('direct_preparation','swap_transfer'):
                        if self._done(p):
                            self._emit(p+'は今回の修正方針で完了済みです。再利用します。')
                            statuses[p]=_read(self.out/p/'analysis_status.json');continue
                        self._emit(p+'の解析を開始／再開します。実機への送信はありません。')
                        with self._progress(p),self.paths.logged_step(self.out,p):
                            statuses[p]=rc.analyse(self.source,self.out/p,bootstraps=a['bootstraps'],
                                seed=a['seed'],solver=a['solver'],count_gof=True,gof_bootstraps=a['gof_bootstraps'],protocol=p,resume=True)
                        self._validate_protocol(self.out/p,1,1,1)
                self._emit('基準回路の解析が終了。較正・回路コスト・比較表を作成します。')
                with self.paths.logged_step(self.out,'diagnostics'):
                    statuses['diagnostics']=diagnostics(self.acq,self.out/'hardware_diagnostics',a['bootstraps'],a['seed'])
                    statuses['baseline_comparison_rows']=benchmark_comparisons(self.out)
                self._verify_network(self.old/'network')
                if self._inventory(self.out/'network')!=self._inventory(self.old/'network'):
                    raise ValueError('Network copy changed during repair')
                result={'status':'RUN02_LOCAL_REPAIR_COMPLETED_AUTHOR_REVIEW_REQUIRED','data_kind':'HARDWARE',
                    'run_id':RUN_ID,'repair_directory':self.out.relative_to(self.root).as_posix(),
                    'original_acquisition_and_original_analysis_unchanged':True,'new_qpu_jobs_submitted':0,
                    'network_result_policy':'reused_original_unchanged','baseline_gof_policy':VERSION,
                    'analyses':statuses,'interpretation_note':'Completeness is not model validity, SPAM correction, general coverage or publication acceptance.'}
                self.paths.write_json(self.out/'repair_completion.json',result);self.finished=True
                self._emit('RUN02_LOCAL_REPAIR_COMPLETED_AUTHOR_REVIEW_REQUIRED')
                return result
            except BaseException as exc:
                message=str(exc)[:800]
                # Offline numeric code only; no account object or SDK call exists here.
                self.paths.write_json(self.out/'repair_error.json',{'type':type(exc).__name__,'message':message,
                    'traceback_without_locals':traceback.format_exc(limit=12),
                    'raw_data_unchanged':True,'no_new_qpu_submission':True})
                self._emit('ローカル解析が停止しました。原因: '+type(exc).__name__+' / '+message)
                self._emit('記録: '+str(self.out/'repair_error.json'))
                raise
            finally:rc.code_fingerprint=old_fingerprint

    def report(self):
        if not self.prepared:raise RuntimeError('Run prepare first')
        if not (self.out/'repair_completion.json').exists():raise RuntimeError('Run analyse to completion first')
        self._validate_protocol(self.out/'network',48,32,32)
        for p in ('direct_preparation','swap_transfer'):self._validate_protocol(self.out/p,1,1,1)
        from IPython.display import display
        from IPython.display import HTML
        from html import escape
        for p in ('network','direct_preparation','swap_transfer'):
            self._emit(p)
            d=_rows(self.out/p/'measured_state_phases_concurrence.csv')
            columns=[k for k in ('M1','M2','x','m','recovery','phase_rad','phase_rad_lo','phase_rad_hi','concurrence','concurrence_lo','concurrence_hi') if d and k in d[0]]
            table='<table><thead><tr>'+''.join('<th>'+escape(k)+'</th>' for k in columns)+'</tr></thead><tbody>'
            table+=''.join('<tr>'+''.join('<td>'+escape(r.get(k,''))+'</td>' for k in columns)+'</tr>' for r in d)
            display(HTML(table+'</tbody></table>'))
        self.finished=True
        return {'status':'REPAIRED_RESULTS_DISPLAYED','path':str(self.out)}

    def export(self):
        if not self.prepared or not (self.out/'repair_completion.json').exists():raise RuntimeError('Complete local repair before export')
        self._validate_protocol(self.out/'network',48,32,32)
        for p in ('direct_preparation','swap_transfer'):self._validate_protocol(self.out/p,1,1,1)
        # Allow-list, not a recursive scan of the user's entire home/project.
        entries={}
        def add(p):
            p=Path(p)
            if p.is_symlink():raise ValueError('Refusing to export a symlink')
            rel=p.relative_to(self.root).as_posix();blob=p.read_bytes()
            if p.suffix=='.ipynb':
                d=json.loads(blob)
                for c in d['cells']:
                    if c['cell_type']=='code':c['outputs']=[];c['execution_count']=None
                d.get('metadata',{}).pop('widgets',None);blob=json.dumps(d,ensure_ascii=False,indent=1).encode()
            if p.suffix in ('.py','.json','.md','.txt','.ipynb'):
                import re
                if re.search(rb'(?i)(?:api[_-]?key|token)\s*[=:]\s*[\"\x27][A-Za-z0-9_-]{30,}[\"\x27]',blob):
                    raise ValueError('Potential credential in export; inspect '+rel)
            entries[rel]=blob
        for n in list(self.paths.code_fingerprint())+list(NEW_FILES)+[
            'revision_project.json','run02_repair_metadata.json','08_resume_run02_gof_repair.ipynb',
            'README_RUN02_GOF_REPAIR_JA.md','NUMERICAL_METHOD.md','requirements-offline.txt','requirements-quantum.txt']:
            if (self.root/n).is_file():add(self.root/n)
        for p in (self.root/'regression').glob('*'):
            if p.is_file() and p.suffix in ('.json','.npy'):add(p)
        # Include the original source data and provenance, but no SDK accounts or local config.
        for n in ('receiver_counts.json','joint_discarded_counts.json','compiled_metadata.json','plan.json','manifest.json',
                  'submitted_jobs.json','submission_intent.json','collection_status.json','job_metadata.json',
                  'compiled_circuits.qpy','logical_circuits.qpy','readout_pair_audit.json','runtime_options.json',
                  'selected_initial_layout.json','sequential_config.json','latest_analysis.json'):
            if (self.acq/n).is_file():add(self.acq/n)
        # Original completed network is needed to reproduce the reuse audit.
        for p in (self.old/'network').rglob('*'):
            if p.is_file() and not p.is_symlink() and p.suffix not in ('.log','.zip','.tmp'):add(p)
        entries['config.json']=json.dumps({'original_data':{'archive':'Inputs/Exact_Channel_Equivalence_hardware_reproducibility_archive.zip','normalized_counts':''},**self.cfg},ensure_ascii=False,indent=2).encode()
        for pattern in ('*calibration*.json','*backend*.json'):
            for p in self.acq.glob(pattern):add(p)
        for p in self.out.rglob('*'):
            if p.is_file() and not p.is_symlink() and p.suffix not in ('.log','.zip','.tmp') and p.name!='repair_error.json':add(p)
        manifest={'status':'LOCAL_REPAIRED_RESULTS_NO_ONLINE_UPLOAD','run_id':RUN_ID,'repair_directory':self.out.relative_to(self.root).as_posix(),
            'files':[{'path':n,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)} for n,b in sorted(entries.items())],
            'scope':'Original completed network retained; direct/SWAP analysed with audited fallback; no new hardware job; shared baselines; single acquisition only.'}
        entries['RUN02_REPAIRED_EXPORT_MANIFEST.json']=json.dumps(manifest,ensure_ascii=False,indent=2).encode()
        out=self.root/'Results/Exports';out.mkdir(exist_ok=True)
        products=[]
        for name in ('full_4resources_run02_repaired_submission.zip','full_4resources_run02_repaired_GitHub.zip'):
            p=out/name
            with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
                for n,b in sorted(entries.items()):z.writestr('Revision_fixed5/'+n,b)
            with zipfile.ZipFile(p) as z:
                if z.testzip() is not None:raise RuntimeError('Export ZIP CRC failure')
            products.append(str(p))
        self._emit('RUN02_REPAIRED_RESULTS_AND_ZIPS_READY_FOR_AUTHOR_REVIEW')
        for p in products:self._emit(p)
        return {'status':'LOCAL_REPAIRED_EXPORTS_CREATED','files':products,'uploaded':False}

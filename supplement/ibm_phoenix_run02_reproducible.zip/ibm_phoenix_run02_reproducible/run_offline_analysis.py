"""Reproducible calculations supported by the supplied source and summary table.
Run: python run_offline_analysis.py
No newly acquired hardware observations are generated or claimed.
"""
from __future__ import annotations
import csv, json, platform, itertools, hashlib
from pathlib import Path
import numpy as np
from quantum_core import *

ROOT=Path(__file__).resolve().parent
from workflow_paths import output_path
OUT=output_path('00_offline')

def save_csv(name,rows):
    category=('DERIVED_FROM_ROUNDED_SUMMARY_NOT_RAW_REANALYSIS' if name.startswith('summary_') else
              'ILLUSTRATIVE_MODEL_NOT_HARDWARE' if name.startswith('illustrative_') else 'IDEAL_CALCULATION')
    rows=[{'data_kind':category,**r} for r in rows]
    path=OUT/name;path.parent.mkdir(exist_ok=True)
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def main(output=None):
    global OUT
    if output is not None:
        from workflow_paths import validate_output
        OUT=validate_output(output)
    (OUT).mkdir(parents=True,exist_ok=True)
    errors=[];operator_errors=[];n_basis=0
    for x,m,M1,M2,y in itertools.product((0,1),repeat=5):
        u=transfer_unitary(x,m);G=resource(m,M1,M2);V=encoding(y);C=frame(x,m,M1,M2)
        env=discarded(x,m,M1,y);out=[]
        for b in (0,1):
            actual=u@np.kron(G,V[:,b]);expected=(-1)**(m*M1+M2*y)*np.kron(C@V[:,b],env)
            errors.append(np.max(np.abs(actual-expected)));out.append(actual);n_basis+=1
        for j,k in itertools.product((0,1),repeat=2):
            actual=partial_receiver(np.outer(out[j],out[k].conj()))
            expected=C@np.outer(V[:,j],V[:,k].conj())@C.conj().T
            operator_errors.append(np.linalg.norm(actual-expected))
    audit={'status':'EXECUTED_OFFLINE_NOT_HARDWARE','python':platform.python_version(),'numpy':np.__version__,
           'parameter_configurations':32,'basis_vector_checks':n_basis,'operator_basis_checks':len(operator_errors),
           'max_basis_amplitude_error':float(max(errors)),'max_operator_frobenius_error':float(max(operator_errors)),
           'criterion':1e-12,'passed':bool(max(errors+operator_errors)<1e-12)}
    assert audit['passed']
    # Extension to the full two-physical-qubit space: parity dephasing, not identity.
    full_errors=[];P0=encoding(0)@encoding(0).conj().T;P1=encoding(1)@encoding(1).conj().T
    for x,m,M1,M2 in itertools.product((0,1),repeat=4):
        U=transfer_unitary(x,m);G=resource(m,M1,M2);C=frame(x,m,M1,M2)
        outs=[U@np.kron(G,ket(j,2)) for j in range(4)]
        for j,k in itertools.product(range(4),repeat=2):
            E=np.outer(ket(j,2),ket(k,2))
            actual=C.conj().T@partial_receiver(np.outer(outs[j],outs[k].conj()))@C
            full_errors.append(np.linalg.norm(actual-(P0@E@P0+P1@E@P1)))
    audit['full_space_operator_checks']=len(full_errors)
    audit['full_space_parity_dephasing_max_error']=float(max(full_errors))
    assert max(full_errors)<1e-12
    (OUT/'ideal_verification.json').write_text(json.dumps(audit,indent=2))

    # Literal source-table values. These are not reconstructed raw hardware data.
    source=[(0,0,0,0,.8925,.9013,.9304,.8321,.3952),(0,0,1,0,.8879,.8800,.9099,.8001,.3902),
            (0,0,0,1,.8631,.8667,.9033,.7796,.3785),(0,0,1,1,.8884,.8959,.9229,.8301,.3926),
            (0,1,0,0,.9175,.9210,.9475,.8671,.4078),(0,1,1,0,.9011,.8980,.9294,.8267,.3962),
            (0,1,0,1,.8945,.9015,.9412,.8356,.3934),(0,1,1,1,.9257,.9238,.9592,.8750,.4062)]
    lower=[]
    for M1,M2,x,m,fr,fp,p,purity,c in source:
        value=2*c+p-1
        # Three four-decimal contributions: 2|c| + p. Outward rounded LOWER bound.
        conservative=np.floor((value-0.00015)*1e4+1e-9)/1e4
        lower.append({'M1':M1,'M2':M2,'x':x,'m':m,'F_raw_reported':fr,'F_physical_reported':fp,
           'code_population_reported':p,'purity_reported':purity,'abs_coherence_reported':c,
           'concurrence_lower_bound_from_printed_numbers':round(value,4),
           'rounding_conservative_lower_bound':round(float(conservative),4),
           'physical_minus_frame_tracked_fidelity_point_difference':round(fp-fr,4),
           'source':'ver3 Table 6; no raw-count reanalysis','uncertainty':'not a confidence bound'})
    save_csv('summary_derived_entanglement_bounds.csv',lower)
    frames=[]
    for M1,M2 in [(0,0),(1,0),(0,1),(1,1)]:
        for x,m in [(0,0),(1,0),(0,1),(1,1)]:
            a,b=raw_basis(x,m,M1,M2);kappa=m^M1^M2;yraw=x^M1^M2
            frames.append({'M1':M1,'M2':M2,'x':x,'m':m,'raw_code_y_for_input_y0':yraw,
                           'recovered_code_y':0,'branch_u':format(a,'02b'),'branch_v':format(b,'02b'),
                           'ideal_raw_branch_phase_rad':-np.pi/3+np.pi*M2,
                           'ideal_raw_fixed_code_phase_rad':float(np.angle(np.exp(1j*((-1)**kappa)*(-np.pi/3+np.pi*M2)))),
                           'ideal_recovered_phase_rad':-np.pi/3,'physical_X_count':(m^x)+kappa,
                           'physical_Z_count':M2,'additional_CX_count':0})
    save_csv('ideal_sector_frames.csv',frames)

    faults=[];psi=encoding()@PROBES['chi'];rho=np.outer(psi,psi.conj())
    for name,E in [('correct recovery',np.eye(4)),('uncompensated Z on receiver 3',np.kron(I,Z)),
                   ('uncompensated X on receiver 4',np.kron(X,I)),('uncompensated X on receiver 3',np.kron(I,X)),
                   ('uncompensated X on both receivers',np.kron(X,X))]:
        s=E@rho@E.conj().T;c=s[0,3]
        faults.append({'scenario':name,'ideal_fidelity':float((psi.conj()@s@psi).real),
                       'code_population':float((s[0,0]+s[3,3]).real),'abs_code_coherence':float(abs(c)),
                       'code_coherence_phase_rad':float(np.angle(c)) if abs(c)>1e-12 else 'undefined',
                       'concurrence':concurrence(s),'data_kind':'IDEAL_CALCULATION'})
    save_csv('ideal_fault_signatures.csv',faults)

    noise=[]
    for p2 in [0.,.001,.005,.01,.02]:
        # Only one representative sector is needed under this covariant noise model;
        # independently test all four resource labels for the representative sector.
        for M1,M2 in itertools.product((0,1),repeat=2):
            r=noisy_receiver(PROBES['chi'],0,0,M1,M2,p2=p2)
            B={k:encoding().conj().T@noisy_receiver(PROBES[k],0,0,M1,M2,p2=p2)@encoding() for k in ('0','1','+','+i')}
            J,met=fit_cptni(B)
            noise.append({'p2_nonidentity_Pauli_probability':p2,'M1':M1,'M2':M2,'transfer_CX_count':7,
                          'F':float((psi.conj()@r@psi).real),'code_population':float((r[0,0]+r[3,3]).real),
                          'coherence_phase':float(np.angle(r[0,3])),'concurrence':concurrence(r),
                          'S_code':met['survival'],'D_identity':met['identity_overlap'],
                          'data_kind':'ILLUSTRATIVE_MODEL_NOT_CALIBRATED_HARDWARE'})
    save_csv('illustrative_gate_noise.csv',noise)
    budgets=[{'error_event_probability':p,'counted_two_qubit_gates':N,'independent_no_fault_probability':(1-p)**N,
              'assumption':'independent event model; not fidelity or hardware calibration'} for N in [19,38,95,190] for p in [.001,.005,.01]]
    save_csv('illustrative_scaling.csv',budgets)

    # Test all tomography basis/sign conventions using exact probabilities represented as weights.
    expected=np.outer(psi,psi.conj());fake={s:{format(i,'02b'):v for i,v in enumerate(probabilities(expected,s))} for s in SETTINGS}
    # tomography insists on integer counts; test with high-shot deterministic rounded weights.
    for s in SETTINGS:
        a=np.rint(probabilities(expected,s)*1e9).astype(int);a[0]+=10**9-a.sum();fake[s]={format(i,'02b'):int(n) for i,n in enumerate(a)}
    err=float(np.linalg.norm(tomography(fake)-expected));assert err<1e-8
    B={k:.9*np.outer(PROBES[k],PROBES[k].conj()) for k in ('0','1','+','+i')}
    J,met=fit_cptni(B);assert abs(met['survival']-.9)<1e-10 and abs(met['identity_overlap']-.9)<1e-10
    # Nonphysical perturbation tests the constrained fallback, not just feasible inversion.
    B_bad={k:v.copy() for k,v in B.items()};B_bad['+'][0,1]+=.04;B_bad['+'][1,0]+=.04
    Jb,mb=fit_cptni(B_bad);assert mb['choi_min_eigenvalue']>=-2e-7 and mb['effect_max_eigenvalue']<=1+2e-7
    (OUT/'software_tests.json').write_text(json.dumps({'status':'EXECUTED_SYNTHETIC_UNIT_TESTS',
      'tomography_error':err,'concurrence_pure_chi':concurrence(expected),
      'concurrence_expected':2*np.sqrt(.21),'uniform_loss_fit':met,'nonphysical_fit':mb},indent=2))
    print(json.dumps(audit,indent=2));print('Concurrence lower bounds:',[r['rounding_conservative_lower_bound'] for r in lower])
    print('All offline tests passed. No IBM jobs were submitted.')
if __name__=='__main__':main()

"""Matched, opt-in IBM Quantum follow-up. Importing does not contact any service.
Builds source circuits, records layouts/QPY/calibration, prints budgets, and
requires explicit submit=True plus an exact shot ceiling before a real QPU run.
Requires Qiskit and qiskit-ibm-runtime only for circuit building/execution.
"""
from __future__ import annotations
from dataclasses import dataclass,asdict
from pathlib import Path
from datetime import datetime,timezone
import itertools,json,hashlib,platform,os,tempfile
import numpy as np
from quantum_core import PROBES,SETTINGS,transfer_gates,encoding,frame,resource,transfer_unitary,ket

FORBIDDEN_BACKENDS=frozenset({'ibm_fez'})
MATCHED_RESOURCES=frozenset({(0,0),(0,1),(1,0),(1,1)})
MATCHED_SECTORS=frozenset({(0,0),(0,1),(1,0),(1,1)})

def require_allowed_backend(backend_name:str):
    """Reject hardware backends that the operator explicitly excluded."""
    if not backend_name:
        raise ValueError('Select an explicit backend')
    if backend_name in FORBIDDEN_BACKENDS:
        raise ValueError(f'Backend {backend_name!r} is explicitly forbidden for this workflow')

@dataclass(frozen=True)
class Plan:
    stage:str='full'  # All 4 resources x 4 sectors x 2 recoveries x 5 probes x 9 bases
    shots:int=4096
    resources:tuple=((0,0),(1,0),(0,1),(1,1))
    sectors:tuple=((0,0),(1,0),(0,1),(1,1))
    seed:int=240917
    direct_preparation_baseline:bool=True
    swap_transfer_baseline:bool=True
    readout_calibration:bool=True
    omit_z_ablation:bool=False
    discarded_diagnostics:bool=True
    def validate(self):
        if self.stage != 'full':raise ValueError('Revision fixed4 requires FULL nine-setting tomography; screen is not accepted')
        if type(self.shots) is not int or self.shots<1:raise ValueError('shots must be a positive integer')
        if len(set(self.resources))!=len(self.resources) or len(set(self.sectors))!=len(self.sectors):raise ValueError('Duplicate resource or sector')
        if any(b not in (0,1) for pair in self.resources+self.sectors for b in pair):raise ValueError('Labels must be binary')
        if frozenset(map(tuple,self.resources))!=MATCHED_RESOURCES:raise ValueError('Matched follow-up requires all four resources (0,0), (0,1), (1,0), (1,1) exactly once')
        if frozenset(map(tuple,self.sectors))!=MATCHED_SECTORS:raise ValueError('Matched follow-up requires all four sectors exactly once')

def manifest(plan:Plan):
    plan.validate();rows=[]
    probes=('chi',) if plan.stage=='screen' else ('0','1','+','+i','chi')
    bases=('ZZ','XX','YY','XY','YX') if plan.stage=='screen' else SETTINGS
    for res,sec,mode,probe,basis in itertools.product(plan.resources,plan.sectors,('raw','physical'),probes,bases):
        rows.append({'protocol':'network','resource':list(res),'sector':list(sec),'recovery':mode,'probe':probe,'basis':basis,'measure_discarded':False})
    if plan.omit_z_ablation:
        for res,sec,probe,basis in itertools.product([r for r in plan.resources if r[1]==1],plan.sectors,probes,bases):
            rows.append({'protocol':'network','resource':list(res),'sector':list(sec),'recovery':'omit_z','probe':probe,'basis':basis,'measure_discarded':False})
    for protocol,enabled in [('direct_preparation',plan.direct_preparation_baseline),('swap_transfer',plan.swap_transfer_baseline)]:
        if enabled:
            for probe,basis in itertools.product(probes,bases):
                rows.append({'protocol':protocol,'resource':[0,0],'sector':[0,0],'recovery':'none','probe':probe,'basis':basis,'measure_discarded':False})
    # Readout-calibration circuits are generated only after compilation reveals
    # every routed physical receiver pair. A fixed logical calibration can miss
    # pairs when final layouts differ across circuits.
    if plan.discarded_diagnostics:
        for res,sec,probe,basis in itertools.product(plan.resources,plan.sectors,('0','1','+','+i'),('XX','YY','ZZ')):
            rows.append({'protocol':'discarded_diagnostic','resource':list(res),'sector':list(sec),'recovery':'raw','probe':probe,'basis':basis,'measure_discarded':True})
    rng=np.random.default_rng(plan.seed);order=rng.permutation(len(rows))
    out=[]
    for pos,original in enumerate(order):
        row=rows[int(original)].copy();row.update(acquisition_index=pos,design_index=int(original),circuit_name=f'rev4_{pos:05d}',shots=plan.shots);out.append(row)
    return out

def budget(plan:Plan):
    rows=manifest(plan);totals={}
    for r in rows:totals[r['protocol']]=totals.get(r['protocol'],0)+1
    by_resource={''.join(map(str,res)):sum(r['protocol']=='network' and tuple(r['resource'])==tuple(res) for r in rows) for res in plan.resources}
    if len(set(by_resource.values()))!=1:raise AssertionError('Network design is not balanced across the four resources')
    return {'circuits_before_backend_specific_readout_calibration':len(rows),
            'shots_per_circuit':plan.shots,
            'shots_before_backend_specific_readout_calibration':len(rows)*plan.shots,'by_protocol':totals,
            'network_circuits_by_resource':by_resource,'matched_four_resource_design':True,
            'readout_calibration_design':'If enabled, compilation adds 8 circuits (4 before + 4 after) for every routed physical receiver pair; plan.json records the exact final budget.',
            'qpu_seconds':'not determined until backend-specific compilation/timing; shots are not a usage-time estimate'}

def _write_json_atomic(path:Path,value):
    """Write a checkpoint without exposing a partially written JSON file."""
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    fd,name=tempfile.mkstemp(prefix=path.name+'-',suffix='.tmp',dir=path.parent);os.close(fd);tmp=Path(name)
    try:
        tmp.write_text(json.dumps(safe_json(value),indent=2),encoding='utf-8')
        os.replace(tmp,path)
    finally:
        if tmp.exists():tmp.unlink()

def _manifest_sha256(rows):
    payload=json.dumps(rows,sort_keys=True,separators=(',',':')).encode()
    return hashlib.sha256(payload).hexdigest()

def prepare_probe(qc,probe,low,high):
    state=PROBES[probe];theta=2*np.arccos(abs(state[0]));phi=np.angle(state[1])-np.angle(state[0]) if abs(state[0]*state[1])>1e-15 else 0
    qc.ry(float(theta),low);qc.rz(float(phi),low);qc.cx(low,high)

def build_circuit(row,measure=True):
    from qiskit import QuantumCircuit,QuantumRegister,ClassicalRegister
    q=QuantumRegister(5,'q');c=ClassicalRegister(2,'c')
    qc=QuantumCircuit(q,c,name=row['circuit_name'])
    d=None
    if row['measure_discarded']:d=ClassicalRegister(3,'d');qc.add_register(d)
    protocol=row['protocol'];M1,M2=row['resource'];x,m=row['sector']
    if protocol=='readout_calibration':
        bit=int(row['probe'],2)
        if bit&1:qc.x(3)
        if bit&2:qc.x(4)
    elif protocol=='direct_preparation':prepare_probe(qc,row['probe'],3,4)
    elif protocol=='swap_transfer':
        prepare_probe(qc,row['probe'],0,1);qc.barrier();qc.swap(1,4);qc.swap(0,3)
    else:
        prepare_probe(qc,row['probe'],0,1)
        if m:qc.x(2)
        qc.h(2)
        if M1:qc.x(3)
        if M2:qc.x(4)
        qc.cx(2,3);qc.cx(2,4);qc.barrier()
        for gate,qubits,_ in transfer_gates(x,m):
            if gate=='cx':qc.cx(*qubits)
            elif gate=='h':qc.h(qubits[0])
            elif gate=='x':qc.x(qubits[0])
        # Preserve the core/recovery boundary for explicit-overhead comparison.
        qc.barrier()
        if row['recovery'] in ('physical','omit_z'):
            if m^x:qc.x(4)
            if m^M1^M2:qc.x(3)
            if M2 and row['recovery']!='omit_z':qc.z(3)
    if measure:
        qc.barrier()
        for wire,axis in zip((4,3),row['basis']):
            if axis=='X':qc.h(wire)
            elif axis=='Y':qc.sdg(wire);qc.h(wire)
        # All basis rotations precede ALL measurements: these remain static circuits.
        if row['measure_discarded']:qc.h(2);qc.h(1)
        qc.measure(3,c[0]);qc.measure(4,c[1])
        if row['measure_discarded']:
            qc.measure(0,d[0]);qc.measure(1,d[1]);qc.measure(2,d[2])
    qc.metadata={k:v for k,v in row.items()};return qc

def verify_qiskit_model():
    """Run this after installing Qiskit, before authorizing QPU submission."""
    from qiskit.quantum_info import Statevector,partial_trace
    worst=0.;checked=0
    for res,sec,probe,mode in itertools.product(((0,0),(1,0),(0,1),(1,1)),((0,0),(1,0),(0,1),(1,1)),tuple(PROBES),('raw','physical')):
        row={'circuit_name':'test','protocol':'network','resource':res,'sector':sec,'probe':probe,'recovery':mode,'basis':'ZZ','measure_discarded':False}
        qc=build_circuit(row,measure=False);actual=np.asarray(partial_trace(Statevector.from_instruction(qc),[0,1,2]).data)
        target=encoding()@PROBES[probe]
        if mode=='raw':target=frame(*sec,*res)@target
        expected=np.outer(target,target.conj());err=np.linalg.norm(actual-expected);worst=max(worst,float(err));checked+=1
    for protocol in ('direct_preparation','swap_transfer'):
        for probe in PROBES:
            row={'circuit_name':'test','protocol':protocol,'resource':[0,0],'sector':[0,0],'probe':probe,'recovery':'none','basis':'ZZ','measure_discarded':False}
            actual=np.asarray(partial_trace(Statevector.from_instruction(build_circuit(row,False)),[0,1,2]).data)
            target=encoding()@PROBES[probe];worst=max(worst,float(np.linalg.norm(actual-np.outer(target,target.conj()))));checked+=1
    if worst>1e-10:raise AssertionError(f'Qiskit/independent-model mismatch {worst}')
    return {'status':'QISKIT_IDEAL_TEST_EXECUTED','checks':checked,'maximum_receiver_error':worst}

def safe_json(value):
    if isinstance(value,dict):return {str(k):safe_json(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)):return [safe_json(v) for v in value]
    if isinstance(value,(np.integer,)):return int(value)
    if isinstance(value,(np.floating,)):return float(value)
    if isinstance(value,(str,int,float,bool)) or value is None:return value
    if isinstance(value,datetime):return value.isoformat()
    return str(value)

def _compiled_metadata_row(backend,row,circ):
    two=sum(len(inst.qubits)==2 and inst.operation.name not in ('barrier','delay','measure') for inst in circ.data)
    layout=circ.layout.final_index_layout(filter_ancillas=True) if circ.layout is not None else None
    gates=[];receiver_measurement_physical={}
    for inst in circ.data:
        name=inst.operation.name;qq=tuple(circ.find_bit(q).index for q in inst.qubits)
        if name=='measure' and inst.clbits:
            cbit=circ.find_bit(inst.clbits[0]).index
            if cbit in (0,1):receiver_measurement_physical['q3' if cbit==0 else 'q4']=qq[0]
        props=None
        try:props=backend.target[name].get(qq)
        except (KeyError,AttributeError):pass
        if name not in ('barrier','measure','delay'):
            gates.append({'gate':name,'physical_qubits':list(qq),'duration_s':getattr(props,'duration',None),'reported_error':getattr(props,'error',None)})
    if set(receiver_measurement_physical)!= {'q3','q4'}:raise RuntimeError('Compiled circuit does not expose both receiver measurements')
    return {**row,'depth':circ.depth(),'native_two_qubit_gate_count':int(two),
            'final_logical_to_physical':layout,'receiver_measurement_physical':receiver_measurement_physical,
            'count_ops':dict(circ.count_ops()),'gate_calibration_records':gates}

def _pair_key(pair):
    return (int(pair['q3']),int(pair['q4']))

def _build_physical_readout_calibrations(backend,pairs,plan):
    """Compile four two-bit preparations on every routed receiver pair."""
    from qiskit import QuantumCircuit,QuantumRegister,ClassicalRegister
    from qiskit.transpiler.preset_passmanagers import generate_preset_pass_manager
    sources=[];compiled=[];rows=[]
    for pair_index,(q3,q4) in enumerate(sorted(pairs)):
        if q3==q4:raise RuntimeError('Receiver qubits cannot share a physical qubit')
        pm=generate_preset_pass_manager(backend=backend,optimization_level=3,seed_transpiler=plan.seed,
                                        initial_layout=[q3,q4])
        for bit in range(4):
            bits=format(bit,'02b');q=QuantumRegister(2,'q');c=ClassicalRegister(2,'c')
            row={'protocol':'readout_calibration','resource':[0,0],'sector':[0,0],'recovery':'none',
                 'probe':bits,'basis':'ZZ','measure_discarded':False,
                 'calibration_for_receiver_pair':{'q3':q3,'q4':q4},
                 'design_index':None,'acquisition_index':None,
                 'circuit_name':f'readout_pair_{q3}_{q4}_{bits}','shots':plan.shots}
            qc=QuantumCircuit(q,c,name=row['circuit_name'])
            if bit&1:qc.x(q[0])
            if bit&2:qc.x(q[1])
            qc.measure(q[0],c[0]);qc.measure(q[1],c[1]);qc.metadata=safe_json(row)
            isa=pm.run(qc);observed=_pair_key(_compiled_metadata_row(backend,row,isa)['receiver_measurement_physical'])
            if observed!=(q3,q4):raise RuntimeError(f'Readout calibration routed to {observed}, expected {(q3,q4)}')
            sources.append(qc);compiled.append(isa);rows.append(row)
    return sources,compiled,rows

def _exact_compiled_budget(rows,plan,receiver_pairs):
    totals={}
    for row in rows:totals[row['protocol']]=totals.get(row['protocol'],0)+1
    by_resource={''.join(map(str,res)):sum(r['protocol']=='network' and tuple(r['resource'])==tuple(res) for r in rows) for res in plan.resources}
    return {'circuits':len(rows),'shots_per_circuit':plan.shots,'total_requested_shots':len(rows)*plan.shots,
            'by_protocol':totals,'network_circuits_by_resource':by_resource,'matched_four_resource_design':True,
            'routed_receiver_pairs':[{'q3':q3,'q4':q4} for q3,q4 in sorted(receiver_pairs)],
            'readout_calibration_circuits_per_pair':8 if plan.readout_calibration else 0,
            'qpu_seconds':'not determined until backend-specific compilation/timing; shots are not a usage-time estimate'}

def runtime_sampler_capabilities():
    """Return the supported public Runtime Sampler API without using internals."""
    import inspect
    import qiskit_ibm_runtime
    sampler_class=getattr(qiskit_ibm_runtime,'SamplerV2',None)
    if sampler_class is None:sampler_class=getattr(qiskit_ibm_runtime,'Sampler',None)
    if sampler_class is None:
        raise ImportError('qiskit_ibm_runtime exposes neither SamplerV2 nor Sampler')
    run_parameters=inspect.signature(sampler_class.run).parameters
    return {'qiskit_ibm_runtime_version':qiskit_ibm_runtime.__version__,
            'sampler_class':f'{sampler_class.__module__}.{sampler_class.__name__}',
            'server_dry_run_supported':'dry_run' in run_parameters}

def _runtime_sampler_class():
    """Select the stable top-level SamplerV2 API across Runtime 0.49/0.50+."""
    import qiskit_ibm_runtime
    sampler_class=getattr(qiskit_ibm_runtime,'SamplerV2',None)
    if sampler_class is None:sampler_class=getattr(qiskit_ibm_runtime,'Sampler',None)
    if sampler_class is None:
        raise ImportError('Install a qiskit-ibm-runtime release exposing SamplerV2')
    return sampler_class

def recommend_physical_layout(backend,plan):
    """Choose one backend-aware five-qubit initial layout without submitting.

    Qiskit's layout search is run once on the longest network circuit.  The
    resulting five logical-to-physical assignments are then fixed for every
    circuit by ``compile_plan`` so all four resources remain matched.
    """
    from qiskit.transpiler.preset_passmanagers import generate_preset_pass_manager
    network_rows=[row for row in manifest(plan) if row['protocol']=='network']
    if not network_rows:raise RuntimeError('No network circuit is available for layout selection')
    candidates=[(len(build_circuit(row).data),row) for row in network_rows]
    representative=build_circuit(max(candidates,key=lambda item:item[0])[1])
    pm=generate_preset_pass_manager(backend=backend,optimization_level=3,seed_transpiler=plan.seed)
    trial=pm.run(representative)
    if trial.layout is None:raise RuntimeError('Backend transpilation did not return a layout')
    physical=list(trial.layout.initial_index_layout(filter_ancillas=True))[:5]
    if len(physical)!=5 or len(set(physical))!=5:
        raise RuntimeError(f'Automatic layout selection returned an invalid mapping: {physical}')
    if any(q<0 or q>=backend.num_qubits for q in physical):
        raise RuntimeError(f'Automatic layout contains an out-of-range qubit: {physical}')
    return [int(q) for q in physical]

def compile_plan(service,backend_name,physical_layout,plan,output):
    """Backend read/compile only. Does not submit any job."""
    import qiskit
    import qiskit_ibm_runtime
    from qiskit.transpiler.preset_passmanagers import generate_preset_pass_manager
    from qiskit import qpy
    require_allowed_backend(backend_name)
    from workflow_paths import validate_output
    out=validate_output(output);out.mkdir(parents=True,exist_ok=True)
    if any((out/n).exists() for n in ('plan.json','submitted_jobs.json','submission_intent.json')):
        raise FileExistsError('A compiled/submitted plan exists. Load it or use a new run_id; do not overwrite it.')
    if len(physical_layout)!=5 or len(set(physical_layout))!=5:raise ValueError('Supply five distinct physical-qubit indices in logical q0..q4 order')
    backend=service.backend(backend_name)
    status=backend.status()
    if not status.operational:raise RuntimeError(f'Backend {backend_name} is not operational')
    if getattr(backend.configuration(),'simulator',False):raise RuntimeError('A real QPU backend is required')
    if any(q<0 or q>=backend.num_qubits for q in physical_layout):raise ValueError('Physical-qubit index out of range')
    tests=verify_qiskit_model();rows=manifest(plan);circuits=[build_circuit(r) for r in rows]
    pm=generate_preset_pass_manager(backend=backend,optimization_level=3,seed_transpiler=plan.seed,initial_layout=list(physical_layout))
    compiled=list(pm.run(circuits))
    base_metadata=[_compiled_metadata_row(backend,row,circ) for row,circ in zip(rows,compiled)]
    measurement_pairs={_pair_key(item['receiver_measurement_physical']) for item in base_metadata}
    if plan.readout_calibration:
        calibration_sources,calibration_compiled,calibration_rows=_build_physical_readout_calibrations(backend,measurement_pairs,plan)
        # Bookend preparation/readout diagnostics; not an isolated measurement-error estimate.
        before_sources=[];before_compiled=[];before_rows=[]
        after_sources=[];after_compiled=[];after_rows=[]
        for phase,ss,cc,rr in [('before',before_sources,before_compiled,before_rows),
                               ('after',after_sources,after_compiled,after_rows)]:
            for source,isa,row in zip(calibration_sources,calibration_compiled,calibration_rows):
                new={**row,'calibration_epoch':phase,'circuit_name':row['circuit_name']+'_'+phase}
                src=source.copy(name=new['circuit_name']);out_circuit=isa.copy(name=new['circuit_name'])
                ss.append(src);cc.append(out_circuit);rr.append(new)
        circuits=before_sources+circuits+after_sources
        compiled=before_compiled+compiled+after_compiled
        rows=before_rows+rows+after_rows
    for index,row in enumerate(rows):
        row['acquisition_index']=index
        compiled[index].metadata=safe_json(row)
        circuits[index].metadata=safe_json(row)
    with (out/'logical_circuits.qpy').open('wb') as f:qpy.dump(circuits,f)
    with (out/'compiled_circuits.qpy').open('wb') as f:qpy.dump(compiled,f)
    metadata=[_compiled_metadata_row(backend,row,circ) for row,circ in zip(rows,compiled)]
    calibrated_pairs={_pair_key(item['receiver_measurement_physical']) for item in metadata if item['protocol']=='readout_calibration'}
    coverage={pair:sorted(set(item['probe'] for item in metadata if item['protocol']=='readout_calibration' and _pair_key(item['receiver_measurement_physical'])==pair)) for pair in calibrated_pairs}
    readout_audit={'measured_receiver_pairs':[{'q3':q3,'q4':q4} for q3,q4 in sorted(measurement_pairs)],
        'calibrated_pairs':[{'q3':q3,'q4':q4} for q3,q4 in sorted(calibrated_pairs)],
        'calibration_states_by_pair':{f'{q3},{q4}':states for (q3,q4),states in sorted(coverage.items())},
        'uncovered_pairs':[{'q3':q3,'q4':q4} for q3,q4 in sorted(measurement_pairs-calibrated_pairs)],
        'warning':'Backend-specific calibration circuits cover every routed receiver pair. No automatic readout mitigation is applied.'}
    _write_json_atomic(out/'readout_pair_audit.json',readout_audit)
    if plan.readout_calibration and (readout_audit['uncovered_pairs'] or any(states!=['00','01','10','11'] for states in coverage.values())):
        raise RuntimeError('Compiled receiver pairs are not all covered by the readout calibration circuits')
    props=backend.properties()
    if props is not None:_write_json_atomic(out/'calibration_at_compile.json',{'captured_utc':datetime.now(timezone.utc).isoformat(), 'caveat':'Compile-time snapshot; not guaranteed execution-time calibration', 'properties':props.to_dict()})
    _write_json_atomic(out/'manifest.json',rows);_write_json_atomic(out/'compiled_metadata.json',metadata)
    manifest_sha=_manifest_sha256(rows)
    authorization_token='SUBMIT-'+manifest_sha[:20]
    exact_budget=_exact_compiled_budget(rows,plan,measurement_pairs)
    plan_record={'schema_version':2,'plan':asdict(plan),'precompile_budget':budget(plan),'budget':exact_budget,'backend':backend_name,
                 'backend_operational_at_compile':bool(status.operational),'backend_pending_jobs_at_compile':int(status.pending_jobs),
                 'initial_layout':list(physical_layout),'compiled_circuits':len(compiled),
                 'qiskit_version':qiskit.__version__,'qiskit_ibm_runtime_version':qiskit_ibm_runtime.__version__,
                 'manifest_sha256':manifest_sha,'submission_authorization_token':authorization_token,
                 'utc':datetime.now(timezone.utc).isoformat(),'model_tests':tests,'readout_pair_audit':readout_audit,
                 'status':'COMPILED_NOT_SUBMITTED'}
    from workflow_paths import sha256, code_fingerprint
    plan_record.update(compiled_qpy_sha256=sha256(out/'compiled_circuits.qpy'), logical_qpy_sha256=sha256(out/'logical_circuits.qpy'), code_hashes=code_fingerprint(), data_kind='COMPILED_PLAN_NOT_MEASUREMENT')
    _write_json_atomic(out/'plan.json',plan_record)
    return backend,compiled,rows

def load_compiled_plan(service,backend_name,output):
    """Resume a compiled acquisition without recompiling or changing its design."""
    import qiskit
    from qiskit import qpy
    require_allowed_backend(backend_name)
    out=Path(output);plan_info=json.loads((out/'plan.json').read_text());rows=json.loads((out/'manifest.json').read_text())
    if plan_info.get('status')!='COMPILED_NOT_SUBMITTED':raise RuntimeError('Compiled plan is not in the expected pre-submission state')
    if plan_info['backend']!=backend_name:raise ValueError('Requested backend does not match the compiled plan')
    if plan_info.get('qiskit_version')!=qiskit.__version__:raise RuntimeError('Qiskit version changed after compilation; recompile into a new acquisition directory')
    if plan_info.get('manifest_sha256')!=_manifest_sha256(rows):raise RuntimeError('Manifest hash mismatch')
    from workflow_paths import sha256
    if sha256(out/'compiled_circuits.qpy')!=plan_info.get('compiled_qpy_sha256'):
        raise RuntimeError('Compiled QPY hash mismatch; do not submit altered circuits')
    with (out/'compiled_circuits.qpy').open('rb') as stream:circuits=qpy.load(stream)
    if len(circuits)!=len(rows) or len(rows)!=plan_info['budget']['circuits']:raise RuntimeError('Compiled circuit count mismatch')
    backend=service.backend(backend_name);status=backend.status()
    if not status.operational:raise RuntimeError(f'Backend {backend_name} is not operational')
    if getattr(backend.configuration(),'simulator',False):raise RuntimeError('A real QPU backend is required')
    return backend,circuits,rows

def server_dry_run_compiled(backend,circuits,rows,output,max_circuits_per_job=300,max_execution_time=600):
    """Submit IBM server-side dry runs only; no QPU execution or manuscript data."""
    out=Path(output);plan_info=json.loads((out/'plan.json').read_text());target=out/'server_dry_run_jobs.json'
    if target.exists():raise FileExistsError('Server dry-run record already exists')
    if plan_info.get('manifest_sha256')!=_manifest_sha256(rows):raise RuntimeError('Manifest hash mismatch')
    capabilities=runtime_sampler_capabilities()
    if not capabilities['server_dry_run_supported']:
        record={'status':'CLIENT_VALIDATION_PASSED_SERVER_DRY_RUN_UNAVAILABLE',
                'qpu_execution':False,'jobs':[],'sampler_api':capabilities,
                'note':'This installed qiskit-ibm-runtime version has no public dry_run argument. No IBM job was submitted. Upgrade to a compatible newer release for an IBM server dry run.'}
        _write_json_atomic(target,record)
        return record
    Sampler=_runtime_sampler_class()
    sampler=Sampler(mode=backend,options={'max_execution_time':max_execution_time,
        'environment':{'job_tags':['exact-channel-equivalence','server-dry-run',plan_info['manifest_sha256'][:16]]}})
    entries=[]
    for start in range(0,len(circuits),max_circuits_per_job):
        stop=min(start+max_circuits_per_job,len(circuits))
        job=sampler.run(circuits[start:stop],shots=rows[0]['shots'],dry_run=True)
        entries.append({'job_id':job.job_id(),'start':start,'stop':stop,'backend':backend.name,
                        'dry_run':True,'submitted_utc':datetime.now(timezone.utc).isoformat()})
        _write_json_atomic(target,entries)
    return {'status':'SERVER_DRY_RUN_SUBMITTED','jobs':entries,'qpu_execution':False,
            'sampler_api':capabilities}

def submit_compiled(backend,circuits,rows,output,*,submit=False,max_total_shots=None,
                    authorization_token='',max_circuits_per_job=300,max_execution_time=600,
                    batch_max_time='10m',execution_mode='job'):
    """Explicitly authorized hardware submission. Never silently resubmit.

    Job mode is the default: a large design need not fit within a batch TTL.
    The per-job QPU-time cap and shot ceiling are NOT a price guarantee.
    """
    from contextlib import nullcontext
    from workflow_paths import validate_output, sha256
    require_allowed_backend(backend.name)
    out=validate_output(output)
    total=sum(r['shots'] for r in rows)
    if not submit:return {'status':'NOT_SUBMITTED','circuits':len(circuits),'total_requested_shots':total}
    plan_info=json.loads((out/'plan.json').read_text())
    if plan_info['backend']!=backend.name:raise ValueError('Backend does not match compiled plan')
    if plan_info['plan']['stage']!='full':raise ValueError('Cannot submit legacy SCREEN circuits as FULL tomography')
    if plan_info.get('manifest_sha256')!=_manifest_sha256(rows):raise RuntimeError('Manifest hash mismatch before submission')
    if sha256(out/'compiled_circuits.qpy')!=plan_info.get('compiled_qpy_sha256'):raise RuntimeError('Compiled QPY hash mismatch')
    if authorization_token!=plan_info.get('submission_authorization_token'):raise ValueError('Exact compilation-specific authorization is required')
    if max_total_shots is None or total!=max_total_shots:raise ValueError('Authorize the exact total number of requested shots')
    if total!=plan_info['budget']['total_requested_shots']:raise RuntimeError('Shot budget differs from compiled plan')
    if not isinstance(max_circuits_per_job,int) or max_circuits_per_job<1:raise ValueError('Invalid chunk size')
    if not isinstance(max_execution_time,int) or max_execution_time<1:raise ValueError('Invalid per-job time cap')
    if len(circuits)!=len(rows) or len({r['shots'] for r in rows})!=1:raise ValueError('Circuit/shot mismatch')
    validate_full_design(rows)
    if execution_mode not in ('job','batch'):raise ValueError('execution_mode must be job or batch')
    index=out/'submitted_jobs.json';intent=out/'submission_intent.json'
    if index.exists() or intent.exists():raise FileExistsError('Submission checkpoint exists. Inspect/recover it; never delete it just to rerun.')
    # Recheck actual backend immediately before consuming allocation.
    if getattr(backend.configuration(),'simulator',False):raise RuntimeError('A real backend is required')
    if not backend.status().operational:raise RuntimeError('Backend is not operational')
    Sampler=_runtime_sampler_class()
    acquisition_tag=out.name.replace('_','-')[:40]+'-'+plan_info['manifest_sha256'][:8]
    _write_json_atomic(intent,{'status':'SUBMISSION_INTENT_RECORDED_NO_JOB_ID_YET','backend':backend.name,
        'manifest_sha256':plan_info['manifest_sha256'],'total_requested_shots':total,
        'acquisition_tag':acquisition_tag,'created_utc':datetime.now(timezone.utc).isoformat(),
        'execution_mode':execution_mode,
        'recovery_note':'If interrupted, query IBM jobs by the saved tag before retrying. Never delete this file blindly.'})
    props=backend.properties()
    if props is not None:
        _write_json_atomic(out/'calibration_at_submission.json',{'captured_utc':datetime.now(timezone.utc).isoformat(),
            'caveat':'Submission-time snapshot; queue delay may separate it from actual execution', 'properties':props.to_dict()})
    options={'max_execution_time':max_execution_time,
             'dynamical_decoupling':{'enable':False},
             'twirling':{'enable_gates':False,'enable_measure':False},
             'environment':{'job_tags':['exact-channel-equivalence',acquisition_tag,plan_info['manifest_sha256'][:16]]}}
    _write_json_atomic(out/'runtime_options.json',options)
    if execution_mode=='batch':
        from qiskit_ibm_runtime import Batch
        context=Batch(backend=backend,max_time=batch_max_time)
    else:context=nullcontext(backend)
    entries=[]
    with context as mode:
        sampler=Sampler(mode=mode,options=options)
        for start in range(0,len(circuits),max_circuits_per_job):
            stop=min(start+max_circuits_per_job,len(circuits))
            job=sampler.run(circuits[start:stop],shots=rows[0]['shots'])
            entries.append({'job_id':job.job_id(),'start':start,'stop':stop,'backend':backend.name,
                            'batch_id':getattr(mode,'session_id',None) if execution_mode=='batch' else None,
                            'submitted_utc':datetime.now(timezone.utc).isoformat()})
            _write_json_atomic(index,entries)
    _write_json_atomic(intent,{**json.loads(intent.read_text()),'status':'ALL_CHUNKS_SUBMITTED',
                               'job_count':len(entries),'completed_utc':datetime.now(timezone.utc).isoformat()})
    return {'status':'SUBMITTED_NOT_YET_MEASURED','execution_mode':execution_mode,'jobs':entries,'total_requested_shots':total}


def validate_full_design(rows):
    """Fail closed if even one required resource/sector/probe/basis is missing."""
    from collections import Counter
    actual=Counter((tuple(r['resource']),tuple(r['sector']),r['recovery'],r['probe'],r['basis'])
                   for r in rows if r['protocol']=='network')
    expected=Counter(itertools.product(sorted(MATCHED_RESOURCES),sorted(MATCHED_SECTORS),
                                     ('raw','physical'),('0','1','+','+i','chi'),SETTINGS))
    if actual!=expected:raise ValueError('FULL network must contain exactly 1440 matched circuits, with no missing/duplicate settings')
    shots={int(r['shots']) for r in rows if r['protocol']=='network'}
    if len(shots)!=1 or min(shots)<1:raise ValueError('Network shots must be identical and positive')
    return {'status':'FULL_DESIGN_VALID','network_circuits':1440,'resources':4,'sectors':4,
            'inputs':5,'measurement_bases':9,'recoveries':['raw','physical'],'input_code_y':0}


def find_submission_jobs(service,output,limit=100):
    """Read-only recovery aid for an interrupted submission checkpoint."""
    out=Path(output);intent=json.loads((out/'submission_intent.json').read_text())
    tag=intent['acquisition_tag'];backend=intent['backend']
    jobs=service.jobs(limit=limit,backend_name=backend,job_tags=['exact-channel-equivalence',tag])
    return [{'job_id':job.job_id(),'status':str(job.status()),'backend':backend,
             'session_id':getattr(job,'session_id',None),'tags':safe_json(getattr(job,'tags',None))} for job in jobs]

def collect_results(service,output,wait=False):
    """Collect existing job IDs, checkpoint each completed chunk; NEVER submit.

    Pending jobs return PENDING by default. Full data are written only after all
    chunks pass the manifest, backend, shot, bit-order and circuit metadata checks.
    """
    from workflow_paths import validate_output, sha256
    from collections import Counter
    out=validate_output(output)
    rows=json.loads((out/'manifest.json').read_text());jobs=json.loads((out/'submitted_jobs.json').read_text())
    info=json.loads((out/'plan.json').read_text());require_allowed_backend(info['backend'])
    validate_full_design(rows)
    if info.get('manifest_sha256')!=_manifest_sha256(rows):raise RuntimeError('Manifest changed')
    indices=[i for j in jobs for i in range(j['start'],j['stop'])]
    if sorted(indices)!=list(range(len(rows))):raise RuntimeError('Partial/duplicate submission. Inspect saved IDs; do not silently call this a complete run.')
    cache=out/'collected_chunks';cache.mkdir(exist_ok=True)
    records=[];joint=[];metadata=[];pending=[]
    for item in jobs:
        filename=cache/(item['job_id']+'.json')
        if filename.is_file():
            payload=json.loads(filename.read_text())
            if payload.get('manifest_sha256')!=info['manifest_sha256']:raise RuntimeError('Cached chunk manifest mismatch')
        else:
            job=service.job(item['job_id'])
            actual_backend=job.backend().name
            if actual_backend!=info['backend']:raise RuntimeError('Retrieved job backend differs from the compiled plan')
            status=str(job.status()).upper().split('.')[-1]
            if status in ('ERROR','CANCELLED','CANCELED'):raise RuntimeError(f"Job {item['job_id']} failed: {status}; preserve completed chunks")
            if not wait and status not in ('DONE','COMPLETED'):
                pending.append({'job_id':item['job_id'],'status':status});continue
            result=job.result()
            if len(result)!=item['stop']-item['start']:raise RuntimeError('Returned circuit count mismatch')
            rr=[];jj=[];pub_meta=[]
            for offset,pub in enumerate(result):
                row=rows[item['start']+offset];counts=pub.data.c.get_counts()
                if set(counts)-{'00','01','10','11'} or any(int(v)!=v or v<0 for v in counts.values()):raise RuntimeError('Invalid receiver bit strings/counts')
                if sum(counts.values())!=row['shots']:raise RuntimeError('Shot total mismatch')
                meta=safe_json(pub.metadata)
                cm=meta.get('circuit_metadata',{}) if isinstance(meta,dict) else {}
                if cm and (cm.get('circuit_name')!=row['circuit_name'] or cm.get('acquisition_index')!=row['acquisition_index']):raise RuntimeError('Returned circuit metadata mismatch')
                record={**row,'job_id':out.name,'acquisition_id':out.name,
                        'hardware_job_id':item['job_id'],'backend':info['backend'],'counts':counts}
                rr.append(record);pub_meta.append({'acquisition_index':row['acquisition_index'],'metadata':meta})
                if row['measure_discarded']:
                    bc=pub.data.c.get_bitstrings();bd=pub.data.d.get_bitstrings()
                    if len(bc)!=len(bd):raise RuntimeError('Joint shot pairing mismatch')
                    jj.append({**row,'hardware_job_id':item['job_id'], 'joint_c_d_counts':dict(Counter(c+' '+d for c,d in zip(bc,bd)))})
            job_meta={'job_id':item['job_id'],'metrics':safe_json(job.metrics()),
                      'result_metadata':safe_json(result.metadata),'pub_metadata':pub_meta}
            payload={'manifest_sha256':info['manifest_sha256'],'records':rr,'joint':jj,'job_metadata':job_meta}
            _write_json_atomic(filename,payload)
        records.extend(payload['records']);joint.extend(payload['joint']);metadata.append(payload['job_metadata'])
    if pending:
        status={'status':'PENDING_HARDWARE_JOBS','completed_circuits':len(records),'pending_jobs':pending,
                'note':'Completed chunks are cached. Rerun collect; no new submissions will be made.'}
        _write_json_atomic(out/'collection_status.json',status);return status
    if sorted(r['acquisition_index'] for r in records)!=list(range(len(rows))):raise RuntimeError('Incomplete cache')
    records.sort(key=lambda r:r['acquisition_index'])
    data={'schema_version':1,'data_kind':'HARDWARE','acquisition_id':out.name,'backend':info['backend'],
          'job_ids':[j['job_id'] for j in jobs],'receiver_bit_order':'q4 q3','input_code_y':0,
          'manifest_sha256':info['manifest_sha256'],'collection_utc':datetime.now(timezone.utc).isoformat(),
          'grouping_note':'job_id in records is the acquisition grouping key; hardware_job_id is the actual IBM job ID.',
          'records':records}
    _write_json_atomic(out/'receiver_counts.json',data)
    _write_json_atomic(out/'joint_discarded_counts.json',joint)
    _write_json_atomic(out/'job_metadata.json',metadata)
    per=out/'raw_counts';per.mkdir(exist_ok=True)
    for r in records:_write_json_atomic(per/(str(r['acquisition_index']).zfill(5)+'.json'),r)
    try:
        props=service.backend(info['backend']).properties()
        if props is not None:_write_json_atomic(out/'calibration_at_collection.json',
            {'captured_utc':datetime.now(timezone.utc).isoformat(),'caveat':'Collection time is not execution time','properties':props.to_dict()})
    except Exception as exc:
        _write_json_atomic(out/'calibration_collection_status.json',{'status':'SNAPSHOT_UNAVAILABLE','exception_type':type(exc).__name__})
    status={'status':'HARDWARE_RESULTS_COLLECTED','data_kind':'HARDWARE','circuits':len(records),
            'shots':sum(sum(r['counts'].values()) for r in records),'receiver_counts_sha256':sha256(out/'receiver_counts.json')}
    _write_json_atomic(out/'collection_status.json',status)
    return status

if __name__=='__main__':
    print(json.dumps(budget(Plan()),indent=2))
    print('FULL design only. No IBM service contacted; use notebook 02 for explicit authorization.')

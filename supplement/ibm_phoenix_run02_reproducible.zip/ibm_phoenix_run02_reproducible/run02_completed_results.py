"""Read-only reporting/export bridge for the completed run02 repair.

No IBM imports, no credential prompts, no optimization, no resampling. The
original acquisition, original analysis and repaired numeric outputs stay intact.
Only reports/step9_10 and Results/Exports receive new files.
"""
from __future__ import annotations
from pathlib import Path, PurePosixPath
from collections import Counter
from contextlib import contextmanager
from datetime import datetime, timezone
from html import escape
from itertools import product
import csv, hashlib, json, os, re, sys, tempfile, zipfile
import numpy as np

BRIDGE_VERSION = "run02-completed-report-export-1.0"
RUN_ID = "full_4resources_run02"
POLICY = "run02-fullreceiver-recovery-1.0"
COUNTS_SHA256 = "99ce131823c6bc7b1cf50599adc079fbcf708cc7f46f44b07b7c88b6c646b188"
EXPECTED_CODES = {'quantum_core.py': '224848759047b17e02e1413d9a0c728e7da74661f37a5272295b31ef7cf44af5', 'reanalyse_counts.py': 'bdeb454715ccb737a164fda391d869938ac968d52a2d481b9210c2648ba784de', 'count_level_gof.py': 'ea1e67228aab701eb1f8680a97bbc47f5de972606e4a52d1d26243f8463f1c7f', 'ibm_followup.py': '26563b3a8fa98c9129b98f74d90054ca262bc33076e66b654517b8d125f82db7', 'workflow.py': '2ae6eb159b87d15cb513cad8afe4c9dc7e033af21f3fa39a443bc942dc8e96c9', 'workflow_paths.py': 'ea1e153c16fad96ee0f990e3ada3ca69c66d5e4860d6fad18c11a55c62c5a919', 'hardware_diagnostics.py': 'df629dd008fa0e8df6a392c484a3010ecf952fc2e85ed677959f68b7e8dacc7a', 'full_receiver_solver_repair.py': '1374acad9ac0a9a35d573b8453ab02eef4b82e0f5293e09063c3249204e7bb50', 'run02_local_repair.py': '20f169cdb11faf072aa8d45c1547919a3dfa82fe757210616e3f18b30545c2f1'}
ORIGINAL_CODES = {k: v for k, v in EXPECTED_CODES.items()
                  if k not in ("run02_local_repair.py", "full_receiver_solver_repair.py")}
EXPECTED_REPAIRED_TABLES = {'direct_preparation/analysis_signature.json': 'e743810d0f59892cd496a242faac8bb7543f3cde75bdd8f253534a458db566d6', 'direct_preparation/analysis_status.json': '5b08224d0bee017afa60048ddb6aec7a92a0a478297dac490a7c8190b3263444', 'direct_preparation/count_level_gof.csv': 'fe3f9e32ec1b58a924e62c279b61b95f97d784d5bad6d74fec67c700645879e5', 'direct_preparation/gof_details/M00_x0m0_physical_process_b84a17fa/count_residuals.csv': 'd96ccb24367c9695a732114100d2554c6637590608ac0bb8127471060d9f032f', 'direct_preparation/gof_details/M00_x0m0_physical_process_b84a17fa/frozen_null.json': '0ea5c0ef0dffebfbb9d56923be9f66bde609313add27be6bd6014faff13eb353', 'direct_preparation/gof_details/M00_x0m0_physical_process_b84a17fa/repair_gof_result.json': '204d43d5436f5a5603ccf22a18326810ab49cf7a4f314349c46f69e544167bd1', 'direct_preparation/gof_details/M00_x0m0_physical_process_b84a17fa/repair_signature.json': '876789aa8e0cec9da086a7f50ccea26487ea3b33e84943e86e54c4dd6c4bb52f', 'direct_preparation/gof_details/M00_x0m0_physical_process_b84a17fa/solver_audit.jsonl': '3fd0b698b9a24643909db2fcccfc94ae38a57bda2982aa5d69b8cd98a1997dbf', 'direct_preparation/matrix_elements.csv': '2b7b945a78e322f118616c46fabf1551f66afce4a837d78f38e2e84a0111f635', 'direct_preparation/measured_cptni_fits.csv': 'fa01081fe156ddcd3f932114cdb7712b485059ca58272f725560ccda85c44ede', 'direct_preparation/measured_phase_comparison.csv': 'cd16af71c816a4fab182f20dbb303ee99879cecd7655570a9ccdb821b94153ab', 'direct_preparation/measured_recovery_comparison.csv': '7703741f562b3f2c276fc35a9aba6f2de114df21e80f56ebf257cdb5ea03115c', 'direct_preparation/measured_state_phases_concurrence.csv': '2c7991a4090fc96ce3dc491671d1e7d477470723ebfb96b99ccf141bcc2f7f37', 'direct_preparation/state_projection_audit.csv': 'a4b5c104baf981ee2ea41bda40178d33813a392c6cf804bdf5f64f87714aa866', 'direct_preparation/tomography_completeness.csv': '45bb58ff769132ebd6903301d2f85e38d11ea86fccab8ead9245070577075c51', 'hardware_diagnostics/calibration_gate_diagnostics.csv': '23a3b0f69f4846f7bbfe451e50dffc434feeb30bd528040cb8555497e3eac276', 'hardware_diagnostics/compiled_recovery_overhead.csv': '8fd9873bb905224494511292b25c1a497c18f0ee548e473b72f5e726c6fd3f76', 'hardware_diagnostics/diagnostics_status.json': '24cc2188caae7d49b8be2db18359d5c3bc6919b51c112bcdda4ebf340b234766', 'hardware_diagnostics/discarded_expectations.csv': '6d0b0e4d209607677b7500f6e540d1673e6e89798d6f5a7e68f4ba06b22cf187', 'hardware_diagnostics/final_layouts_and_counts_mapping.csv': 'a8e241aaa4798ebd566eaa82b98f6acaa7884b4547551282175cfd6f6f39e515', 'hardware_diagnostics/readout_response.csv': '61611c387db6651f381d56ef8429523b05a142ccc6092a7ba9728dd5e85b2bce', 'hardware_diagnostics/readout_response_summary.csv': 'bd41ae43755a3f740ccab07935ae469ba75dff1891a0c0693addc3b53b0f0b67', 'hardware_diagnostics/receiver_discarded_correlations.csv': '14ebb4378ef5e2852075b198531f9af5a9eff2529584d6d97ccab53c1a9d6485', 'matched_baseline_comparisons.csv': '8553598c1b49a9ac1633a4908bff016d5609eba19aa30faa250c007cc996c349', 'network/analysis_signature.json': '78d92d7d3959f185851ea86506d8116a9ee8c06fbcfca40961c6118093abdabc', 'network/analysis_status.json': 'cd67ac79e5cf087955e348a19cd38b467d372830feac65ecba6589875967bca8', 'network/count_level_gof.csv': 'e487604533aa762b3562866544e0ecc8e85be62e05e6ad31b72c7c1fbdc34ddc', 'network/gof_details/M00_x0m0_physical_process_b84a17fa/count_residuals.csv': '63a02cf29feefa0b9ce7e600461ee6ae5ac9248af28333e3ccff27505a717dc8', 'network/gof_details/M00_x0m0_raw_process_b84a17fa/count_residuals.csv': '8ead5518b18de11e3072807a77bbd0e0886d47c463e0587735b3f0850c86bfaf', 'network/gof_details/M00_x0m1_physical_process_b84a17fa/count_residuals.csv': '0dd606aad67587723f3392514af900c860b68fed2af6a0e8c83645ca263b6d35', 'network/gof_details/M00_x0m1_raw_process_b84a17fa/count_residuals.csv': 'eb8cde5291bf5c86eff7bac3bf25a4d3b8073d139ef21d53a70d709a0249427c', 'network/gof_details/M00_x1m0_physical_process_b84a17fa/count_residuals.csv': '4bffae1ee4422ee7d8bb669e4a1bfedbfdf217c7c75c643be0f4b6df2f0b3d59', 'network/gof_details/M00_x1m0_raw_process_b84a17fa/count_residuals.csv': '91fdb97da68ef985e8a18b6e3ca83f519c2e554887acc97987b6616cc923b8d9', 'network/gof_details/M00_x1m1_physical_process_b84a17fa/count_residuals.csv': '2d0f68277661b63148674faa14cab7261cd8c70ac40cc706550282d4dc1a3337', 'network/gof_details/M00_x1m1_raw_process_b84a17fa/count_residuals.csv': '418088571ba5e005601b8b91add46db944e01971c31bd2d8461b2164015971a7', 'network/gof_details/M01_x0m0_physical_process_b84a17fa/count_residuals.csv': 'fbca7463ea8cd62382d7fc58b03a954efefa60d678cd4a6380bf84d85bbc4f10', 'network/gof_details/M01_x0m0_raw_process_b84a17fa/count_residuals.csv': '115cc69d18a666354014a02cd987d709bdf92fd858ddae3f20b4a18f02922233', 'network/gof_details/M01_x0m1_physical_process_b84a17fa/count_residuals.csv': '888784cd79df5139326fdc34b71f8742ec5272c9096c1a0498c94ad9580e3a98', 'network/gof_details/M01_x0m1_raw_process_b84a17fa/count_residuals.csv': '09b3c137f66d5e164781253188c5bd7a78b87d636e1898db642dedb27a74a39e', 'network/gof_details/M01_x1m0_physical_process_b84a17fa/count_residuals.csv': 'e41be11647739d0184ca96ba053ed1496acabefb46f82599c067bb1106fb99ac', 'network/gof_details/M01_x1m0_raw_process_b84a17fa/count_residuals.csv': 'ca43f794761d4517d5a5e5e689484c3ad5c8a86a6fe05ffe59724cb92c40782d', 'network/gof_details/M01_x1m1_physical_process_b84a17fa/count_residuals.csv': '5c26212e1d2a6ae8dd0e999cff669fe1dfff2bbe70491bb4db36086ab35e85ea', 'network/gof_details/M01_x1m1_raw_process_b84a17fa/count_residuals.csv': '51a9b62f7d56748d62fc8078b0a42cf55600c08bf7d3a356a3d4617105870bcb', 'network/gof_details/M10_x0m0_physical_process_b84a17fa/count_residuals.csv': '22bb11e5fe117692a99756fccf5c0a0541d6e2e8ceefef24a7bf7169eeab402e', 'network/gof_details/M10_x0m0_raw_process_b84a17fa/count_residuals.csv': '073e85c5b790aee3e338dd31b7a6358b8ca757800c3920e98830ede93da772fb', 'network/gof_details/M10_x0m1_physical_process_b84a17fa/count_residuals.csv': '11307e56671134b1ae80a4640ab0abad08f7e418a2eda8a6e36ee02762561ed2', 'network/gof_details/M10_x0m1_raw_process_b84a17fa/count_residuals.csv': '45f15342d77d4da75095b7e3cb0238698a4deda678fe7f2fe93b371a77f6262f', 'network/gof_details/M10_x1m0_physical_process_b84a17fa/count_residuals.csv': '50e0976c9ed3e235cfac6a56b1060ecb1616e6e2b8a8feccb3613f0be7f7937f', 'network/gof_details/M10_x1m0_raw_process_b84a17fa/count_residuals.csv': 'f5577e1f6eabe7c7a4953949910e537c8a7096a14d145bf02f9e1c7eb9e7f348', 'network/gof_details/M10_x1m1_physical_process_b84a17fa/count_residuals.csv': 'e94b89e8c5321032a171b54fdda2ad49a817c0af94f837a3bed4ea1607d37015', 'network/gof_details/M10_x1m1_raw_process_b84a17fa/count_residuals.csv': '5dd76a2bff20262172d781f3cedbd127afb7baef897871d74ca129c61196094a', 'network/gof_details/M11_x0m0_physical_process_b84a17fa/count_residuals.csv': 'd3fe941f04cf7b723eb512656af043be5f4245786e5de6fd47b6383e6831a9e5', 'network/gof_details/M11_x0m0_raw_process_b84a17fa/count_residuals.csv': '43f257f95c98e9872c1fefe1bef363e91c88ea6da4cb0888c982e8be59ea2449', 'network/gof_details/M11_x0m1_physical_process_b84a17fa/count_residuals.csv': '953d355f520cbb41b2c23a8bf0945a0f2dcc4f44bcbe179d51a4db2a8142bb08', 'network/gof_details/M11_x0m1_raw_process_b84a17fa/count_residuals.csv': '0ebfda52c1462b1a166892c6560217ce257d870646a0e215bab3feecda9e5547', 'network/gof_details/M11_x1m0_physical_process_b84a17fa/count_residuals.csv': '217f166f452462062cc7d48a9f945ae2d5ad23e589197bd5765ee906f6b5369a', 'network/gof_details/M11_x1m0_raw_process_b84a17fa/count_residuals.csv': '5dfe37bcbd4457c20ccb281cecc8fb798c9ecb333547cee458f9aa4c89d490cd', 'network/gof_details/M11_x1m1_physical_process_b84a17fa/count_residuals.csv': '5ec0e2aca8277511470e4dac70146ac85103b5a8e1528fe90d90ce119ba4697d', 'network/gof_details/M11_x1m1_raw_process_b84a17fa/count_residuals.csv': '8fb24f2ea791a452efa2683d5103202b9555c9f4da25db0e91886b840939b00e', 'network/matrix_elements.csv': '8d9daafa68872a47d4cbb636593c1712498cf69184a5acedf72699a3a0d95390', 'network/measured_cptni_fits.csv': 'f99532c69ff91df1615b440a9f5aa85d75db6c02b4454e4a969a7c468e450cec', 'network/measured_phase_comparison.csv': '6cefa5ab087b66b3d64c7de750fe2415cf2abf8b0e1af3ad3384ac0b02a066bf', 'network/measured_recovery_comparison.csv': 'd1329dd0923173061423a0706aaa3bb3d8cec60ba66aa435f7ddf368a4a3af84', 'network/measured_state_phases_concurrence.csv': '48d6a554ed8766dc311f2964ca8c3abfb973dad3f624e949a710c26f721811c8', 'network/state_projection_audit.csv': 'f412e130617d1071f74bb983761d715f28388366900866bac76bdb3aaa6d62db', 'network/tomography_completeness.csv': '90a107ff012991cf85d4af7fbfb2f6ea6a36c278c1a2ea21d65ce0e24fd9f552', 'network_reuse_provenance.json': 'c7e30f86edbfd0bbee6669f843dff2c532c0694c1c0ada6cb4b273429c489a60', 'repair_completion.json': 'd78938f2e08ab2faaf6f8dd1e4654e0fd45886d244789c6d639ebce12636e05e', 'repair_identity.json': '557d01797589d1492b3a51407636cbfe76833bcfb53766e12053006d14ba9690', 'swap_transfer/analysis_signature.json': '74a1828becae8aa2838e3bf48c9936cd0019f18481901721c86b8bfbaea458b8', 'swap_transfer/analysis_status.json': 'a49da2964036e26669d10ac251197076af64383fbc304af5e87f422308a82b32', 'swap_transfer/count_level_gof.csv': '0882b12d82a96afed02a0dd7e6b87ff84148bf73232b402097562b0b3d7e7144', 'swap_transfer/gof_details/M00_x0m0_physical_process_b84a17fa/count_residuals.csv': '8d14351bc76e9d28d7edffa1cf6b6de6dea4f841133f4d96dc3dd055f5c13cf5', 'swap_transfer/gof_details/M00_x0m0_physical_process_b84a17fa/frozen_null.json': '72de3d5e8441db781cea543baf26422ea123bd3e4b7ff37583bc92cc9c173853', 'swap_transfer/gof_details/M00_x0m0_physical_process_b84a17fa/repair_gof_result.json': '477904fed72d4d54ba82445060606189fe2f36c4d4be6730e6ff2c0abdbffe54', 'swap_transfer/gof_details/M00_x0m0_physical_process_b84a17fa/repair_signature.json': 'a3e2fc295c49ae63f5335694109fe3639383470a81abe54f0c8b055cb152aef9', 'swap_transfer/gof_details/M00_x0m0_physical_process_b84a17fa/solver_audit.jsonl': '345fb059c20fc454547acefee6f51e5f3c1513cbeb3a93db4b9b9e4b8d037d2e', 'swap_transfer/matrix_elements.csv': '989861760943955e5736c8e6e96e678aa319f2977890a412539e16d20abbccf7', 'swap_transfer/measured_cptni_fits.csv': '128626bf2728e55a02080ca22d1574413b89ab190cf4fa9f44704d250209b1c3', 'swap_transfer/measured_phase_comparison.csv': 'a210ec4f2c75c33ff9bc759405f7dda7c0198b1fdb287dd1781f15ece9a1061f', 'swap_transfer/measured_recovery_comparison.csv': '7703741f562b3f2c276fc35a9aba6f2de114df21e80f56ebf257cdb5ea03115c', 'swap_transfer/measured_state_phases_concurrence.csv': 'df2423efba233e225f0f293385b2c96719065eef3277f0832591605ef6b87e5a', 'swap_transfer/state_projection_audit.csv': 'f8b8aaa8e60c13ca95853c14048a7e838ab5dab29a62eba2a25b1d112d6c344b', 'swap_transfer/tomography_completeness.csv': '58ca2377027f8f1a5cc455325f027c29996e7a512f504d1f257a69a0df34f1a2'}
PROTOCOLS = {"network": (48, 32, 32), "direct_preparation": (1, 1, 1), "swap_transfer": (1, 1, 1)}
NOTEBOOK_FILENAME = "analyze-phase-concurrence-cptni-gof.ipynb"
NOTICE = (
    "Saved IBM hardware measurements are analysed without new acquisition, refits, or resampling "
    "when a completed certified repair already exists. In the 48 network state rows, "
    "16 frame_tracked rows are derived from raw measurements, not independent acquisitions. "
    "Reported intervals represent counting uncertainty from this acquisition and do not "
    "cover all SPAM, drift, or calibration uncertainty. Missing phase bounds must not "
    "be replaced with zeros; inspect phase_warning. Validation is an evidence-integrity "
    "check, not proof of model correctness or publication readiness."
)

class CompletedResultError(RuntimeError):
    """Stop rather than use incomplete, mixed, or substituted analysis files."""

def require(condition, message):
    if not condition:
        raise CompletedResultError(message + "\n実測データや記録を削除せず、原因を確認してください。")

def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))

def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()

def json_blob(value):
    return json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False).encode("utf-8")

def safe_path(base, relative):
    """Paths in recorded provenance must be relative, local and symlink-free."""
    base = Path(base).resolve()
    text = str(relative)
    q = PurePosixPath(text)
    require(not q.is_absolute() and ".." not in q.parts and "\\" not in text
            and ":" not in text, "不正な記録内パス: " + text)
    p = base.joinpath(*q.parts)
    for item in [p, *p.parents]:
        if item == base:
            break
        require(not item.is_symlink(), "シンボリックリンクは使用できません: " + item.name)
    require(p.resolve().is_relative_to(base), "記録内のパスが対象フォルダの外です。")
    return p

def rows(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def atomic_write(path, blob):
    path = Path(path)
    require(not path.is_symlink(), "出力先にシンボリックリンクがあります。")
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(blob)
        os.replace(tmp, path)
    finally:
        Path(tmp).unlink(missing_ok=True)

def locate_project(explicit=None):
    def good(p):
        return ((p / "revision_project.json").is_file()
                and (p / "Results/02_hardware" / RUN_ID).is_dir())
    if explicit is not None:
        p = Path(explicit).expanduser().resolve()
        require(good(p), "PROJECT_ROOT に既存の Revision_fixed5 を指定してください。")
        return p
    cwd = Path.cwd().resolve()
    for p in [cwd, *cwd.parents]:
        if good(p):
            return p
    candidates = [p for p in cwd.iterdir() if p.is_dir() and good(p)]
    require(len(candidates) == 1,
            "プロジェクトを一意に見つけられません。工程9冒頭の PROJECT_ROOT に実在する保存先を指定してください。")
    return candidates[0].resolve()

@contextmanager
def read_export_lock(acq):
    """Share the existing workflow lock; not a cloud or analysis operation."""
    f = (Path(acq) / ".sequential_operation.lock").open("a+b")
    locked = False
    try:
        f.seek(0, 2)
        if f.tell() == 0:
            f.write(b"0"); f.flush()
        f.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            locked = True
        except OSError as exc:
            raise CompletedResultError("同じrun02を別カーネルで操作中です。並行操作を止めてください。") from exc
        yield
    finally:
        if locked:
            f.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)
        f.close()

def checked_array(path, shape):
    a = np.load(path, allow_pickle=False)
    require(a.shape == shape and np.isfinite(a).all(), "行列の形・有限性の確認に失敗: " + Path(path).name)
    return a

def partial_output(J, dout):
    return np.trace(J.reshape(2, dout, 2, dout), axis1=1, axis2=3)

def audit_matrix(path, kind):
    dout = 4 if kind == "cptp" else 2
    shape = (8, 8) if kind == "cptp" else (4, 4)
    J = checked_array(path, shape)
    require(np.linalg.norm(J - J.conj().T) <= 2e-5, "エルミート性の検査に失敗: " + Path(path).name)
    require(np.linalg.eigvalsh(J).min() >= -2e-6, "正値性の検査に失敗: " + Path(path).name)
    if kind == "state":
        require(abs(np.trace(J) - 1) <= 2e-5, "状態のトレース確認に失敗。")
    elif kind == "cptni":
        require(np.linalg.eigvalsh(partial_output(J, dout)).max() <= 1 + 2e-6,
                "CP-TNIのトレース非増加検査に失敗。")
    else:
        require(np.linalg.norm(partial_output(J, dout) - np.eye(2)) <= 2e-5,
                "CPTPのトレース保存検査に失敗。")
    return J

def load_samples(path, names):
    with np.load(path, allow_pickle=False) as z:
        out = {}
        for name in names:
            require(name in z and z[name].shape == (500,) and np.isfinite(z[name]).all(),
                    "500標本の保存内容が不完全: " + Path(path).name + " / " + name)
            out[name] = z[name].copy()
        return out

class CompletedRun02Results:
    def __init__(self, root=None, repair_directory=None):
        self.root = locate_project(root)
        self.acq = safe_path(self.root, "Results/02_hardware/" + RUN_ID)
        self.explicit_repair = repair_directory
        self.repair = None
        self.summary = None
        self.tables = {}
        self.report_dir = safe_path(self.acq, "reports/step9_10")
        self.reported = False

    def _select_repair(self):
        if self.explicit_repair is not None:
            selected = safe_path(self.root, self.explicit_repair)
        elif (self.acq / "latest_gof_repair.json").is_file():
            selected = safe_path(self.root, read_json(self.acq / "latest_gof_repair.json")["repair_directory"])
        else:
            candidates = sorted((self.acq / "repairs").glob("gof_repair_*/repair_completion.json"))
            require(len(candidates) == 1,
                    "完了した修復結果を一意に見つけられません。修復済みフォルダを確認してください。複数ある場合は REPAIR_DIRECTORY を明示します。")
            selected = candidates[0].parent
        require(selected.resolve().is_relative_to((self.acq / "repairs").resolve()), "修復先がrun02のrepairs外です。")
        # Check components again even if selected by glob.
        selected = safe_path(self.root, selected.relative_to(self.root).as_posix())
        require((selected / "repair_completion.json").is_file(), "修復完了記録がありません。工程8を自動再実行することはありません。")
        return selected

    def _acquisition(self):
        src = self.acq / "receiver_counts.json"
        require(src.is_file(), "run02の receiver_counts.json がありません。再測定せず元の保存先を確認してください。")
        require(digest(src) == COUNTS_SHA256, "今回の修復結果と実測カウントのSHA-256が一致しません。")
        data = read_json(src)
        require(data.get("data_kind") == "HARDWARE" and data.get("acquisition_id") == RUN_ID,
                "HARDWARE/run02以外のカウントは使用できません。")
        plan = read_json(self.acq / "plan.json")
        manifest = read_json(self.acq / "manifest.json")
        require(plan["manifest_sha256"] == hashlib.sha256(json.dumps(manifest,sort_keys=True,separators=(",",":")).encode()).hexdigest() == data["manifest_sha256"],
                "測定マニフェストのハッシュ不一致。")
        require(plan["plan"]["stage"] == "full" and plan["backend"] == data["backend"], "実機/測定設計が一致しません。")
        for name, key in (("compiled_circuits.qpy", "compiled_qpy_sha256"), ("logical_circuits.qpy", "logical_qpy_sha256")):
            require(digest(self.acq / name) == plan[key], "回路ファイルのハッシュ不一致: " + name)
        jobs = read_json(self.acq / "submitted_jobs.json")
        intent = read_json(self.acq / "submission_intent.json")
        require(intent["status"] == "ALL_CHUNKS_SUBMITTED", "全ジョブの送信記録が確認できません。")
        require(len(jobs) == len(set(j["job_id"] for j in jobs)) == intent["job_count"], "ジョブIDに重複・欠落があります。")
        require([j["job_id"] for j in jobs] == data["job_ids"], "カウントとジョブIDの対応が異なります。")
        cursor = 0
        job_for_index = {}
        for job in jobs:
            require(job["start"] == cursor and job["stop"] > cursor and job["backend"] == data["backend"],
                    "分割ジョブの範囲に欠落・重複があります。")
            for i in range(job["start"], job["stop"]):
                job_for_index[i] = job["job_id"]
            cursor = job["stop"]
        records = data["records"]
        require(cursor == len(records) == len(manifest) == plan["budget"]["circuits"], "回路数が一致しません。")
        keys, total = [], 0
        for i, (record, entry) in enumerate(zip(records, manifest)):
            require(record["acquisition_index"] == i and all(record.get(k) == v for k, v in entry.items()),
                    "カウントとマニフェストの対応が不正: " + str(i))
            require(record["hardware_job_id"] == job_for_index[i], "回路とジョブIDの対応が不正。")
            counts = record["counts"]
            require(set(counts) <= {"00", "01", "10", "11"} and all(type(v) is int and v >= 0 for v in counts.values()),
                    "不正な受信カウント。")
            require(sum(counts.values()) == record["shots"] == plan["plan"]["shots"], "shotsが一致しません。")
            total += record["shots"]
            if record["protocol"] == "network":
                keys.append((*record["resource"], *record["sector"], record["recovery"], record["probe"], record["basis"]))
        expected = set(product((0,1),(0,1),(0,1),(0,1),("raw","physical"),("0","1","+","+i","chi"),
                               ("XX","XY","XZ","YX","YY","YZ","ZX","ZY","ZZ")))
        require(len(keys) == len(set(keys)) == 1440 and set(keys) == expected, "4資源fullの測定範囲が不完全です。")
        collected = read_json(self.acq / "collection_status.json")
        require(collected["status"] == "HARDWARE_RESULTS_COLLECTED" and collected["receiver_counts_sha256"] == COUNTS_SHA256
                and total == plan["budget"]["total_requested_shots"] == collected["shots"], "取得完了記録が一致しません。")
        return {"backend": data["backend"], "circuits": len(records), "shots": total,
                "job_count": len(jobs), "resources": 4, "counts_sha256": COUNTS_SHA256}

    def _protocol(self, protocol, expected_rows):
        folder = self.repair / protocol
        status = read_json(folder / "analysis_status.json")
        sig = read_json(folder / "analysis_signature.json")
        ns, nproc, ng = expected_rows
        require(status.get("status") == "ANALYSED" and status.get("data_kind") == "HARDWARE" and not status.get("warnings"),
                protocol + " の完了記録に未完了/警告があります。")
        require(status["source_counts_sha256"] == COUNTS_SHA256 == sig["input_sha256"], protocol + " の原カウントが一致しません。")
        require(sig["protocol"] == protocol and sig["code_hashes"] == (ORIGINAL_CODES if protocol == "network" else EXPECTED_CODES),
                protocol + " の解析コード署名が異なります。")
        for k in ("bootstraps", "gof_bootstraps", "seed", "solver", "count_gof"):
            require(sig[k] == self.identity["analysis_settings"][k], protocol + " の解析条件が異なります: " + k)
        names = ("measured_state_phases_concurrence.csv", "measured_cptni_fits.csv", "count_level_gof.csv")
        tables = [rows(folder / name) for name in names]
        require([len(t) for t in tables] == [ns, nproc, ng], protocol + " のCSV行数が不完全です。")
        require([status[k] for k in ("phase_rows","process_rows","gof_rows")] == [ns,nproc,ng], protocol + " の完了件数不一致。")
        for t in tables:
            require(all(r["data_kind"] == "HARDWARE" and r["protocol"] == protocol and r["acquisition_id"] == RUN_ID for r in t),
                    protocol + " のCSV由来が一致しません。")
        for row in tables[0]:
            require(int(row["bootstrap_replicates"]) == 500 and row["source_counts_sha256"] == COUNTS_SHA256, "状態標本/出典が不正。")
            audit_matrix(safe_path(folder,row["matrix_file"]), "state")
            load_samples(safe_path(folder,row["bootstrap_file"]), ("concurrence","fidelity","code_population","phase_rad"))
        for row in tables[1]:
            require(int(row["bootstrap_replicates"]) == 500 and row["source_counts_sha256"] == COUNTS_SHA256, "チャネル標本/出典が不正。")
            audit_matrix(safe_path(folder,row["matrix_file"]), "cptni")
            checked_array(safe_path(folder,row["ptm_file"]),(4,4))
            load_samples(safe_path(folder,row["bootstrap_file"]),("survival","identity_overlap","block_residual"))
        audit_counts = Counter()
        for row in tables[2]:
            require(int(row["resamples"]) == 500, "適合度検定の標本が500件ではありません。")
            detail = safe_path(folder,"gof_details/"+row["process_id"])
            audit_matrix(detail/"full_receiver_cptp_choi.npy", "cptp")
            samples=load_samples(detail/"parametric_null_statistics.npz",("pearson_X2","block_residual"))
            for stat, value_key, pkey in (("pearson_X2","pearson_X2","pearson_parametric_p"),
                                         ("block_residual","block_objective","block_parametric_p")):
                pval=(1+int(np.sum(samples[stat] >= float(row[value_key]))))/501
                require(abs(pval-float(row[pkey])) < 1e-12, "保存されたp値と帰無標本が一致しません。")
            if protocol != "network":
                require(row.get("solver_recovery_policy") == POLICY and row.get("no_failed_replicates_dropped") == "True"
                        and row.get("all_requested_replicates_completed") == "True", "修復方針/標本完了記録が不正。")
                checkpoint=read_json(detail/"bootstrap_checkpoint.json")
                require(len(checkpoint["pearson"]) == 500 and len(checkpoint["block_residual"]) == 500,
                        "基準回路の適合度チェックポイントが不完全です。")
                require(np.array_equal(samples["pearson_X2"],np.asarray(checkpoint["pearson"])) and
                        np.array_equal(samples["block_residual"],np.asarray(checkpoint["block_residual"])),
                        "保存標本とチェックポイントが異なります。")
                audits=[json.loads(line) for line in (detail/"solver_audit.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
                require(len(audits)==501, "数値ソルバー監査記録が不完全です。")
                require(Counter((a["role"],a.get("replicate")) for a in audits)
                        == Counter([("observed",None)]+[("null_refit",i) for i in range(1,501)]),
                        "監査記録の標本番号に欠落・重複があります。")
                for a in audits:
                    require(a["policy"] == POLICY, "数値監査方針が一致しません。")
                    if a["method"] == "legacy_SCS_accepted":
                        require(a["audit"]["accepted"] is True, "SCS監査が不合格です。")
                    elif a["method"] == "certified_same_count_recovery":
                        accepted=[x for x in a["detail"]["attempts"] if x["attempt"]==a["detail"]["accepted_attempt"]]
                        require(len(accepted)==1 and accepted[0]["accepted"] is True
                                and accepted[0]["convex_gap_upper_bound"]<=accepted[0]["convex_gap_tolerance"],
                                "代替解法の最適性監査が不合格です。")
                    else:
                        raise CompletedResultError("未知の数値監査方法です。")
                    audit_counts[a["method"]]+=1
        state_keys={(int(x["M1"]),int(x["M2"]),int(x["x"]),int(x["m"]),x["recovery"]) for x in tables[0]}
        process_keys={(int(x["M1"]),int(x["M2"]),int(x["x"]),int(x["m"]),x["recovery"]) for x in tables[1]}
        gof_keys={(int(x["M1"]),int(x["M2"]),int(x["x"]),int(x["m"]),x["recovery"]) for x in tables[2]}
        if protocol=="network":
            require(state_keys==set(product((0,1),(0,1),(0,1),(0,1),("raw","physical","frame_tracked")))
                    and len(state_keys)==ns, "4資源の状態評価の対応が不完全です。")
            require(process_keys==set(product((0,1),(0,1),(0,1),(0,1),("physical","frame_tracked")))
                    and len(process_keys)==nproc and gof_keys==process_keys, "4資源のプロセス/検定の対応が不完全です。")
        self.tables[protocol]={"state":tables[0],"process":tables[1],"gof":tables[2]}
        return {"states":ns,"processes":nproc,"gof_tests":ng,"bootstrap_replicates":500,
                "gof_bootstrap_replicates":500,"solver_audit_counts":dict(audit_counts)}

    def validate(self):
        """Verify completed evidence without any solver or device import."""
        self.repair=self._select_repair()
        complete=read_json(self.repair/"repair_completion.json")
        require(complete.get("status")=="RUN02_LOCAL_REPAIR_COMPLETED_AUTHOR_REVIEW_REQUIRED"
                and complete.get("data_kind")=="HARDWARE" and complete.get("run_id")==RUN_ID
                and complete.get("new_qpu_jobs_submitted")==0, "修復完了記録が期待するものではありません。")
        require(complete["repair_directory"]==self.repair.relative_to(self.root).as_posix(), "修復先の記録が一致しません。")
        for rel, h in EXPECTED_REPAIRED_TABLES.items():
            p = safe_path(self.repair, rel)
            require(p.is_file() and digest(p) == h,
                    "添付いただいた修復完了結果と表/監査記録が一致しません: " + rel)
        self.identity=read_json(self.repair/"repair_identity.json")
        ident=hashlib.sha256(json.dumps(self.identity,sort_keys=True).encode()).hexdigest()[:12]
        require(self.repair.name=="gof_repair_"+ident and self.identity["policy"]==POLICY
                and self.identity["run_id"]==RUN_ID and self.identity["counts_sha256"]==COUNTS_SHA256,
                "修復結果の識別情報が不一致です。")
        require(self.identity["code_hashes"]==EXPECTED_CODES, "修復時のコード署名が異なります。")
        for name, h in EXPECTED_CODES.items():
            require((self.root/name).is_file() and digest(self.root/name)==h, "解析コードが欠落または変更されています: "+name)
        require(self.identity["analysis_settings"]["bootstraps"]==500
                and self.identity["analysis_settings"]["gof_bootstraps"]==500, "今回の修復条件ではありません。")
        acquisition=self._acquisition()
        original=safe_path(self.root,self.identity["original_analysis"])
        require(original.is_relative_to(self.acq/"analyses"), "元解析先がrun02の外です。")
        self.original=original
        reuse=read_json(self.repair/"network_reuse_provenance.json")
        require(reuse["status"]=="REUSED_UNCHANGED_ORIGINAL_NETWORK_RESULTS"
                and reuse["source"]==(original/"network").relative_to(self.root).as_posix(), "本体再利用の由来が不一致。")
        for rel,h in reuse["source_files_sha256"].items():
            require(digest(safe_path(original/"network",rel))==h and digest(safe_path(self.repair/"network",rel))==h,
                    "完成済みnetworkの原本と修復先が一致しません: "+rel)
        results={p:self._protocol(p,n) for p,n in PROTOCOLS.items()}
        for p,n in PROTOCOLS.items():
            saved=read_json(self.repair/p/"analysis_status.json")
            require(complete["analyses"][p]==saved, "修復完了記録と解析状態が不一致: "+p)
        diag=read_json(self.repair/"hardware_diagnostics/diagnostics_status.json")
        require(diag.get("data_kind")=="HARDWARE" and diag.get("bootstrap_replicates")==500
                and complete["analyses"]["diagnostics"]==diag, "ハードウェア診断が未完了/不一致です。")
        diagnostic_counts={}
        for name,n in {"final_layouts_and_counts_mapping.csv":acquisition["circuits"],
                       "calibration_gate_diagnostics.csv":acquisition["circuits"],
                       "compiled_recovery_overhead.csv":diag["overhead_pairs"],
                       "readout_response.csv":diag["calibration_probability_rows"],
                       "receiver_discarded_correlations.csv":diag["connected_correlation_rows"]}.items():
            d=rows(self.repair/"hardware_diagnostics"/name)
            require(len(d)==n, "ハードウェア診断の行数が不一致: "+name)
            diagnostic_counts[name]=len(d)
        baseline=rows(self.repair/"matched_baseline_comparisons.csv")
        require(len(baseline)==complete["analyses"]["baseline_comparison_rows"]==32, "Baseline comparison表が不完全です。")
        self.tables["baselines"]=baseline
        # Make a digest of the evidence selected for export. Revalidate before step10.
        self.summary={"status":"REPAIRED_RUN02_RESULTS_VALIDATED_FOR_DISPLAY", "bridge_version":BRIDGE_VERSION,
                      "run_id":RUN_ID,"repair_directory":self.repair.relative_to(self.root).as_posix(),
                      "acquisition":acquisition,"protocols":results,"diagnostic_csv_rows":diagnostic_counts,
                      "matched_baseline_comparison_rows":len(baseline),"new_qpu_jobs_submitted":0,
                      "numerical_refits_performed":0,"original_results_modified":False,
                      "uploaded_reference_table_hashes_verified":len(EXPECTED_REPAIRED_TABLES),
                      "limitations":NOTICE,
                      "validation_scope":"File signatures/provenance, full-count coverage, saved point physicality, 500-sample completeness, saved p-values and solver audit. Not an independent statistical refit or verification of the cloud account."}
        return self.summary

    @staticmethod
    def _table(title, data, columns):
        columns=[c for c in columns if data and c in data[0]]
        h="<h3>"+escape(title)+"</h3><div style='overflow-x:auto'><table border='1' cellpadding='4'><thead><tr>"
        h+=''.join("<th>"+escape(c)+"</th>" for c in columns)+"</tr></thead><tbody>"
        for r in data:
            h+="<tr>"+''.join("<td>"+escape(str(r.get(c,"")))+"</td>" for c in columns)+"</tr>"
        return h+"</tbody></table></div>"

    def report(self, display_tables=True):
        self.reported=False
        with read_export_lock(self.acq):
            summary=self.validate()
            h="<!doctype html><html lang='en'><meta charset='utf-8'><title>run02 Repaired Results</title><body>"
            h+="<h1>full_4resources_run02: Repaired Analysis Results</h1><p>"+escape(NOTICE)+"</p>"
            h+="<p>Source repair: "+escape(summary["repair_directory"])+"</p>"
            for p in PROTOCOLS:
                h+=self._table(p+" — Phase and concurrence",self.tables[p]["state"],
                              ["M1","M2","x","m","recovery","phase_rad","phase_rad_lo","phase_rad_hi","ideal_phase_rad",
                               "concurrence","concurrence_lo","concurrence_hi","phase_localized_approximate_check","phase_warning"])
                h+="<details><summary>"+escape(p)+" — CP-TNI and goodness-of-fit</summary>"
                h+=self._table("CP-TNI",self.tables[p]["process"],["M1","M2","x","m","recovery","survival","identity_overlap",
                                 "block_residual","bootstrap_boundary_fraction"])
                h+=self._table("Count-level goodness-of-fit",self.tables[p]["gof"],["M1","M2","x","m","recovery","pearson_X2",
                                  "pearson_parametric_p","block_objective","block_parametric_p","resamples"])+"</details>"
            h+="<details><summary>Baseline comparisons (descriptive differences)</summary>"
            h+=self._table("Baseline comparison",self.tables["baselines"],list(self.tables["baselines"][0]))+"</details></body></html>"
            safe_path(self.acq,"reports/step9_10")
            atomic_write(self.report_dir/"validation.json",json_blob(summary))
            atomic_write(self.report_dir/"step9_results.html",h.encode("utf-8"))
            self.reported=True
        print("REPAIRED_RUN02_RESULTS_DISPLAYED_NO_RECOMPUTATION")
        print("Validated repair:",self.repair)
        print("Network: 48 states / 32 CP-TNI channels / 32 GOF tests. Each baseline: 1/1/1.")
        print("English HTML report:",self.report_dir/"step9_results.html")
        if display_tables:
            from IPython.display import display, HTML
            display(HTML(h))
        return summary

    def _files(self):
        """Tight allow-list: no homes, accounts, environment dumps or unrelated runs."""
        chosen={}
        def add(p):
            p=Path(p);rel=p.relative_to(self.root).as_posix()
            safe_path(self.root,rel)
            require(p.is_file(), "出力に必要なファイルがありません: "+rel)
            chosen[rel]=p
        for name in list(EXPECTED_CODES)+[
            "revision_project.json", "run02_repair_metadata.json", "requirements-offline.txt",
            "requirements-quantum.txt", "requirements-review.txt", "README.md",
            "LICENSE_NOTICE.md", "phoenix_hardware_evidence.py",
            "phoenix_acquisition_controller.py", "run02_completed_results.py",
            "analyze-phase-concurrence-cptni-gof.ipynb", "ibm_phoenix_calculations.ipynb",
            "config.json", "publication_export.py", "notebook_support.py"]:
            add(self.root/name)
        for name in ["README_RUN02_GOF_REPAIR_JA.md","NUMERICAL_METHOD.md","VALIDATION_RUN02_GOF_REPAIR.md"]:
            if (self.root/name).is_file():add(self.root/name)
        for name in ["receiver_counts.json","joint_discarded_counts.json","compiled_metadata.json","plan.json","manifest.json",
                     "submitted_jobs.json","submission_intent.json","collection_status.json","job_metadata.json","compiled_circuits.qpy",
                     "logical_circuits.qpy","readout_pair_audit.json","runtime_options.json","selected_initial_layout.json",
                     "sequential_config.json","latest_analysis.json"]:
            add(self.acq/name)
        for pattern in ("*calibration*.json","*backend*.json"):
            for p in self.acq.glob(pattern):add(p)
        allowed={".json",".jsonl",".csv",".npy",".npz",".png",".svg",".pdf",".txt",".md"}
        for folder in [self.original/"network", self.repair,
                       self.root/"regression", self.acq/"raw_counts"]:
            require(folder.is_dir(), "必要フォルダがありません: "+folder.name)
            for p in sorted(folder.rglob("*")):
                require(not p.is_symlink(), "結果内のシンボリックリンクは出力できません。")
                if (p.is_file() and p.suffix.lower() in allowed and p.name!="repair_error.json"
                    and not any(part.startswith('.') for part in p.relative_to(folder).parts)):
                    add(p)
        return chosen

    @staticmethod
    def _credential_check(name, blob):
        if Path(name).suffix.lower() not in {".json",".jsonl",".py",".md",".txt",".ipynb",".html",".csv"}:
            return
        # Do not print a matched secret. Research job IDs and SUBMIT plan IDs are not API keys.
        patterns=[rb"(?i)(?:api[_-]?key|apikey|access_token|refresh_token|password|client_secret)[\"']?\s*[:=]\s*[\"'][^\"'\r\n]{12,}[\"']",
                  rb"crn:v[0-9]+:[^\s\"'<>]+:[^\s\"'<>]+:[^\s\"'<>]+:[^\s\"'<>]+:a/[^\s\"'<>]+"]
        require(not any(re.search(p,blob) for p in patterns), "秘密情報の可能性があるためZIP作成を停止しました。対象ファイル: "+name)

    def _notebook(self):
        candidates=[]
        for folder in [self.root,self.root/"Results/Executed_Notebooks"]:
            if not folder.is_dir():continue
            for p in folder.glob("analyze-phase-concurrence-cptni-gof.ipynb"):
                try:nb=read_json(p)
                except (OSError,ValueError):continue
                if nb.get("metadata",{}).get("run02_results_bridge",{}).get("version")==BRIDGE_VERSION:
                    for c in nb.get("cells",[]):
                        if c.get("cell_type")=="code":c["outputs"]=[];c["execution_count"]=None
                        c["metadata"]={k:v for k,v in c.get("metadata",{}).items() if k in ("tags","jupyter")}
                    nb["metadata"].pop("widgets",None)
                    candidates.append((p,nb))
        require(bool(candidates), "修正版02ノートブックを既存プロジェクト直下に保存してください。")
        preferred=[x for x in candidates if x[0]==self.root/NOTEBOOK_FILENAME]
        if preferred:candidates=preferred
        blobs={hashlib.sha256(json_blob(nb)).hexdigest():nb for _,nb in candidates}
        require(len(blobs)==1, "修正版02が複数あり内容が異なります。使用する修正版1つをプロジェクト直下に置いてください。")
        return json_blob(next(iter(blobs.values())))

    def export(self):
        require(self.reported, "先に工程9の修正版セルを実行してください。工程1～8は不要です。")
        with read_export_lock(self.acq):
            summary=self.validate()   # refuse changed evidence since step9
            entries={n:p.read_bytes() for n,p in self._files().items()}
            cfg=read_json(self.acq/"sequential_config.json")
            entries["config.json"]=json_blob({"original_data":{"archive":"Inputs/Exact_Channel_Equivalence_hardware_reproducibility_archive.zip","normalized_counts":""},**cfg})
            entries[NOTEBOOK_FILENAME]=self._notebook()
            if (self.root/"08_resume_run02_gof_repair.ipynb").is_file():
                nb=read_json(self.root/"08_resume_run02_gof_repair.ipynb")
                for c in nb["cells"]:
                    if c["cell_type"]=="code":c["outputs"]=[];c["execution_count"]=None
                    c["metadata"]={k:v for k,v in c.get("metadata",{}).items() if k in ("tags","jupyter")}
                nb.get("metadata",{}).pop("widgets",None)
                entries["08_resume_run02_gof_repair.ipynb"]=json_blob(nb)
            # A portable locator is added to the ZIP ONLY. Do not overwrite the local old analysis pointer.
            prefix=self.acq.relative_to(self.root).as_posix()
            entries[prefix+"/latest_gof_repair.json"]=json_blob({"repair_directory":summary["repair_directory"],"policy":POLICY,"original_latest_analysis_unchanged":True})
            entries[prefix+"/reports/step9_10/validation.json"]=json_blob(summary)
            entries[prefix+"/reports/step9_10/step9_results.html"]=(self.report_dir/"step9_results.html").read_bytes()
            entries["README_STEP9_STEP10.md"]=(
                "# Repaired run02 reporting and export\n\n"
                "Use `analyze-phase-concurrence-cptni-gof.ipynb` to validate the attached "
                "completed repair, display stages 8-9, and create stage-10 local ZIPs. "
                "No IBM connection or new hardware job is needed for these saved results.\n\n"
                "Source: `"+summary["repair_directory"]+"`. "
                "The original latest_analysis.json is preserved.\n\n"
                +NOTICE+"\n\nThe original network fit is reused without alteration. "
                "Baseline GOF tests use 500 repaired parametric bootstrap replicates each. "
                "Solver audit records, matrices, and counting provenance are included. "
                "No online publication or GitHub upload is performed.\n"
            ).encode("utf-8")
            for name,blob in entries.items():self._credential_check(name,blob)
            inventory=[{"path":n,"sha256":hashlib.sha256(b).hexdigest(),"bytes":len(b)} for n,b in sorted(entries.items())]
            content_id=hashlib.sha256(json_blob(inventory)).hexdigest()
            manifest={"status":"COMPLETED_REPAIRED_RESULTS_LOCAL_EXPORT_ONLY","bridge_version":BRIDGE_VERSION,
                      "run_id":RUN_ID,"repair_directory":summary["repair_directory"],"files":inventory,"content_sha256":content_id,
                      "scope":"Reuses unchanged numeric files; outputs stripped from notebooks; no fitting/measurement/upload; source raw counts, original network, repair outputs and solver audit retained."}
            entries["RUN02_STEP10_EXPORT_MANIFEST.json"]=json_blob(manifest)
            entries["SHA256SUMS.txt"]=''.join(hashlib.sha256(b).hexdigest()+"  "+n+"\n" for n,b in sorted(entries.items())).encode()
            output=safe_path(self.root,"Results/Exports");output.mkdir(parents=True,exist_ok=True)
            products=[]
            for target in ("submission","GitHub"):
                p=output/(RUN_ID+"_step10_"+target+".zip")
                if p.exists():
                    # Keep a prior distinct export. Identical exports are simply reused.
                    try:
                        with zipfile.ZipFile(p) as z:
                            identical=(z.testzip() is None and len(z.namelist())==len(entries)
                                       and all(z.read("Revision_fixed5/"+n)==b for n,b in entries.items()))
                    except (OSError,ValueError,KeyError,zipfile.BadZipFile):identical=False
                    if identical:products.append(str(p));continue
                    stamp=datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
                    p=output/(RUN_ID+"_step10_"+target+"_"+stamp+".zip")
                fd,tmp=tempfile.mkstemp(prefix=p.stem+".",suffix=".tmp",dir=output);os.close(fd)
                try:
                    with zipfile.ZipFile(tmp,"w",zipfile.ZIP_DEFLATED,compresslevel=6) as z:
                        for name,blob in sorted(entries.items()):
                            zi=zipfile.ZipInfo("Revision_fixed5/"+name,date_time=(2026,10,25,0,0,0))
                            zi.compress_type=zipfile.ZIP_DEFLATED
                            z.writestr(zi,blob)
                    with zipfile.ZipFile(tmp) as z:
                        require(z.testzip() is None, "ZIP CRC検証に失敗しました。")
                        require(all(hashlib.sha256(z.read("Revision_fixed5/"+e["path"])).hexdigest()==e["sha256"] for e in inventory),
                                "ZIPの内容ハッシュ検証に失敗しました。")
                    os.replace(tmp,p)
                finally:
                    Path(tmp).unlink(missing_ok=True)
                products.append(str(p))
            atomic_write(self.report_dir/"step10_export_status.json",json_blob({"status":"RESULTS_AND_LOCAL_EXPORTS_READY_FOR_AUTHOR_REVIEW",
                         "run_id":RUN_ID,"files":[str(Path(p).relative_to(self.root).as_posix()) for p in products],
                         "content_sha256":content_id,"online_upload":False,"new_qpu_jobs":0,"refits":0}))
        print("RESULTS_AND_LOCAL_EXPORTS_READY_FOR_AUTHOR_REVIEW")
        for p in products:print(p)
        print("Original repaired ZIPs, hardware counts, and latest_analysis.json were preserved. No remote upload.")
        return {"status":"RESULTS_AND_LOCAL_EXPORTS_READY_FOR_AUTHOR_REVIEW","files":products,"uploaded":False}



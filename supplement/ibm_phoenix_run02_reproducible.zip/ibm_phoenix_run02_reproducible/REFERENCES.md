# Implementation references

The circuit, frame, encoding, original-data metadata and original analysis conventions come from the supplied Revision fixed3(1).zip and manuscript materials. New engineering changes are described in CHANGELOG.md. These external official references were checked for the implementation interface and state measure; they do not substantiate new hardware results.

- IBM Quantum, SamplerV2: https://quantum.cloud.ibm.com/docs/en/api/qiskit-ibm-runtime/sampler-v2
- IBM Quantum, SamplerOptions: https://quantum.cloud.ibm.com/docs/en/api/qiskit-ibm-runtime/options-sampler-options
- IBM Quantum, initialize account: https://quantum.cloud.ibm.com/docs/en/guides/initialize-account
- IBM Quantum, credential handling: https://quantum.cloud.ibm.com/docs/en/guides/save-credentials
- IBM Quantum, batch execution and TTL: https://quantum.cloud.ibm.com/docs/en/guides/run-jobs-batch
- IBM Quantum, quantum_info concurrence: https://quantum.cloud.ibm.com/docs/en/api/qiskit/quantum_info

Retrieved 23 October 2026. Service interfaces, account access and backend availability can change. Always record the installed package versions and actual job metadata. Authentication is not a statement that a QPU job has completed.


## fixed5: execution-environment documentation

See the official IJulia, IPython, Jupyter Client, Python venv, and Conda.jl references listed in readme_fixed.md. No new quantum-information claims are introduced by this environment-only update.

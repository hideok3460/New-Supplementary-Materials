"""Audited numerical recovery for the original full-receiver GOF likelihood.

No hardware access. No failed resample is dropped or replaced. Legacy SCS is
attempted first; a rejected numerical solution is re-solved on the SAME counts
by a full-rank-capable PSD/TP factorization, accepted only with a convex lower-
bound certificate. The original J>=0, Tr_out J=I and probability floor remain.

This module is additive: original count_level_gof.py is not overwritten.
"""
from __future__ import annotations
from pathlib import Path
from contextlib import contextmanager
import hashlib, json, math, time, warnings
import numpy as np
from scipy.optimize import minimize

VERSION = 'run02-fullreceiver-recovery-1.0'
PSD_TOL = 2e-6                 # SAME as the original physicality audit
TP_TOL = 2e-5                  # SAME as the original physicality audit
FLOOR = 1e-10                  # SAME model probability floor
DUAL_GAP_TOL = 2e-7            # normalized negative-log-likelihood units
PROBE_ORDER = ('0','1','+','+i')
BASES = tuple(a+b for a in 'XYZ' for b in 'XYZ')
EYE2=np.eye(2, dtype=complex)
PAULI={'I':EYE2,'X':np.array([[0,1],[1,0]],complex),
       'Y':np.array([[0,-1j],[1j,0]],complex),'Z':np.diag([1.,-1.]).astype(complex)}
PROBES={'0':np.array([1,0],complex),'1':np.array([0,1],complex),
        '+':np.array([1,1],complex)/np.sqrt(2),'+i':np.array([1,1j],complex)/np.sqrt(2)}


def effect(J):
    return np.array([[np.trace(J[4*i:4*i+4,4*j:4*j+4]) for j in range(2)] for i in range(2)])


def design_operators():
    operators=[]
    for q in PROBE_ORDER:
        rho=np.outer(PROBES[q],PROBES[q].conj())
        for ab in BASES:
            for o in range(4):
                E=np.kron((EYE2+(-1)**(o>>1)*PAULI[ab[0]])/2,
                          (EYE2+(-1)**(o&1)*PAULI[ab[1]])/2)
                operators.append(np.kron(rho.T,E))
    return np.asarray(operators)


OPERATORS=design_operators()


def counts_array(counts):
    a=np.array([[counts[p][b].get(format(o,'02b'),0) for o in range(4)]
                for p in PROBE_ORDER for b in BASES],dtype=float)
    if (a.shape!=(36,4) or not np.isfinite(a).all() or np.any(a<0)
            or np.any(a!=np.floor(a)) or np.any(a.sum(axis=1)<=0)):
        raise ValueError('Expected finite integer counts, 36 complete settings with positive shots')
    return a


def counts_from_array(a):
    a=np.asarray(a)
    if a.shape!=(36,4) or not np.isfinite(a).all() or np.any(a<0) or np.any(a!=np.floor(a)):
        raise ValueError('Expected a 36x4 nonnegative integer count array')
    out={p:{} for p in PROBE_ORDER}
    for i,(p,b) in enumerate((p,b) for p in PROBE_ORDER for b in BASES):
        out[p][b]={format(o,'02b'):int(a[i,o]) for o in range(4)}
    counts_array(out)
    return out


def count_digest(counts):
    return hashlib.sha256(counts_array(counts).astype('<i8').tobytes()).hexdigest()


def audit_choi(J):
    J=np.asarray(J,complex)
    if J.shape!=(8,8) or not np.isfinite(J).all():
        return {'accepted':False,'reason':'nonfinite_or_wrong_shape'}
    H=(J+J.conj().T)/2
    p=np.einsum('bij,ji->b',OPERATORS,H).real.reshape(36,4)
    minimum=float(np.linalg.eigvalsh(H).min());tp=float(np.linalg.norm(effect(H)-EYE2))
    return {'accepted':bool(minimum>=-PSD_TOL and tp<=TP_TOL),
            'choi_min_eigenvalue':minimum,'trace_preservation_residual_frobenius':tp,
            'hermiticity_residual':float(np.linalg.norm(J-J.conj().T)),
            'minimum_probability':float(p.min()),'maximum_row_sum_error':float(abs(p.sum(1)-1).max()),
            'psd_tolerance':PSD_TOL,'tp_tolerance':TP_TOL}


def convex_gap_bound(J,weights):
    """A posteriori lower bound for the convex, normalized negative log likelihood.

    G=grad f(J). For any Y with G-Y tensor I4>=0, convexity yields
    f(J*) >= f(J)-Tr(GJ)+Tr(Y). Construct Y from Tr_out(GJ), then shift
    it downward by the negative minimum eigenvalue of G-Y tensor I4.
    This is a valid lower bound even with the additional probability floor.
    It is a floating-point certificate, NOT an interval-arithmetic proof.
    """
    p=np.einsum('bij,ji->b',OPERATORS,J).real
    if np.any(p<=0) or not np.isfinite(p).all():return float('inf')
    G=-np.einsum('b,bij->ij',weights/p,OPERATORS)
    Y=effect(G@J);Y=(Y+Y.conj().T)/2
    slack=(G-np.kron(Y,np.eye(4)));slack=(slack+slack.conj().T)/2
    # Numerical safety margin makes the constructed dual slack slightly interior.
    delta=max(0.,-float(np.linalg.eigvalsh(slack).min()))+1e-12*(1+np.linalg.norm(G))
    return float(np.trace(G@J).real-np.trace(Y).real+2*delta)


class CertifiedLikelihood:
    """Same convex model, optimized through a nonconvex but surjective factor map.

    J=A (R R*) A*, A=(Tr_out RR*)^(-1/2) tensor I4. R is unrestricted 8x8;
    thus no rank restriction is imposed. Final iterates are NEVER eigenvalue-
    clipped or trace-renormalized as a substitute for optimization. Eigenvalue
    clipping below is used ONLY to choose an initial factor for the optimizer.
    A physical result is not enough: the convex gap test is mandatory.
    """
    def __init__(self,observed):
        self.observed=np.asarray(observed,float)
        if (self.observed.shape!=(36,4) or not np.isfinite(self.observed).all() or np.any(self.observed<0)
            or np.any(self.observed.sum(axis=1)<=0) or np.any(self.observed!=np.floor(self.observed))):
            raise ValueError('Expected 36x4 finite nonnegative integer counts')
        self.weights=self.observed.ravel()/self.observed.sum()

    def matrix(self,x,aux=False):
        R=x[:64].reshape(8,8)+1j*x[64:].reshape(8,8)
        S=R@R.conj().T;E=effect(S);E=(E+E.conj().T)/2
        ev,U=np.linalg.eigh(E)
        if not np.isfinite(ev).all() or ev.min()<=1e-18:
            raise FloatingPointError('Singular input marginal in trial factor')
        sq=np.sqrt(ev);A=(U*(1/sq))@U.conj().T;A8=np.kron(A,np.eye(4))
        J=A8@S@A8;J=(J+J.conj().T)/2
        if aux:return J,R,S,U,sq,A8
        return J

    def value_gradient(self,x):
        J,R,S,U,sq,A8=self.matrix(x,aux=True)
        p=np.einsum('bij,ji->b',OPERATORS,J).real
        if np.any(p<=0) or not np.isfinite(p).all():
            raise FloatingPointError('Nonpositive probability in trial factor')
        G=-np.einsum('b,bij->ij',self.weights/p,OPERATORS)
        H=effect(S@A8@G+G@A8@S)
        # Frechet derivative of E^(-1/2), stable even for repeated eigenvalues.
        F=-1/(sq[:,None]*sq[None,:]*(sq[:,None]+sq[None,:]))
        C=U@(F*(U.conj().T@H@U))@U.conj().T
        GS=A8@G@A8+np.kron(C,np.eye(4));grad=2*GS@R
        return float(-self.weights@np.log(p)),np.r_[grad.real.ravel(),grad.imag.ravel()]

    @staticmethod
    def start(candidate=None,regularizer=1e-5):
        if candidate is None:R=np.eye(8,dtype=complex)/2
        else:
            candidate=np.asarray(candidate,complex)
            if candidate.shape!=(8,8) or not np.isfinite(candidate).all():
                return CertifiedLikelihood.start()
            eig,U=np.linalg.eigh((candidate+candidate.conj().T)/2)
            R=U*np.sqrt(np.maximum(eig,regularizer))
        return np.r_[R.real.ravel(),R.imag.ravel()]

    def solve(self,candidate=None):
        attempts=[]
        starts=[(candidate,1e-5),(None,1e-5),(candidate,1e-3)]
        for attempt,(base,reg) in enumerate(starts,1):
            began=time.monotonic()
            try:
                r=minimize(self.value_gradient,self.start(base,reg),jac=True,method='L-BFGS-B',
                    options={'maxiter':5000,'ftol':1e-15,'gtol':1e-10,'maxls':50,'maxcor':30})
                J=self.matrix(r.x);p=np.einsum('bij,ji->b',OPERATORS,J).real.reshape(36,4)
                audit=audit_choi(J);gap=convex_gap_bound(J,self.weights)
                accepted=(audit['accepted'] and audit['minimum_probability']>=FLOOR
                          and np.isfinite(gap) and -1e-9<=gap<=DUAL_GAP_TOL)
                item={'attempt':attempt,'method':'PSD_TP_factor_LBFGSB_with_convex_gap',
                    'optimizer_success':bool(r.success),'iterations':int(r.nit),
                    'normalized_negative_log_likelihood':float(r.fun),'convex_gap_upper_bound':gap,
                    'convex_gap_tolerance':DUAL_GAP_TOL,'accepted':bool(accepted),**audit}
                item['accepted']=bool(accepted)
            except (FloatingPointError,np.linalg.LinAlgError,ValueError) as exc:
                item={'attempt':attempt,'accepted':False,'exception_type':type(exc).__name__}
                accepted=False
            item['elapsed_seconds']=time.monotonic()-began;attempts.append(item)
            if accepted:
                # Only roundoff row normalization, as in the original returned probabilities.
                p=p/p.sum(axis=1,keepdims=True)
                N=self.observed.sum(axis=1,keepdims=True)
                T=float(np.sum((self.observed-N*p)**2/(N*p)))
                return J,p,T,{'solver_policy':VERSION,'attempts':attempts,'accepted_attempt':attempt}
        raise FitRecoveryError('Certified full-receiver recovery did not converge',attempts)


class FitRecoveryError(RuntimeError):
    def __init__(self,message,attempts):
        super().__init__(message);self.attempts=attempts


class RecoveringReceiver:
    """Legacy fit first, deterministic same-count recovery on numerical rejection."""
    def __init__(self,counts,legacy_class,audit_path=None,force_certificate=False):
        self.legacy_class=legacy_class;self.force_certificate=force_certificate
        self.primary=None if force_certificate else legacy_class(counts)
        self.audit_path=Path(audit_path) if audit_path else None
        self.context={};self.last=None;self.history=[]

    def _log(self,item):
        self.history.append(item)
        if self.audit_path:
            self.audit_path.parent.mkdir(parents=True,exist_ok=True)
            with self.audit_path.open('a',encoding='utf-8') as f:
                f.write(json.dumps(item,ensure_ascii=False,allow_nan=False)+'\n')

    def fit(self,counts):
        a=counts_array(counts);candidate=self.last
        record={'policy':VERSION,**self.context,'counts_sha256':count_digest(counts)}
        if self.primary is not None:
            try:
                with warnings.catch_warnings(record=True) as caught:
                    warnings.simplefilter('always')
                    J,p,T=self.primary.fit(counts)
                au=audit_choi(J)
                if not au['accepted'] or not np.isfinite(p).all() or not np.isfinite(T):
                    raise RuntimeError('Full-receiver fit failed physicality audit')
                record.update(method='legacy_SCS_accepted',audit=au,
                    solver_status=str(self.primary.problem.status),warning_count=len(caught))
                self.last=J.copy();self._log(record);return J,p,T
            except RuntimeError as exc:
                if not str(exc).startswith(('Full-receiver fit failed','Solver failure')):
                    raise
                value=getattr(getattr(self.primary,'J',None),'value',None)
                if value is not None:candidate=np.asarray(value,complex).copy()
                record['legacy_rejection']=str(exc)[:180]
                if candidate is not None:record['rejected_audit']=audit_choi(candidate)
        try:
            J,p,T,detail=CertifiedLikelihood(a).solve(candidate)
        except FitRecoveryError as exc:
            record.update(method='all_recovery_attempts_failed',attempts=exc.attempts)
            self._log(record);raise
        record.update(method='certified_same_count_recovery',detail=detail)
        self.last=J.copy();self._log(record)
        if self.primary is not None:
            # Discard the inaccurate cached warm start WITHOUT editing private SDK caches.
            self.primary=self.legacy_class(counts)
            self.primary.J.value=J
        return J,p,T

    @staticmethod
    def draw(p,counts,rng):
        out={q:{} for q in PROBE_ORDER}
        for i,(q,b) in enumerate((q,b) for q in PROBE_ORDER for b in BASES):
            n=sum(counts[q][b].values())
            out[q][b]={format(o,'02b'):int(v) for o,v in enumerate(rng.multinomial(n,p[i]))}
        return out


def _digest_json(obj):
    return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def calibrated_gof_repaired(counts,frame_matrix=None,resamples=500,seed=240917,
        block_solver='cvxpy',output=None,*,_force_certificate=False):
    """Full original test, new versioned checkpoints, no replicate rejection.

    Null J/p0/T0/R0 are frozen once and loaded on resume. A failed draw keeps
    the preceding RNG checkpoint, so restart repeats precisely that draw.
    Do not point this function at an old-method GOF directory.
    """
    import count_level_gof as original
    from quantum_core import encoding,CPTNIFitter,tomography
    from workflow_paths import validate_output,write_json
    if type(resamples) is not int or resamples<1:raise ValueError('Positive integer resamples required')
    if frame_matrix is None:frame_matrix=np.eye(4)
    frame_matrix=np.asarray(frame_matrix,complex)
    if frame_matrix.shape!=(4,4) or np.linalg.norm(frame_matrix.conj().T@frame_matrix-np.eye(4))>1e-9:
        raise ValueError('A unitary 4x4 frame is required')
    counts_array(counts)
    out=validate_output(output) if output is not None else None
    signature={'policy':VERSION,'counts_sha256':count_digest(counts),'resamples':resamples,
        'seed':int(seed),'block_solver':block_solver,'force_certificate_validation_only':_force_certificate,
        'frame_real':frame_matrix.real.tolist(),'frame_imag':frame_matrix.imag.tolist(),
        'repair_module_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    if out:
        out.mkdir(parents=True,exist_ok=True);sp=out/'repair_signature.json'
        if sp.exists() and json.loads(sp.read_text())!=signature:
            raise ValueError('Repair checkpoint inputs/policy changed; use a new repair directory')
        if (out/'bootstrap_checkpoint.json').exists() and not sp.exists():
            raise ValueError('Refusing to mix an original-policy checkpoint with repaired-policy replicates')
        write_json(sp,signature)
    legacy=original.FullReceiverModel
    model=RecoveringReceiver(counts,legacy,out/'solver_audit.jsonl' if out else None,_force_certificate)
    fitter=CPTNIFitter(block_solver);V=encoding()
    def block_stat(cc):
        B={q:V.conj().T@frame_matrix.conj().T@tomography(dd)@frame_matrix@V for q,dd in cc.items()}
        return fitter.fit(B)[1]['block_residual']
    model.context={'role':'observed','replicate':None}
    frozen=out/'frozen_null.json' if out else None
    if frozen and frozen.exists():
        d=json.loads(frozen.read_text())
        if d['signature_sha256']!=_digest_json(signature):raise ValueError('Frozen null signature mismatch')
        if hashlib.sha256((out/'full_receiver_cptp_choi.npy').read_bytes()).hexdigest()!=d['choi_file_sha256']:
            raise ValueError('Frozen null Choi checksum mismatch')
        J=np.load(out/'full_receiver_cptp_choi.npy',allow_pickle=False)
        if not audit_choi(J)['accepted']:raise ValueError('Frozen null fails physicality audit')
        p0=np.asarray(d['p0'],float);T0=float(d['pearson_observed']);R0=float(d['block_observed'])
        if p0.shape!=(36,4) or not np.isfinite(p0).all() or p0.min()<=0 or not np.allclose(p0.sum(1),1,atol=1e-12):
            raise ValueError('Invalid frozen null probabilities')
        model.last=J.copy()
    else:
        J,p0,T0=model.fit(counts);R0=block_stat(counts)
        if out:
            np.save(out/'full_receiver_cptp_choi.npy',J)
            write_json(frozen,{'signature_sha256':_digest_json(signature),
                'choi_file_sha256':hashlib.sha256((out/'full_receiver_cptp_choi.npy').read_bytes()).hexdigest(),'p0':p0.tolist(),
                'pearson_observed':T0,'block_observed':R0})
    Ts=[];Rs=[];rng=np.random.default_rng(seed)
    checkpoint=out/'bootstrap_checkpoint.json' if out else None
    if checkpoint and checkpoint.exists():
        d=json.loads(checkpoint.read_text())
        if d['signature_sha256']!=_digest_json(signature):raise ValueError('Bootstrap signature mismatch')
        Ts=list(d['pearson']);Rs=list(d['block_residual'])
        if len(Ts)!=len(Rs) or len(Ts)>resamples or not np.isfinite(Ts+Rs).all():raise ValueError('Invalid checkpoint statistics')
        rng.bit_generator.state=d['rng_state']
    for k in range(len(Ts),resamples):
        # Checkpoint is only committed after BOTH statistics pass their audits.
        before=json.loads(json.dumps(rng.bit_generator.state))
        cc=model.draw(p0,counts,rng);model.context={'role':'null_refit','replicate':k+1}
        try:
            _,_,T=model.fit(cc);R=block_stat(cc)
        except Exception as exc:
            if out:
                write_json(out/'failed_refit.json',{'replicate_1_based':k+1,'exception_type':type(exc).__name__,
                    'message':str(exc)[:350],'counts_36x4':counts_array(cc).astype(int).tolist(),
                    'rng_state_before_draw':before,'successful_replicates':len(Ts),
                    'no_failed_replicate_dropped':True})
            raise
        Ts.append(float(T));Rs.append(float(R))
        if out:
            write_json(checkpoint,{'signature_sha256':_digest_json(signature),'seed':int(seed),
                'resamples':resamples,'pearson':Ts,'block_residual':Rs,'rng_state':rng.bit_generator.state})
    if len(Ts)!=resamples or len(Rs)!=resamples:raise RuntimeError('Incomplete repaired GOF')
    if out:
        import csv
        np.savez_compressed(out/'parametric_null_statistics.npz',pearson_X2=Ts,block_residual=Rs)
        with (out/'count_residuals.csv').open('w',newline='',encoding='utf-8') as f:
            wr=csv.DictWriter(f,fieldnames=['probe','basis','outcome','observed','expected','pearson_contribution']);wr.writeheader()
            for i,(q,b) in enumerate((q,b) for q in PROBE_ORDER for b in BASES):
                N=sum(counts[q][b].values())
                for o in range(4):
                    observed=counts[q][b].get(format(o,'02b'),0);ex=N*p0[i,o]
                    wr.writerow(dict(probe=q,basis=b,outcome=format(o,'02b'),observed=observed,
                        expected=float(ex),pearson_contribution=float((observed-ex)**2/ex)))
    pT=float((1+np.sum(np.asarray(Ts)>=T0))/(resamples+1));pR=float((1+np.sum(np.asarray(Rs)>=R0))/(resamples+1))
    result={'pearson_X2':float(T0),'pearson_parametric_p':pT,'block_objective':float(R0),'block_parametric_p':pR,
        'pearson_null_mean':float(np.mean(Ts)),'pearson_null_q95':float(np.quantile(Ts,.95)),
        'block_null_mean':float(np.mean(Rs)),'block_null_q95':float(np.quantile(Rs,.95)),
        'resamples':resamples,'null_model':'CPTP logical-qubit to full receiver; ideal SPAM axes/probes',
        'monte_carlo_standard_error_pearson':float(np.sqrt(pT*(1-pT)/(resamples+1))),
        'minimum_expected_count':float(min(sum(counts[q][b].values())*p0[i].min() for i,(q,b) in enumerate((q,b) for q in PROBE_ORDER for b in BASES))),
        'boundary_note':'Refit parametric bootstrap handles active constraints locally; not universal coverage proof',
        'solver_recovery_policy':VERSION,'all_requested_replicates_completed':True,
        'no_failed_replicates_dropped':True,'frozen_null_on_resume':True}
    if out:write_json(out/'repair_gof_result.json',result)
    return result


@contextmanager
def activate_recovery():
    """Scoped in-memory substitution; every original source file stays unchanged."""
    import count_level_gof as m
    old=m.calibrated_gof
    m.calibrated_gof=calibrated_gof_repaired
    try:yield
    finally:m.calibrated_gof=old

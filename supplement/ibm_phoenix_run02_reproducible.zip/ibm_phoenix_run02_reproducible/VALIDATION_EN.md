# Validation record (English)

## Executed and verified

- `ibm_phoenix_calculations.ipynb`: **all 7 Python code cells executed successfully** in local `reuse` mode, without IBM authentication or new job submission. Hardware count integrity verified against **1,746 individual raw JSON records**.
- `analyze-phase-concurrence-cptni-gof.ipynb`: **all 5 Python code cells executed successfully**, including the strict stage-8 stored-analysis audit, stage-9 English HTML report, and stage-10 ZIP exports. Stored complete numerical results were reused rather than refitted.
- Original IBM Phoenix run: **1,746 circuits**, **7,151,616 shots**, **six stored IBM Runtime job IDs**. All recorded 4,096-shot histograms conserve shots.
- Receiver counts SHA-256: `99ce131823c6bc7b1cf50599adc079fbcf708cc7f46f44b07b7c88b6c646b188` (matches saved collection status and all repaired analysis metadata).
- Hardware protocol distribution: direct_preparation: 45, discarded_diagnostic: 192, network: 1,440, readout_calibration: 24, swap_transfer: 45.
- Network analysis: **48 state rows (16 derived frame-tracked), 32 CP-TNI processes, 32 count-level GOF fits**. Each direct-preparation and SWAP-transfer baseline has **1 state, 1 process, 1 GOF fit**. 500 saved bootstrap replicates for uncertainty and 500 parametric GOF replicates per process.
- Preservation: original `receiver_counts.json`, original `latest_analysis.json`, original scientific code and SHA-256, repaired bootstrap checkpoints and numerical GOF solver audit preserved. The local notebooks add reports and exports without changing QPU measurements.
- `Results/Review_Outputs/review_summary_phase_concurrence_cptni_gof.csv` contains **50 displayed state rows**, with the available process and GOF metrics joined by sector and recovery. Frame-tracked rows intentionally have empty process/GOF fields, rather than implying extra measurements.
- Stage-10 local exports were generated and checked for their full raw count records and both English notebooks. The submission and GitHub exports contain the same science/reproducibility evidence.

## Not done (important distinction)

**No new IBM Quantum job was submitted** and no new physical measurement was made in this environment. IBM cloud-side job status was not independently queried. No complete CVXPY numerical reconstruction was performed, because the user-supplied archive already contained a fully finished repair with validated saved bootstrap data. Stage 8 includes the original recovery mechanism if the repair is incomplete and quantum solver dependencies are installed.

## Data interpretation

A checked count archive is not proof of a physics hypothesis, a complete device-error model, accurate frequentist coverage, or suitability for journal acceptance. Saved intervals cover finite multinomial counting uncertainty and not all device drift, SPAM, or calibration errors. Always review the solver audit, phase warnings and study's scientific assumptions.

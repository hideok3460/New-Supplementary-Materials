"""Count-level goodness-of-fit calibration with a full receiver model.

Requires CVXPY/SCS.  The released ``ibm_phoenix`` analysis executes this path
with a deterministic seed and archives the resulting diagnostics. Refit
failures raise exceptions instead of being dropped.
"""
from __future__ import annotations
import numpy as np
from quantum_core import *

class FullReceiverModel:
    """CPTP qubit -> two-qubit multinomial model, including leakage coherences.
    Ideal input probes and local measurement axes are model assumptions.
    """
    def __init__(self,counts):
        import cvxpy as cp
        self.cp=cp;self.keys=[(p,b) for p in ('0','1','+','+i') for b in SETTINGS]
        self.J=cp.Variable((8,8),hermitian=True);self.n=cp.Parameter((36,4),nonneg=True)
        eff=cp.bmat([[cp.trace(self.J[4*i:4*i+4,4*j:4*j+4]) for j in range(2)] for i in range(2)])
        rows=[]
        for probe,basis in self.keys:
            state=np.outer(PROBES[probe],PROBES[probe].conj())
            output=sum(state[i,j]*self.J[4*i:4*i+4,4*j:4*j+4] for i in range(2) for j in range(2))
            ps=[]
            for bit in range(4):
                povm=np.kron((I+(-1)**(bit>>1)*PAULI[basis[0]])/2,(I+(-1)**(bit&1)*PAULI[basis[1]])/2)
                ps.append(cp.real(cp.trace(povm@output)))
            rows.append(cp.hstack(ps))
        self.p=cp.vstack(rows)
        # Tiny numerical floor avoids log(0); it is not post-selection.
        self.problem=cp.Problem(cp.Minimize(-cp.sum(cp.multiply(self.n,cp.log(self.p)))),
                                [self.J>>0,eff==I,self.p>=1e-10])
        self.original=counts
    def fit(self,counts):
        observed=np.array([[counts[p][b].get(format(o,'02b'),0) for o in range(4)] for p,b in self.keys],float)
        if np.any(observed.sum(axis=1)<=0):raise ValueError('Each setting must contain shots')
        self.n.value=observed/observed.sum()  # constant rescaling improves numerical conditioning
        self.problem.solve(solver='SCS',eps=1e-7,max_iters=100000,warm_start=True)
        if self.problem.status not in ('optimal','optimal_inaccurate') or self.J.value is None:
            raise RuntimeError('Full-receiver fit failed: '+str(self.problem.status))
        J=(self.J.value+self.J.value.conj().T)/2
        if np.linalg.eigvalsh(J).min() < -2e-6 or np.linalg.norm(effect_transpose(J)-I)>2e-5:
            raise RuntimeError('Full-receiver fit failed physicality audit')
        p=np.clip(np.asarray(self.p.value,float),1e-12,None);p/=p.sum(axis=1,keepdims=True)
        N=observed.sum(axis=1,keepdims=True)
        statistic=float(np.sum((observed-N*p)**2/(N*p)))
        return J,p,statistic
    def draw(self,p,counts,rng):
        out={k:{} for k in ('0','1','+','+i')}
        for i,(probe,basis) in enumerate(self.keys):
            n=sum(counts[probe][basis].values())
            out[probe][basis]={format(o,'02b'):int(v) for o,v in enumerate(rng.multinomial(n,p[i]))}
        return out

def calibrated_gof(counts,frame_matrix=None,resamples=500,seed=240917,block_solver='cvxpy',output=None):
    """Parametric refit bootstrap for Pearson X2 AND original block objective.
    A plug-in calibrated diagnostic, not proof of correct SPAM or uniform coverage.
    """
    if frame_matrix is None:frame_matrix=np.eye(4)
    model=FullReceiverModel(counts);J,p0,T0=model.fit(counts)
    V=encoding();fitter=CPTNIFitter(block_solver)
    def block_stat(cc):
        B={probe:V.conj().T@frame_matrix.conj().T@tomography(dd)@frame_matrix@V for probe,dd in cc.items()}
        return fitter.fit(B)[1]['block_residual']
    R0=block_stat(counts);Ts=[];Rs=[];rng=np.random.default_rng(seed)
    from pathlib import Path
    import json,csv
    from workflow_paths import validate_output,write_json
    out=validate_output(output) if output is not None else None
    if out is not None:
        out.mkdir(parents=True,exist_ok=True)
        checkpoint=out/'bootstrap_checkpoint.json'
        if checkpoint.is_file():
            saved=json.loads(checkpoint.read_text())
            if saved['seed']!=seed or saved['resamples']!=resamples:
                raise ValueError('GOF checkpoint settings mismatch')
            Ts=list(saved['pearson']);Rs=list(saved['block_residual'])
            rng.bit_generator.state=saved['rng_state']
    for _ in range(len(Ts),resamples):
        cc=model.draw(p0,counts,rng)
        _,_,T=model.fit(cc);Ts.append(T);Rs.append(block_stat(cc))
        if out is not None and (len(Ts)%25==0 or len(Ts)==resamples):
            write_json(checkpoint,{'seed':seed,'resamples':resamples,'pearson':Ts,'block_residual':Rs,
                                  'rng_state':rng.bit_generator.state})
    if out is not None:
        np.save(out/'full_receiver_cptp_choi.npy',J)
        np.savez_compressed(out/'parametric_null_statistics.npz',pearson_X2=Ts,block_residual=Rs)
        with (out/'count_residuals.csv').open('w',newline='',encoding='utf-8') as f:
            fields=['probe','basis','outcome','observed','expected','pearson_contribution']
            writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
            for i,(probe,basis) in enumerate(model.keys):
                total=sum(counts[probe][basis].values())
                for k in range(4):
                    obs=counts[probe][basis].get(format(k,'02b'),0);ex=total*p0[i,k]
                    writer.writerow(dict(probe=probe,basis=basis,outcome=format(k,'02b'),observed=obs,
                                         expected=float(ex),pearson_contribution=float((obs-ex)**2/ex)))
    pT=(1+np.sum(np.asarray(Ts)>=T0))/(resamples+1)
    pR=(1+np.sum(np.asarray(Rs)>=R0))/(resamples+1)
    return {'pearson_X2':T0,'pearson_parametric_p':float(pT),'block_objective':R0,'block_parametric_p':float(pR),
            'pearson_null_mean':float(np.mean(Ts)), 'pearson_null_q95':float(np.quantile(Ts,.95)),
            'block_null_mean':float(np.mean(Rs)), 'block_null_q95':float(np.quantile(Rs,.95)),
            'resamples':resamples,'null_model':'CPTP logical-qubit to full receiver; ideal SPAM axes/probes',
            'monte_carlo_standard_error_pearson':float(np.sqrt(pT*(1-pT)/(resamples+1))),
            'minimum_expected_count':float(min(sum(counts[probe][basis].values())*p0[i].min() for i,(probe,basis) in enumerate(model.keys))),
            'boundary_note':'Refit parametric bootstrap handles active constraints locally; not universal coverage proof'}

def coverage_study(choi_models,shots=4096,trials=200,inner_bootstraps=500,seed=240917,solver='cvxpy'):
    """Optional costly nested simulation; synthetic output only.
    choi_models: named physical 8x8 CPTP Choi matrices (vary boundary proximity).
    This must be RUN before making any numerical coverage claim.
    """
    rng=np.random.default_rng(seed);V=encoding();rows=[]
    for name,J in choi_models.items():
        if J.shape!=(8,8) or np.linalg.eigvalsh(J).min()<-1e-8 or np.linalg.norm(effect_transpose(J)-I)>1e-7:
            raise ValueError('Coverage models must be physical qubit-to-full-receiver CPTP maps')
        embed=np.kron(I,V);trueJ=embed.conj().T@J@embed;phi=np.array([1,0,0,1])/np.sqrt(2)
        truth=np.array([np.trace(trueJ).real/2,(phi@trueJ@phi).real/2]);covered=np.zeros(2,int)
        output={q:apply_choi(J,np.outer(PROBES[q],PROBES[q].conj())) for q in ('0','1','+','+i')}
        def estimate(cc):
            B={q:V.conj().T@tomography(d)@V for q,d in cc.items()};_,m=fit_cptni(B,solver=solver)
            return [m['survival'],m['identity_overlap']]
        for _ in range(trials):
            cc={q:sample_counts(rho,shots,rng) for q,rho in output.items()}
            rr=np.array([estimate({q:resample_counts(d,rng) for q,d in cc.items()}) for _ in range(inner_bootstraps)])
            lo,hi=np.quantile(rr,[.025,.975],axis=0);covered+=(lo<=truth)&(truth<=hi)
        rows.append({'model':name,'data_kind':'SYNTHETIC_COVERAGE_STUDY','trials':trials,
                     'coverage_survival':covered[0]/trials,'coverage_overlap':covered[1]/trials,
                     'coverage_mc_se_max':.5/np.sqrt(trials)})
    return rows

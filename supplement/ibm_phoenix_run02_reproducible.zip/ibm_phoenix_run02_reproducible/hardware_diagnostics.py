"""Read-only diagnostics from real counts and compiled metadata; no mitigation.

Calibration circuits estimate preparation-plus-readout response, not isolated
measurement errors. Limited discarded-register checks cannot prove factorization.
"""
from __future__ import annotations
from pathlib import Path
from collections import defaultdict
import csv,json
import numpy as np
from reanalyse_counts import write_csv
from workflow_paths import validate_output,write_json


def analyse(acquisition,output,bootstraps=500,seed=240917):
    acq=Path(acquisition);out=validate_output(output);out.mkdir(parents=True,exist_ok=True)
    source=json.loads((acq/'receiver_counts.json').read_text())
    if source.get('data_kind')!='HARDWARE':raise ValueError('Hardware diagnostics require genuine HARDWARE counts')
    metadata=json.loads((acq/'compiled_metadata.json').read_text())
    by_index={r['acquisition_index']:r for r in metadata}
    layout=[];cal={};rng=np.random.default_rng(seed)
    for r in source['records']:
        md=by_index[r['acquisition_index']];pair=md['receiver_measurement_physical']
        layout.append({'acquisition_index':r['acquisition_index'],'circuit_name':r['circuit_name'],
            'hardware_job_id':r['hardware_job_id'],'protocol':r['protocol'],
            'M1':r['resource'][0],'M2':r['resource'][1],'x':r['sector'][0],'m':r['sector'][1],
            'recovery':r['recovery'],'probe':r['probe'],'basis':r['basis'],'receiver_order':'q4 q3',
            'physical_q4':pair['q4'],'physical_q3':pair['q3'],
            'final_logical_to_physical':json.dumps(md['final_logical_to_physical']),
            'depth':md['depth'],'two_qubit_gates':md['native_two_qubit_gate_count'],
            'shots':sum(r['counts'].values())})
        if r['protocol']=='readout_calibration':
            k=(pair['q3'],pair['q4'],r.get('calibration_epoch','not_recorded'))
            counts=cal.setdefault(k,{})
            if r['probe'] in counts:raise ValueError('Repeated readout calibration label; separate runs rather than silently pool')
            counts[r['probe']]=r['counts']
    write_csv(out/'final_layouts_and_counts_mapping.csv',layout)
    calibration=[];calibration_summary=[]
    for (q3,q4,epoch),dd in sorted(cal.items()):
        if set(dd)!={'00','01','10','11'}:raise ValueError('Incomplete receiver calibration')
        A=np.column_stack([np.array([dd[b].get(format(i,'02b'),0) for i in range(4)])/sum(dd[b].values()) for b in ('00','01','10','11')])
        for j in range(4):
            counts=dd[format(j,'02b')];N=sum(counts.values())
            reps=rng.multinomial(N,A[:,j],size=bootstraps)/N;lo,hi=np.quantile(reps,[.025,.975],axis=0)
            for i in range(4):
                calibration.append({'data_kind':'HARDWARE','physical_q3':q3,'physical_q4':q4,'design_epoch':epoch,
                    'prepared':format(j,'02b'),'observed':format(i,'02b'),'probability':float(A[i,j]),
                    'probability_lo':float(lo[i]),'probability_hi':float(hi[i]),'shots':N,
                    'note':'Preparation-plus-readout response; no SPAM separation or automatic mitigation.'})
        calibration_summary.append({'physical_q3':q3,'physical_q4':q4,'design_epoch':epoch,
            'mean_assignment_success':float(np.trace(A)/4),'response_condition_number':float(np.linalg.cond(A)),
            'note':'before/after are manifest bookends, not guaranteed chronological QPU execution order.'})
    write_csv(out/'readout_response.csv',calibration);write_csv(out/'readout_response_summary.csv',calibration_summary)
    # Descriptive compilation overhead on matched logical settings.
    network={}
    for r in metadata:
        if r['protocol']!='network':continue
        key=(tuple(r['resource']),tuple(r['sector']),r['probe'],r['basis'])
        network.setdefault(key,{})[r['recovery']]=r
    overhead=[];gate_rows=[]
    for key,modes in sorted(network.items()):
        if set(modes)!={'raw','physical'}:continue
        a,b=modes['raw'],modes['physical']
        overhead.append({'M1':key[0][0],'M2':key[0][1],'x':key[1][0],'m':key[1][1],'probe':key[2],'basis':key[3],
            'raw_depth':a['depth'],'physical_depth':b['depth'],'depth_difference':b['depth']-a['depth'],
            'raw_two_qubit_gates':a['native_two_qubit_gate_count'],'physical_two_qubit_gates':b['native_two_qubit_gate_count'],
            'two_qubit_gate_difference':b['native_two_qubit_gate_count']-a['native_two_qubit_gate_count'],
            'same_final_receiver_pair':a['receiver_measurement_physical']==b['receiver_measurement_physical'],
            'note':'Compiler/layout-dependent contrast; not an isolated causal recovery-gate error.'})
    for r in metadata:
        gates=r['gate_calibration_records'];errors=[g['reported_error'] for g in gates if isinstance(g.get('reported_error'),(int,float)) and 0<=g['reported_error']<=1]
        durations=[g['duration_s'] for g in gates if isinstance(g.get('duration_s'),(int,float))]
        gate_rows.append({'acquisition_index':r['acquisition_index'],'protocol':r['protocol'],'circuit_name':r['circuit_name'],
            'native_gate_count':len(gates),'gates_with_error_estimate':len(errors),
            'sum_native_gate_durations_s':float(sum(durations)),
            'independent_no_error_proxy':float(np.prod([1-e for e in errors])) if errors else None,
            'caveat':'Sum of gate durations is not scheduled runtime. Independent error proxy is not predicted fidelity; calibration does not identify crosstalk.'})
    write_csv(out/'compiled_recovery_overhead.csv',overhead);write_csv(out/'calibration_gate_diagnostics.csv',gate_rows)
    joint=json.loads((acq/'joint_discarded_counts.json').read_text()) if (acq/'joint_discarded_counts.json').exists() else []
    correlations=[];discarded=[]
    for r in joint:
        dd=r['joint_c_d_counts'];labels=list(dd);N=sum(dd.values());weights=np.array([dd[b] for b in labels])/N
        c=[];d=[]
        for label in labels:
            bc,bd=label.split()
            if len(bc)!=2 or len(bd)!=3:raise ValueError('Expected paired c4c3 and d2d1d0 bit strings')
            c.append([(-1)**int(v) for v in bc]);d.append([(-1)**int(v) for v in bd])
        c=np.asarray(c);d=np.asarray(d)
        draws=rng.multinomial(N,weights,size=bootstraps)/N
        dc=weights@d;cc=weights@c
        res=r['resource'];sec=r['sector'];expect=[(-1)**sec[1],(-1)**res[0],(-1)**(sec[0]^sec[1])]
        base={'data_kind':'HARDWARE','acquisition_index':r['acquisition_index'],'M1':res[0],'M2':res[1],
              'x':sec[0],'m':sec[1],'probe':r['probe'],'receiver_basis':r['basis'],'shots':N}
        for j,axis in enumerate(('X2','X1','Z0')):
            b=draws@d[:,j];lo,hi=np.quantile(b,[.025,.975])
            discarded.append({**base,'discarded_observable':axis,'expectation':float(dc[j]),
                'expectation_lo':float(lo),'expectation_hi':float(hi),'ideal':expect[j]})
        for i,receiver in enumerate(('q4','q3')):
            for j,axis in enumerate(('X2','X1','Z0')):
                cd=c[:,i]*d[:,j];point=weights@cd-cc[i]*dc[j]
                bs=draws@cd-(draws@c[:,i])*(draws@d[:,j]);lo,hi=np.quantile(bs,[.025,.975])
                correlations.append({**base,'receiver_observable':r['basis'][i]+receiver,'discarded_observable':axis,
                    'connected_correlation':float(point),'correlation_lo':float(lo),'correlation_hi':float(hi),'ideal':0,
                    'note':'Selected witnesses only; zero values do not prove full receiver-discarded factorization.'})
    write_csv(out/'discarded_expectations.csv',discarded);write_csv(out/'receiver_discarded_correlations.csv',correlations)
    status={'data_kind':'HARDWARE','mapped_circuits':len(layout),'calibration_probability_rows':len(calibration),
            'overhead_pairs':len(overhead),'connected_correlation_rows':len(correlations),
            'no_measurement_mitigation_applied':True,'no_crosstalk_isolation_claim':True,
            'bootstrap_replicates':bootstraps}
    write_json(out/'diagnostics_status.json',status);return status


def benchmark_comparisons(analysis_root):
    """Shared-baseline comparisons are descriptive, not independent replications."""
    root=validate_output(analysis_root)
    def load(protocol):
        p=root/protocol/'measured_state_phases_concurrence.csv'
        return list(csv.DictReader(p.open(encoding='utf-8'))) if p.exists() else []
    network=[r for r in load('network') if r['recovery']=='physical'];rows=[]
    for protocol in ('direct_preparation','swap_transfer'):
        baseline=load(protocol)
        if not baseline:continue
        if len(baseline)!=1:raise ValueError('Compare one baseline per acquisition; do not pool unrelated runs')
        base=baseline[0];bb=np.load(root/protocol/base['bootstrap_file'],allow_pickle=False)
        for net in network:
            bn=np.load(root/'network'/net['bootstrap_file'],allow_pickle=False)
            row={k:net[k] for k in ('acquisition_id','M1','M2','x','m','data_kind')};row['baseline']=protocol
            for metric in ('fidelity','code_population','concurrence'):
                diff=bn[metric]-bb[metric];lo,hi=np.quantile(diff,[.025,.975])
                row['network_minus_baseline_'+metric]=float(net[metric])-float(base[metric])
                row[metric+'_difference_lo']=float(lo);row[metric+'_difference_hi']=float(hi)
            row['caveat']='Baseline is shared, not repeated independently per resource. Different workloads/layouts; no universal performance-superiority inference.'
            rows.append(row)
    write_csv(root/'matched_baseline_comparisons.csv',rows);return len(rows)

"""Repository-relative paths, atomic provenance and publication-safe utilities.
No account is read and no network call is made on import.
"""
from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
from contextlib import redirect_stdout, redirect_stderr, contextmanager
from importlib.metadata import version, PackageNotFoundError
import hashlib, json, os, platform, re, sys, tempfile

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / 'Results'
INPUTS = ROOT / 'Inputs'
VERSION = 'fixed5.0'

def utc_now():
    return datetime.now(timezone.utc).isoformat()

def output_path(*parts, directory=True):
    target = RESULTS.joinpath(*parts).resolve()
    if not target.is_relative_to(RESULTS.resolve()):
        raise ValueError('Generated outputs must remain inside the project Results directory')
    (target if directory else target.parent).mkdir(parents=True, exist_ok=True)
    return target

def validate_output(path):
    path = Path(path).resolve()
    if not path.is_relative_to(RESULTS.resolve()):
        raise ValueError(f'Output must be inside {RESULTS}, not {path}')
    return path

def sha256(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def jsonable(v):
    import numpy as np
    if isinstance(v, dict): return {str(k):jsonable(x) for k,x in v.items()}
    if isinstance(v,(tuple,list,set)): return [jsonable(x) for x in v]
    if isinstance(v, np.ndarray): return jsonable(v.tolist())
    if isinstance(v, (np.integer,)): return int(v)
    if isinstance(v, (float,np.floating)): return float(v) if np.isfinite(v) else None
    if isinstance(v, (np.bool_,bool)): return bool(v)
    if isinstance(v, (str,int)) or v is None: return v
    if isinstance(v, (Path,datetime)): return str(v)
    return str(v)

def write_json(path, value):
    path=Path(path);path.parent.mkdir(parents=True, exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.',suffix='.tmp',dir=path.parent)
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:
            json.dump(jsonable(value),f,ensure_ascii=False,indent=2,allow_nan=False)
        os.replace(tmp,path)
    finally:
        if Path(tmp).exists(): Path(tmp).unlink()

def environment_record():
    packages={}
    for p in ('numpy','scipy','qiskit','qiskit-ibm-runtime','cvxpy','scs','nbformat','nbclient','ipykernel','pytest'):
        try: packages[p]=version(p)
        except PackageNotFoundError: packages[p]=None
    return {'created_utc':utc_now(),'workflow_version':VERSION,'python':platform.python_version(),
            'platform':platform.platform(),'packages':packages,
            'note':'Package versions only. No credentials or account identifiers are exported.'}

def code_fingerprint():
    names=('quantum_core.py','reanalyse_counts.py','count_level_gof.py','ibm_followup.py','workflow.py','workflow_paths.py','hardware_diagnostics.py')
    return {n:sha256(ROOT/n) for n in names if (ROOT/n).is_file()}

def load_config():
    cfg=json.loads((ROOT/'config.json').read_text(encoding='utf-8'))
    if cfg['experiment']['stage']!='full':
        raise ValueError('This revision is a FULL tomography design. stage must remain full.')
    run_id=cfg['experiment']['run_id']
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,79}',run_id) or '..' in run_id:
        raise ValueError('Use a simple, unique run_id without slashes or ..')
    if type(cfg['experiment']['seed']) is not int:raise ValueError('experiment.seed must be an integer')
    a=cfg['analysis']
    if min(a['bootstraps'],a['gof_bootstraps'])<20:
        raise ValueError('At least 20 bootstrap replicates; use >=500 for manuscript reporting.')
    if cfg['execution']['mode'] not in ('job','batch'):
        raise ValueError('execution.mode must be job or batch')
    return cfg

@contextmanager
def logged_step(folder, name):
    """Append stdout/stderr to Results; exceptions remain visible to the caller."""
    folder=validate_output(folder);folder.mkdir(parents=True,exist_ok=True)
    with (folder/(name+'.log')).open('a',encoding='utf-8') as log:
        with redirect_stdout(log),redirect_stderr(log):
            print('\nSTART',utc_now(),name)
            try: yield
            finally: print('END',utc_now(),name)

def checksums(folder):
    folder=Path(folder)
    files=[p for p in sorted(folder.rglob('*')) if p.is_file() and
           p.name!='SHA256SUMS.txt' and not any(s in p.parts for s in ('__pycache__','.ipynb_checkpoints'))]
    (folder/'SHA256SUMS.txt').write_text(''.join(sha256(p)+'  '+p.relative_to(folder).as_posix()+'\n' for p in files),encoding='utf-8')
    return len(files)

"""High-level notebook actions. Every output is rooted in ./Results.
Cloud access is lazy and explicit; prepare/offline/analyse/export are offline.
"""
from __future__ import annotations
from dataclasses import asdict
from pathlib import Path
import hashlib,json,os
from workflow_paths import (ROOT,RESULTS,INPUTS,output_path,write_json,sha256,
                            load_config,environment_record,code_fingerprint,jsonable,checksums,logged_step)


def experiment_plan(cfg=None):
    from ibm_followup import Plan
    cfg=cfg or load_config();e=cfg['experiment']
    return Plan(stage='full',shots=e['shots'],seed=e['seed'],
                direct_preparation_baseline=e['direct_preparation_baseline'],
                swap_transfer_baseline=e['swap_transfer_baseline'],
                readout_calibration=e['readout_calibration'],
                discarded_diagnostics=e['discarded_diagnostics'],omit_z_ablation=False)


def acquisition_folder(cfg=None):
    cfg=cfg or load_config()
    return output_path('02_hardware',cfg['experiment']['run_id'])


def prepare_followup(cfg=None):
    from ibm_followup import budget,manifest,validate_full_design
    cfg=cfg or load_config();plan=experiment_plan(cfg);out=acquisition_folder(cfg)
    rows=manifest(plan);validation=validate_full_design(rows)
    info={'status':'PLANNED_NOT_SUBMITTED','data_kind':'EXPERIMENT_DESIGN_NOT_MEASUREMENT',
          'backend_requested':cfg['experiment']['backend'],'plan':asdict(plan),
          'budget':budget(plan),'design_validation':validation,
          'note':'No network connection or QPU job. Readout calibration adds backend-dependent circuits after compile.'}
    write_json(out/'planned_manifest.json',rows);write_json(out/'planned_experiment.json',info)
    write_json(out/'environment_prepare.json',environment_record())
    return info


def run_offline():
    out=output_path('00_offline')
    with logged_step(out,'offline_checks'):
        import run_offline_analysis
        run_offline_analysis.main(out)
    from smoke_test_workflows import run
    with logged_step(out,'synthetic_full_workflow'):
        tests=run(out/'synthetic_full_workflow')
    write_json(out/'environment.json',environment_record())
    plan=prepare_followup()
    summary={'status':'OFFLINE_CHECKS_COMPLETED','data_kind':'OFFLINE_AND_SYNTHETIC_ONLY',
             'new_hardware_jobs_submitted':0,'tests':tests,
             'full_design_budget':plan['budget'],
             'limitations':['No IBM account or live backend accessed','SDK/CVXPY integration requires installed quantum dependencies']}
    write_json(out/'notebook_00_status.json',summary);checksums(out)
    return summary


def _analysis_folder(base,source,a):
    sig={'source':sha256(source),'analysis':a,'code':code_fingerprint()}
    ident=hashlib.sha256(json.dumps(sig,sort_keys=True).encode()).hexdigest()[:12]
    out=Path(base)/'analyses'/('analysis_'+ident);out.mkdir(parents=True,exist_ok=True)
    write_json(Path(base)/'latest_analysis.json',{'analysis_directory':out.relative_to(ROOT).as_posix(),
               'analysis_fingerprint':ident,'source_sha256':sig['source']})
    return out


def reanalyse_original(cfg=None):
    cfg=cfg or load_config();out=output_path('01_original_reanalysis');spec=cfg['original_data']
    # Inputs may be outside the repository. Converted outputs and logs never are.
    archive=Path(spec['archive']).expanduser()
    if not archive.is_absolute():archive=ROOT/archive
    normalized=spec.get('normalized_counts','').strip()
    if normalized:
        source=Path(normalized).expanduser()
        if not source.is_absolute():source=ROOT/source
        if not source.is_file():raise FileNotFoundError('The configured normalized_counts file does not exist')
        data=json.loads(source.read_text())
        if data.get('data_kind')!='HARDWARE':raise ValueError('Original reanalysis requires real HARDWARE counts')
        backends={r.get('backend',data.get('backend')) for r in data['records']}
        if backends!={'ibm_phoenix'}:raise ValueError('Notebook 01 is for the original ibm_phoenix data; use 02 for new runs')
        target=out/'receiver_counts.json';write_json(target,data)
        write_json(out/'normalized_import_audit.json',{'status':'SCHEMA_INPUT_COPIED',
            'input_sha256':sha256(source),'output_sha256':sha256(target),
            'caveat':'Direct normalized input is not a cryptographic audit of the missing original archive.'})
    elif archive.is_file():
        from import_ibm_phoenix_archive import convert
        target=out/'receiver_counts.json'
        with logged_step(out,'import_original'):
            audit=convert(archive,target,out/'phoenix_counts_mapping.csv',out/'phoenix_import_audit.json')
        write_json(out/'source_archive_audit.json',{'archive_filename':archive.name,'archive_sha256':sha256(archive),
                                                 'import_audit':audit})
    else:
        status={'status':'INPUT_REQUIRED','real_analysis_executed':False,
                'expected_archive':spec['archive'],
                'action':'Place the real original reproducibility ZIP in Inputs/, or configure an existing real receiver_counts.json. No synthetic substitute is used.'}
        write_json(out/'notebook_01_status.json',status);return status
    from reanalyse_counts import analyse
    a=cfg['analysis'];destination=_analysis_folder(out,target,a)
    with logged_step(destination,'reanalysis'):
        status=analyse(target,destination/'network',bootstraps=a['bootstraps'],seed=a['seed'],solver=a['solver'],
                       count_gof=a['count_gof'],gof_bootstraps=a['gof_bootstraps'],resume=a['resume'])
    write_json(out/'notebook_01_status.json',status);checksums(out);return status


def connect_runtime(prompt_for_credentials=False):
    """Use an existing saved account, environment variables, or hidden input.
    Never print/save API keys, service objects, saved_accounts(), or error text.
    """
    from qiskit_ibm_runtime import QiskitRuntimeService
    token=os.environ.get('IBM_QUANTUM_API_KEY','').strip()
    instance=os.environ.get('IBM_QUANTUM_INSTANCE','').strip()
    account=os.environ.get('IBM_QUANTUM_ACCOUNT_NAME','').strip()
    if prompt_for_credentials and not token:
        from getpass import getpass
        token=getpass('IBM Quantum API key (hidden; not stored in this repository): ').strip()
        if not instance:instance=input('IBM Quantum instance CRN (not written to result files): ').strip()
    kwargs={}
    if token:
        kwargs['token']=token;kwargs['channel']='ibm_quantum_platform'
    elif account:kwargs['name']=account
    if instance:kwargs['instance']=instance
    try:return QiskitRuntimeService(**kwargs)
    except Exception as exc:
        raise RuntimeError('IBM authentication/connection failed ('+type(exc).__name__+'). Check your saved account or environment credentials. No credentials were logged.') from None


def compile_followup(service,cfg=None):
    from ibm_followup import compile_plan,load_compiled_plan,recommend_physical_layout,require_allowed_backend
    cfg=cfg or load_config();out=acquisition_folder(cfg);plan=experiment_plan(cfg);backend_name=cfg['experiment']['backend']
    require_allowed_backend(backend_name)
    if (out/'plan.json').is_file():
        saved=json.loads((out/'plan.json').read_text())
        if saved['plan']!=jsonable(asdict(plan)):raise ValueError('Configuration changed after compilation. Choose a NEW experiment.run_id.')
        backend,circuits,rows=load_compiled_plan(service,backend_name,out)
        return backend,circuits,rows
    layout=cfg['experiment']['physical_layout']
    if not layout:
        layout=recommend_physical_layout(service.backend(backend_name),plan)
        write_json(out/'selected_initial_layout.json',{'logical_q0_to_q4':layout,
            'method':'One backend layout search; same initial layout fixed for all resource/sector circuits.'})
    return compile_plan(service,backend_name,layout,plan,out)


def submit_followup(service,authorization_token,authorized_shots,cfg=None):
    from ibm_followup import load_compiled_plan,submit_compiled
    cfg=cfg or load_config();out=acquisition_folder(cfg);ex=cfg['execution']
    backend,circuits,rows=load_compiled_plan(service,cfg['experiment']['backend'],out)
    return submit_compiled(backend,circuits,rows,out,submit=True,
        max_total_shots=authorized_shots,authorization_token=authorization_token,
        max_circuits_per_job=ex['max_circuits_per_job'],max_execution_time=ex['max_execution_time_per_job_seconds'],
        batch_max_time=ex['batch_max_time'],execution_mode=ex['mode'])


def collect_followup(service,cfg=None,wait=False):
    from ibm_followup import collect_results
    return collect_results(service,acquisition_folder(cfg),wait=wait)


def analyse_followup(cfg=None):
    from ibm_followup import validate_full_design
    from reanalyse_counts import analyse
    from hardware_diagnostics import analyse as diagnostics,benchmark_comparisons
    cfg=cfg or load_config();acq=acquisition_folder(cfg);source=acq/'receiver_counts.json'
    if not source.exists():
        status={'status':'AWAITING_FULL_HARDWARE_COUNTS','analysis_executed':False,
                'note':'Compile/submit/collect the full design first. SCREEN artifacts are never used as full data.'}
        write_json(acq/'analysis_waiting_status.json',status);return status
    data=json.loads(source.read_text())
    if data.get('data_kind')!='HARDWARE':raise ValueError('New hardware analysis refuses synthetic data')
    validate_full_design(data['records'])
    a=cfg['analysis'];out=_analysis_folder(acq,source,a);statuses={}
    protocols={r.get('protocol','network') for r in data['records']}
    for protocol in ('network','direct_preparation','swap_transfer'):
        if protocol not in protocols:continue
        with logged_step(out,protocol):
            statuses[protocol]=analyse(source,out/protocol,bootstraps=a['bootstraps'],seed=a['seed'],solver=a['solver'],
                count_gof=a['count_gof'],gof_bootstraps=a['gof_bootstraps'],protocol=protocol,resume=a['resume'])
    with logged_step(out,'diagnostics'):
        statuses['diagnostics']=diagnostics(acq,out/'hardware_diagnostics',a['bootstraps'],a['seed'])
        statuses['baseline_comparison_rows']=benchmark_comparisons(out)
    n=statuses['network']
    if n['phase_rows']!=48 or n['process_rows']!=32 or n['warnings']:
        raise RuntimeError('Unexpected full-design analysis coverage; inspect logs before publication')
    if a['count_gof'] and n['gof_rows']!=32:raise RuntimeError('Incomplete count-level goodness-of-fit coverage')
    status={'status':'ANALYSIS_COMPLETED_AUTHOR_INTERPRETATION_REQUIRED','data_kind':'HARDWARE',
            'analysis_directory':out.relative_to(ROOT).as_posix(),'analyses':statuses,
            'scope':'Single acquisition; repeated sessions/devices require separate run_ids. No guaranteed acceptance or boundary coverage.'}
    write_json(acq/'notebook_02_status.json',status);checksums(acq);return status

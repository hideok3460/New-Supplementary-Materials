"""Build local submission/GitHub bundles. Never publishes to an online service.
Source notebooks are exported without outputs; run outputs remain in Results.
Secrets/account files, caches, old SCREEN artifacts and recursive ZIPs are excluded.
"""
from __future__ import annotations
from pathlib import Path
import csv,hashlib,json,re,zipfile
from workflow_paths import ROOT,RESULTS,output_path,write_json,sha256,utc_now
from reanalyse_counts import write_csv

EXCLUDED_PARTS={'.git','.qiskit','.venv','venv','__pycache__','.ipynb_checkpoints','.pytest_cache','_cache','Exports','legacy_fixed3_compilation','pytest_tmp','Setup','Environment','previous_fixed4_results'}
EXCLUDED_NAMES={'qiskit-ibm.json','credentials.json','.env','config.local.json','MANIFEST_SHA256.txt','SHA256SUMS.txt'}


def readiness():
    runs=[]
    for folder in sorted((RESULTS/'02_hardware').glob('*')) if (RESULTS/'02_hardware').exists() else []:
        state=folder/'notebook_02_status.json'
        entry={'run_id':folder.name,'status':'NOT_ANALYSED','hardware_counts_present':(folder/'receiver_counts.json').is_file()}
        if state.exists():
            d=json.loads(state.read_text());entry['status']=d['status']
            if d.get('data_kind')=='HARDWARE' and d.get('analysis_directory'):
                adir=ROOT/d['analysis_directory'];net=adir/'network'
                for label,file in [('phase_rows','measured_state_phases_concurrence.csv'),('process_rows','measured_cptni_fits.csv'),('gof_rows','count_level_gof.csv')]:
                    p=net/file;rows=list(csv.DictReader(p.open(encoding='utf-8'))) if p.is_file() else []
                    entry[label]=len(rows)
                entry['complete_four_resource_analysis']=(entry.get('phase_rows')==48 and entry.get('process_rows')==32 and entry.get('gof_rows')==32)
                entry['analysis_directory']=d['analysis_directory']
        runs.append(entry)
    ready=any(r.get('complete_four_resource_analysis') for r in runs)
    status={'created_utc':utc_now(),'hardware_evidence_status':'COMPLETE_ANALYSIS_REQUIRES_AUTHOR_REVIEW' if ready else 'NO_COMPLETE_NEW_HARDWARE_ANALYSIS',
            'runs':runs,'readiness_is_not_acceptance_or_validation_of_interpretation':True,
            'excluded_as_evidence':['Synthetic test results','Ideal numerical checks','Compiled-only legacy SCREEN artifacts'],
            'scope_warning':'A full single acquisition still does not establish between-session or cross-backend reproducibility; phase/entanglement intervals are conditional and boundary-limited.'}
    write_json(RESULTS/'publication_readiness.json',status)
    evidence=[]
    for r in runs:
        base=r.get('analysis_directory','Results/02_hardware/'+r['run_id'])
        present=r.get('complete_four_resource_analysis',False)
        for reviewer,request,rel in [
            ('R1-4 / R3','All four resources, common sectors and probes','network/tomography_completeness.csv'),
            ('R2-8','Raw/physical/tracked phase and circular bootstrap intervals','network/measured_phase_comparison.csv'),
            ('R2-9','CP-TNI residuals and boundary fraction','network/measured_cptni_fits.csv'),
            ('R2-9','Count-level parametric refit goodness-of-fit','network/count_level_gof.csv'),
            ('R2-10','Raw/recovered subspace definitions','network/measured_state_phases_concurrence.csv'),
            ('R2-11','Unconditional two-qubit mixed-state concurrence','network/measured_state_phases_concurrence.csv'),
            ('R3','Compiled recovery overhead and final pair audit','hardware_diagnostics/compiled_recovery_overhead.csv'),
            ('R3','Direct/SWAP baseline comparisons','matched_baseline_comparisons.csv'),
            ('R3','Limited receiver/discarded connected-correlation checks','hardware_diagnostics/receiver_discarded_correlations.csv')]:
            evidence.append({'run_id':r['run_id'],'reviewer_request':reviewer,'evidence':request,'expected_file':base+'/'+rel,
                             'file_exists':(ROOT/base/rel).is_file(),'complete_full_analysis':present})
    write_csv(RESULTS/'reviewer_evidence_index.csv',evidence)
    return status


def _safe(path):
    rel=path.relative_to(ROOT)
    return (not EXCLUDED_PARTS.intersection(rel.parts) and path.name not in EXCLUDED_NAMES
            and not path.is_symlink() and path.suffix not in ('.pyc','.pyo','.zip','.log')
            and not path.name.startswith('.env') and 'Inputs' not in rel.parts)


def _content(path):
    if path.suffix=='.ipynb':
        d=json.loads(path.read_text())
        for cell in d['cells']:
            if cell['cell_type']=='code':cell['outputs']=[];cell['execution_count']=None
        d.get('metadata',{}).pop('widgets',None)
        return json.dumps(d,ensure_ascii=False,indent=1).encode()
    return path.read_bytes()


def make_release():
    status=readiness();out=output_path('Exports')
    files=[p for p in sorted(ROOT.rglob('*')) if p.is_file() and _safe(p)]
    secret_patterns=[re.compile(rb'(?i)(?:api[_-]?key|token)\s*[=:]\s*[\"\']([A-Za-z0-9_\-]{30,})[\"\']')]
    entries=[];large=[]
    for p in files:
        data=_content(p)
        if p.suffix in ('.py','.json','.ipynb','.md','.txt'):
            for pat in secret_patterns:
                if pat.search(data):raise RuntimeError('Potential embedded credential in '+str(p.relative_to(ROOT))+'. Remove it before export.')
        if len(data)>50*1024**2:large.append(str(p.relative_to(ROOT)))
        entries.append((p.relative_to(ROOT).as_posix(),data))
    manifest={'created_utc':utc_now(),'hardware_evidence_status':status['hardware_evidence_status'],
              'files':[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in entries],
              'publication_note':'Notebook outputs are cleared in exports. Numeric results are separate Results artifacts. API accounts and original input ZIPs are not included.',
              'large_files_consider_github_release_or_lfs':large}
    report=[]
    for name in ('Revision_fixed5_submission_bundle.zip','Revision_fixed5_GitHub_bundle.zip'):
        path=out/name
        with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            for rel,data in entries:z.writestr('Revision_fixed5/'+rel,data)
            z.writestr('Revision_fixed5/EXPORT_MANIFEST.json',json.dumps(manifest,indent=2))
        with zipfile.ZipFile(path) as z:
            if z.testzip() is not None:raise RuntimeError('Export ZIP CRC failure')
        report.append({'file':path.relative_to(ROOT).as_posix(),'sha256':sha256(path),'files':len(entries)+1})
    result={'status':'LOCAL_BUNDLES_CREATED_NOT_UPLOADED','hardware_evidence_status':status['hardware_evidence_status'],
            'bundles':report,'large_files':large}
    write_json(out/'export_status.json',result);return result

if __name__=='__main__':print(json.dumps(make_release(),indent=2))

# Rights and public release

This update does not choose or grant a new open-source license on behalf of the manuscript authors. Preserve any applicable original rights. Before uploading to a public repository, the authors should confirm software authorship, data-sharing permissions and an appropriate license. CITATION.cff uses the manuscript author list only as citation metadata; it is not a copyright or contribution determination.

No submitted paper PDF, publisher-owned conference PDF, account credentials, or font files are included. IBM/Qiskit and other dependencies are not bundled; install them under their own licenses.

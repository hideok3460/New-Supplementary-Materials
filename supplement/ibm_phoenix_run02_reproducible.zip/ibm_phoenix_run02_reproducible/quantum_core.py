"""Offline, independently testable five-qubit model and receiver tomography.
Tensor convention: |q4 q3 q2 q1 q0>; receiver matrices are |q4 q3>.
No IBM service is contacted by this module. Synthetic data are explicitly labelled.
"""
from __future__ import annotations
import itertools
import numpy as np
from scipy.optimize import minimize

I=np.eye(2,dtype=complex)
X=np.array([[0,1],[1,0]],complex)
Y=np.array([[0,-1j],[1j,0]],complex)
Z=np.diag([1,-1]).astype(complex)
H=(X+Z)/np.sqrt(2)
PAULI={'I':I,'X':X,'Y':Y,'Z':Z}
SETTINGS=tuple(''.join(v) for v in itertools.product('XYZ',repeat=2))
PROBES={'0':np.array([1,0],complex),'1':np.array([0,1],complex),
        '+':np.array([1,1],complex)/np.sqrt(2),
        '+i':np.array([1,1j],complex)/np.sqrt(2),
        'chi':np.array([np.sqrt(.7),np.exp(1j*np.pi/3)*np.sqrt(.3)])}

def ket(index:int,n:int)->np.ndarray:
    v=np.zeros(2**n,complex);v[index]=1;return v

def single(g:np.ndarray,q:int,n:int=5)->np.ndarray:
    a=np.array([[1]],complex)
    for wire in reversed(range(n)): a=np.kron(a,g if wire==q else I)
    return a

def cx(control:int,target:int,n:int=5)->np.ndarray:
    a=np.zeros((2**n,2**n),complex)
    for b in range(2**n):a[b ^ ((1<<target) if (b>>control)&1 else 0),b]=1
    return a

def transfer_gates(x:int,m:int):
    # Chronological order, i.e. right-to-left in the manuscript's product U_T.
    g=[('h',(1,),H),('cx',(1,2),None),('h',(1,),H),('cx',(2,3),None),('h',(3,),H)]
    if m:g.append(('x',(3,),X))
    g += [('cx',(1,3),None),('h',(3,),H)]
    if m:g.append(('x',(3,),X))
    g += [('cx',(2,4),None),('cx',(4,3),None),('cx',(0,3),None),('h',(4,),H)]
    if m^x:g.append(('x',(4,),X))
    g.append(('cx',(4,0),None))
    return g

def transfer_unitary(x:int,m:int)->np.ndarray:
    u=np.eye(32,dtype=complex)
    for name,qs,g in transfer_gates(x,m):u=(cx(*qs) if name=='cx' else single(g,qs[0]))@u
    return u

def resource(m:int,M1:int,M2:int)->np.ndarray:
    return (ket(4*M2+2*M1,3)+(-1)**m*ket(4*(1-M2)+2*(1-M1)+1,3))/np.sqrt(2)

def encoding(y:int=0)->np.ndarray:
    return np.column_stack([ket(2*y,2),ket(2*(1-y)+1,2)])

def frame(x:int,m:int,M1:int,M2:int)->np.ndarray:
    return np.kron(X if m^x else I,(X if m^M1^M2 else I)@(Z if M2 else I))

def discarded(x:int,m:int,M1:int,y:int)->np.ndarray:
    return np.kron(np.kron(H@ket(m,1),H@ket(M1,1)),ket(m^x^y,1))

def raw_basis(x:int,m:int,M1:int,M2:int,y:int=0)->tuple[int,int]:
    z=m^x;kappa=m^M1^M2
    return 2*(y^z)+kappa,2*(1^y^z)+(1^kappa)

def partial_receiver(rho:np.ndarray)->np.ndarray:
    return np.einsum('aibi->ab',rho.reshape(4,8,4,8))

def partial_discarded(rho:np.ndarray)->np.ndarray:
    return np.einsum('aiaj->ij',rho.reshape(4,8,4,8))

def ideal_output(logical:np.ndarray,x:int,m:int,M1:int,M2:int,y:int=0)->np.ndarray:
    u=transfer_unitary(x,m);v=np.kron(resource(m,M1,M2),encoding(y)@logical)
    return u@v

def project_density(rho:np.ndarray)->np.ndarray:
    """Nearest PSD trace-one matrix in Frobenius norm (simplex projection)."""
    rho=(rho+rho.conj().T)/2
    rho=rho/np.trace(rho).real
    vals,vec=np.linalg.eigh(rho)
    ss=np.sort(vals)[::-1];cc=np.cumsum(ss)-1
    active=np.flatnonzero(ss-cc/np.arange(1,len(ss)+1)>0)
    theta=cc[active[-1]]/(active[-1]+1)
    vals=np.maximum(vals-theta,0)
    return (vec*vals)@vec.conj().T

def concurrence(rho:np.ndarray)->float:
    """Wootters concurrence, evaluated using a Hermitian PSD product."""
    rho=project_density(rho)
    vals,vec=np.linalg.eigh(rho)
    sr=(vec*np.sqrt(np.maximum(vals,0)))@vec.conj().T
    yy=np.kron(Y,Y);rt=yy@rho.conj()@yy
    a=sr@rt@sr;a=(a+a.conj().T)/2
    roots=np.sqrt(np.maximum(np.linalg.eigvalsh(a),0))[::-1]
    return float(max(0,roots[0]-sum(roots[1:])))

def probabilities(rho:np.ndarray,setting:str)->np.ndarray:
    if setting not in SETTINGS:raise ValueError('Expected two Pauli letters, receiver order q4 q3')
    out=[]
    for b in range(4):
        p=np.kron((I+(-1)**(b>>1)*PAULI[setting[0]])/2,
                  (I+(-1)**(b&1)*PAULI[setting[1]])/2)
        out.append(np.trace(p@rho).real)
    out=np.clip(out,0,None);return np.array(out)/sum(out)

def tomography(counts:dict[str,dict[str,int]],project:bool=True)->np.ndarray:
    """Nine-setting linear inversion. Counts 'b4b3', i.e. c[1]c[0].
    Repeated single-qubit expectations are pooled by their shot counts.
    """
    sums={a+b:0. for a in 'IXYZ' for b in 'IXYZ'}
    ns={k:0 for k in sums}
    if set(counts)!=set(SETTINGS):raise ValueError('Full tomography requires all nine settings')
    for ab,dd in counts.items():
        for bitstr,n in dd.items():
            bitstr=bitstr.replace(' ','')
            if bitstr not in ('00','01','10','11') or int(n)!=n or n<0:raise ValueError('Invalid two-bit count')
            v1=(-1)**int(bitstr[0]);v2=(-1)**int(bitstr[1])
            for key,v in [(ab,v1*v2),(ab[0]+'I',v1),('I'+ab[1],v2),('II',1)]:
                sums[key]+=n*v;ns[key]+=n
    if any(v==0 for v in ns.values()):raise ValueError('Missing shots')
    rho=sum((sums[a+b]/ns[a+b])*np.kron(PAULI[a],PAULI[b]) for a in 'IXYZ' for b in 'IXYZ')/4
    return project_density(rho) if project else rho

def sample_counts(rho:np.ndarray,shots:int,rng:np.random.Generator):
    return {s:{format(i,'02b'):int(n) for i,n in enumerate(rng.multinomial(shots,probabilities(rho,s)))} for s in SETTINGS}

def resample_counts(counts,rng):
    return {s:{b:int(n) for b,n in zip(['00','01','10','11'],rng.multinomial(sum(d.values()),np.array([d.get(b,0) for b in ['00','01','10','11']])/sum(d.values())))} for s,d in counts.items()}

def circular_interval(values:np.ndarray,center:float,level:float=.95)->tuple[float,float]:
    """Unwrap locally around point estimate. Not a global circular coverage guarantee."""
    delta=np.angle(np.exp(1j*(np.asarray(values)-center)))
    lo,hi=np.quantile(delta,[(1-level)/2,(1+level)/2])
    return float(center+lo),float(center+hi)

def choi_from_blocks(blocks:dict[str,np.ndarray])->np.ndarray:
    b0,b1,bp,bi=[blocks[k] for k in ('0','1','+','+i')]
    off=(bp-(b0+b1)/2)+1j*(bi-(b0+b1)/2)
    return np.block([[b0,off],[off.conj().T,b1]])

def effect_transpose(J:np.ndarray)->np.ndarray:
    d=J.shape[0]//2
    return np.array([[np.trace(J[i*d:(i+1)*d,j*d:(j+1)*d]) for j in range(2)] for i in range(2)])

def apply_choi(J:np.ndarray,rho:np.ndarray)->np.ndarray:
    d=J.shape[0]//2
    return sum(rho[i,j]*J[i*d:(i+1)*d,j*d:(j+1)*d] for i in range(2) for j in range(2))

def hermitian_basis(d:int):
    out=[]
    for i in range(d):
        b=np.zeros((d,d),complex);b[i,i]=1;out.append(b)
    for i in range(d):
        for j in range(i+1,d):
            b=np.zeros((d,d),complex);b[i,j]=b[j,i]=1/np.sqrt(2);out.append(b)
            b=np.zeros((d,d),complex);b[i,j]=1j/np.sqrt(2);b[j,i]=-1j/np.sqrt(2);out.append(b)
    return np.array(out)

def fit_cptni(blocks:dict[str,np.ndarray],solver:str='scipy'):
    """Unweighted block least squares, not a multinomial goodness-of-fit test.
    scipy is an offline fallback; cvxpy reproduces the original solver family.
    """
    Jlin=choi_from_blocks(blocks)
    keys=('0','1','+','+i');inputs=[np.outer(PROBES[k],PROBES[k].conj()) for k in keys]
    if solver=='cvxpy':
        import cvxpy as cp
        J=cp.Variable((4,4),hermitian=True)
        eff=cp.bmat([[cp.trace(J[2*i:2*i+2,2*j:2*j+2]) for j in range(2)] for i in range(2)])
        loss=sum(cp.sum_squares(cp.abs(sum(rho[i,j]*J[2*i:2*i+2,2*j:2*j+2] for i in range(2) for j in range(2))-blocks[k])) for k,rho in zip(keys,inputs))
        prob=cp.Problem(cp.Minimize(loss),[J>>0,I-eff>>0]);prob.solve(solver='SCS',eps=1e-7,max_iters=30000)
        if prob.status not in ('optimal','optimal_inaccurate') or J.value is None:raise RuntimeError(f'CP-TNI fit: {prob.status}')
        out=(J.value+J.value.conj().T)/2;status=prob.status
    elif solver=='scipy':
        if min(np.linalg.eigvalsh(Jlin))>=-1e-10 and max(np.linalg.eigvalsh(effect_transpose(Jlin)))<=1+1e-10:
            out=Jlin;status='feasible_linear_inversion'
        else:
            basis=hermitian_basis(4)
            target=np.concatenate([blocks[k].ravel() for k in keys]);target=np.r_[target.real,target.imag]
            design=[]
            for b in basis:
                z=np.concatenate([apply_choi(b,rho).ravel() for rho in inputs]);design.append(np.r_[z.real,z.imag])
            A=np.array(design).T
            def matrix(v):return np.einsum('k,kij->ij',v,basis)
            def coefficients(j):return np.real(np.einsum('kij,ji->k',basis,j))
            def project_psd(j):
                ev,vec=np.linalg.eigh((j+j.conj().T)/2)
                return (vec*np.maximum(ev,0))@vec.conj().T
            def project_tni(j):
                excess=project_psd(effect_transpose(j)-I)
                return j-np.kron(excess,I)/2
            # Consensus ADMM for a convex quadratic and two closed convex sets.
            rho_admm=1.;z=coefficients(.45*np.eye(4));w=z.copy();du=z*0;dv=z*0
            ata=2*A.T@A;atb=2*A.T@target
            def inverse(rho_admm):return np.linalg.inv(ata+2*rho_admm*np.eye(16))
            inv=inverse(rho_admm)
            for iteration in range(100000):
                theta=inv@(atb+rho_admm*(z-du+w-dv))
                oldz,oldw=z.copy(),w.copy()
                z=coefficients(project_psd(matrix(theta+du)))
                w=coefficients(project_tni(matrix(theta+dv)))
                du+=theta-z;dv+=theta-w
                primal=np.linalg.norm(np.r_[theta-z,theta-w])
                dual=rho_admm*np.linalg.norm(np.r_[z-oldz,w-oldw])
                if max(primal,dual)<1e-9:break
                if iteration%50==49:
                    factor=2 if primal>10*dual else (.5 if dual>10*primal else 1)
                    if factor!=1:rho_admm*=factor;du/=factor;dv/=factor;inv=inverse(rho_admm)
            else:raise RuntimeError('CP-TNI consensus ADMM did not converge')
            out=matrix(theta);status=f'consensus_ADMM_converged_{iteration+1}_iterations'
            if np.linalg.eigvalsh(out).min() < -2e-7 or np.linalg.eigvalsh(effect_transpose(out)).max()>1+2e-7:
                raise RuntimeError('CP-TNI numerical feasibility check failed')
    else:raise ValueError('solver must be scipy or cvxpy')
    residual=float(sum(np.linalg.norm(apply_choi(out,r)-blocks[k])**2 for k,r in zip(keys,inputs)))
    phi=np.array([1,0,0,1],complex)/np.sqrt(2)
    metrics={'solver':solver,'status':status,'block_residual':residual,'survival':float(np.trace(out).real/2),
             'identity_overlap':float((phi.conj()@out@phi).real/2),'choi_min_eigenvalue':float(np.linalg.eigvalsh(out).min()),
             'effect_max_eigenvalue':float(np.linalg.eigvalsh(effect_transpose(out)).max())}
    return out,metrics

def noisy_receiver(logical,x,m,M1,M2,y=0,p2=0.0,px_recovery=0.0,recover=True):
    """Illustrative stochastic-Pauli model, NOT calibration-derived hardware data.
    Perfect preparation and single-qubit transfer gates; nonidentity 2-qubit
    Pauli error with TOTAL probability p2 after each of the SEVEN transfer CXs.
    Physical recovery X errors use a depolarizing single-qubit Pauli model.
    """
    psi=np.kron(resource(m,M1,M2),encoding(y)@logical);rho=np.outer(psi,psi.conj())
    for name,qs,g in transfer_gates(x,m):
        a=cx(*qs) if name=='cx' else single(g,qs[0]);rho=a@rho@a.conj().T
        if name=='cx' and p2:
            mixed=np.zeros_like(rho)
            for pa,pb in itertools.product('IXYZ',repeat=2):
                if pa+pb=='II':continue
                e=single(PAULI[pa],qs[0])@single(PAULI[pb],qs[1]);mixed+=e@rho@e.conj().T
            rho=(1-p2)*rho+p2*mixed/15
    r=partial_receiver(rho)
    if recover:
        c=frame(x,m,M1,M2);r=c.conj().T@r@c
        for wire,active in [(1,m^x),(0,m^M1^M2)]:
            if active and px_recovery:
                mixed=sum(single(PAULI[p],wire,2)@r@single(PAULI[p],wire,2) for p in 'XYZ')/3
                r=(1-px_recovery)*r+px_recovery*mixed
    return r

class CPTNIFitter:
    """Reusable constrained least-squares fitter; no renormalization of code blocks.

    CVXPY's problem is built once and warm-started for bootstrap replicates.
    The independent numpy/scipy implementation remains available for offline tests.
    """
    def __init__(self, solver='cvxpy'):
        self.solver=solver
        self.keys=('0','1','+','+i')
        self.inputs={k:np.outer(PROBES[k],PROBES[k].conj()) for k in self.keys}
        if solver=='cvxpy':
            import cvxpy as cp
            self.J=cp.Variable((4,4),hermitian=True)
            self.B={k:cp.Parameter((2,2),complex=True) for k in self.keys}
            eff=cp.bmat([[cp.trace(self.J[2*i:2*i+2,2*j:2*j+2]) for j in range(2)] for i in range(2)])
            loss=0
            for k,r in self.inputs.items():
                pred=sum(r[i,j]*self.J[2*i:2*i+2,2*j:2*j+2] for i in range(2) for j in range(2))
                loss+=cp.sum_squares(cp.abs(pred-self.B[k]))
            self.problem=cp.Problem(cp.Minimize(loss),[self.J>>0,I-eff>>0])
        elif solver!='scipy':raise ValueError('solver must be cvxpy or scipy')
    def fit(self,blocks):
        if self.solver=='scipy':
            J,metrics=fit_cptni(blocks,'scipy')
        else:
            for k in self.keys:self.B[k].value=blocks[k]
            self.problem.solve(solver='SCS',eps=1e-7,max_iters=30000,warm_start=True)
            if self.problem.status not in ('optimal','optimal_inaccurate') or self.J.value is None:
                raise RuntimeError('CP-TNI solver failed: '+str(self.problem.status))
            J=(self.J.value+self.J.value.conj().T)/2
            phi=np.array([1,0,0,1],complex)/np.sqrt(2)
            metrics={'solver':self.solver,'status':self.problem.status,
                'block_residual':float(sum(np.linalg.norm(apply_choi(J,self.inputs[k])-blocks[k])**2 for k in self.keys)),
                'survival':float(np.trace(J).real/2),'identity_overlap':float((phi.conj()@J@phi).real/2),
                'choi_min_eigenvalue':float(np.linalg.eigvalsh(J).min()),
                'effect_max_eigenvalue':float(np.linalg.eigvalsh(effect_transpose(J)).max())}
        if metrics['choi_min_eigenvalue'] < -2e-6 or metrics['effect_max_eigenvalue']>1+2e-6:
            raise RuntimeError('CP-TNI fit failed the numerical physicality audit')
        return J,metrics

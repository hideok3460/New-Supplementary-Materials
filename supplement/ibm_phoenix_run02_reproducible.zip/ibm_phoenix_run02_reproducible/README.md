# IBM Phoenix run02: reproducible measured counts and repaired analyses

This package reorganizes the user-supplied **Revision_fixed5** experiment into **two English-language notebooks** while preserving the original scientific Python sources and the saved IBM Phoenix measurement/fit evidence. It is suitable for *preparing* a GitHub repository or a paper-review archive, not automatic online publication.

## Quick start

1. Unzip the project, open a terminal in the extracted **project root** (the directory containing `config.json`), and launch `jupyter lab` (or `jupyter notebook`) with a Python 3 kernel.
2. Install lightweight local display dependencies: `python -m pip install -r requirements-review.txt`. The included exact research dependency lists are `requirements-offline.txt` and `requirements-quantum.txt`.
3. Run all cells in **`ibm_phoenix_calculations.ipynb`** with `ACQUISITION_MODE = "reuse"` (the default). This checks the genuine recorded QPU results and generates `Results/Review_Outputs/hardware_counts_1746_circuits.csv`. It does not require IBM credentials.
4. Run all cells in **`analyze-phase-concurrence-cptni-gof.ipynb`**. The provided finished repair is read and strictly audited without refitting. It displays phase, concurrence, CP-TNI and goodness-of-fit; saves an English HTML report; and produces both local step-10 export ZIPs.
5. For **numerical repair from scratch**, install the full research environment in `requirements-quantum.txt`, including Qiskit, IBM Runtime, CVXPY, and SCS, then use `ALLOW_NUMERICAL_REPAIR = True` if the repair is absent/incomplete. The pre-existing repair normally bypasses this expensive stage. For **new QPU runs**, install the same environment and use the separate stage-1–7 notebook's explicit `live` mode, with consent at submission. The supplied `run_id` already has six saved hardware jobs; **do not accidentally submit them again**.

## Confirmed saved-run identity

| Property | From the saved evidence |
|---|---|
| Experiment stage | `full` |
| Run ID | `full_4resources_run02` |
| Hardware backend | `ibm_phoenix` |
| Acquisition | 1,746 circuits × 4,096 shots = **7,151,616 shots** |
| IBM jobs | Six saved IBM Runtime job IDs (see `submitted_jobs.json`) |
| Normalized counts | `Results/02_hardware/full_4resources_run02/receiver_counts.json` |
| SHA-256 | `99ce131823c6bc7b1cf50599adc079fbcf708cc7f46f44b07b7c88b6c646b188` |
| Protocol inventory | Network 1,440; discarded diagnostics 192; direct preparation 45; SWAP transfer 45; readout calibration 24 |
| Network repaired analysis | 48 state rows (16 frame-tracked derived), 32 CP-TNI processes, 32 count-level GOF tests |
| Baselines | Direct preparation: 1/1/1; SWAP transfer: 1/1/1 (state/process/GOF) |
| Bootstrap settings | 500 counting and 500 parametric GOF replicates (as recorded) |

These are **preserved hardware records from the uploaded archive**, rather than new cloud measurements run by this assistant. The package independently verifies their internal consistency, job attribution and checksums; external provider confirmation would require a user's authorized IBM account. Do not claim that saved counts were freshly measured during package creation.

## Package layout

```text
ibm_phoenix_run02_reproducible/
├── ibm_phoenix_calculations.ipynb
├── analyze-phase-concurrence-cptni-gof.ipynb
├── README.md
├── requirements-review.txt
├── config.json
├── phoenix_hardware_evidence.py
├── phoenix_acquisition_controller.py
├── run02_completed_results.py
├── run02_local_repair.py / full_receiver_solver_repair.py
├── quantum_core.py / count_level_gof.py / reanalyse_counts.py / ...
├── regression/ ...
└── Results/02_hardware/full_4resources_run02/
    ├── raw_counts/00000.json ... 01745.json
    ├── receiver_counts.json, manifest.json, plan.json, job_metadata.json
    ├── compiled_circuits.qpy, logical_circuits.qpy, compiled_metadata.json
    ├── analyses/analysis_e18778278933/ ...
    ├── repairs/gof_repair_2c61f51ed8ce/ ...
    └── reports/step9_10/ ...
```

## Repair and model-fit provenance

The original sequential stage 8 stopped on a numerical GOF fit. The repaired evidence was completed in the supplied archive. The project verifies recorded numerical recovery of failed bootstrap sample 396 without discarding that sample or relaxing the stated constraints. The original **network 48/32/32** evidence was reused unchanged; baseline GOF calculations were recomputed with the documented certified fallback. Files `repair_completion.json`, `repair_identity.json`, `solver_audit.jsonl`, `frozen_null.json`, and `parametric_null_statistics.npz` document the result.

The analysis notebook uses the original strict validation/export logic reorganized into `run02_completed_results.py`, preserving SHA-256 checks of the scientific sources and repaired tables. It is not a substitute for an independent science review or uncertainty analysis.

## Reporting and export

Run step 9 to write `Results/02_hardware/full_4resources_run02/reports/step9_10/step9_results.html` and validation metadata. Step 10 writes `Results/Exports/full_4resources_run02_step10_submission.zip` and `Results/Exports/full_4resources_run02_step10_GitHub.zip` (or timestamped names if a nonidentical file already exists). They are **local evidence exports**, not remote uploads, and are not substitutes for the full bundled reproducibility ZIP.

## Reproducibility limits and security

- **Real measurement vs. derived analysis:** `data_kind=HARDWARE` with saved IBM job IDs identifies recorded QPU counts. Frame-tracked data are computed from existing counts, not new experiments. The local count-table export does not alter original JSON.
- **Statistical meaning:** 95% multinomial count intervals are conditional on one acquisition; finite-replicate intervals, convex boundaries, and parametric GOF have caveats. SPAM, device drift, calibration and readout-model uncertainty are not fully propagated. No measurement mitigation is asserted.
- **Integrity:** The program stops on missing counts, inconsistent SHA-256, mismatched job IDs or incomplete analysis results. Do not edit original hashed science scripts or repair files. For a new dataset, create a new run ID and rebuild the evidence rather than suppressing checks.
- **Secrets:** No IBM API key or CRN should be committed. Live mode requests credentials through masked input and explicitly asks for submission approval. Before pushing to GitHub, inspect all included data and license notices (`LICENSE_NOTICE.md`) and decide whether hardware job IDs and calibration files are appropriate for public release.
- **Environment:** The original acquisition was made using the saved Windows/Qiskit runtime environment. Package assembly and offline review are cross-platform, while exact numerical reruns may depend on solver and SDK versions.

## Verification command

```bash
python -c "from pathlib import Path; from phoenix_hardware_evidence import verify_saved_hardware; print(verify_saved_hardware(Path('.')))"
```

The project's review-time validation and notebook execution log are in `VALIDATION_EN.md` and `Results/Review_Outputs/`.

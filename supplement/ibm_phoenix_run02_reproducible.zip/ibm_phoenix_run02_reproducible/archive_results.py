"""Backward-discoverable entry point for publication-safe Results exports.
The previous append-to-external-S4 behavior was removed: outputs stay in Results.
"""
from publication_export import make_release
if __name__=='__main__':
    import json
    print(json.dumps(make_release(),indent=2))
